
## Read-only Lean code gutter

Added a native numbered gutter and horizontal scrolling to the saved Lean source in the explicitly opened formal details inspector. Source text is unchanged; line numbers are accessibility-hidden and excluded from selectable proof text. Preview compilation and official UI-only build passed. Visually checked `screenshots/formal-details-numbered-code.png`: number alignment follows actual source lines, including blank lines, and long statements scroll horizontally. No Provider calls were made. Full 15-page pixel fidelity remains unverified and incomplete.

## Shared navigation groups

Matched the source sidebar grouping, 11pt Manrope section labels, 16pt group spacing, 2pt row spacing and 14pt brand title. Existing actions only; no inert project tree or fabricated resource menu was added. Captured all 15 current native page states in `screenshots/latest15/` with matching AX snapshots. These are explicit preview fixtures, not production AI executions. Inspected workspace screenshot: grouped sidebar and existing native editor render successfully. Previous `current15` captures are historical. Full pixel fidelity is still incomplete.

## Native Lean syntax colors

Read the original `tab-lean-code` export and matched code background #14181a, text #e0e9eb, gutter #566568, keywords #00e7fe/#27d8ff, tactics #80cbc4 and comments #78909c with SwiftUI AttributedString. Styling leaves the source string intact and is cosmetic, not a Lean parser. Visually verified saved source in `screenshots/formal-details-native-syntax.png`. Native preview and official UI-only builds passed; no AI request or new Kernel run. Selected-goal code correspondence and full 15-page pixel fidelity remain incomplete.

## Import page command strip and gateways

Matched original 20pt command strip padding/title, 32pt header icon, 224pt gateway height, 40pt gateway icons, 14pt Manrope titles and 16pt card gaps. Replaced the prior gray nested queue cards with white divided rows padded 20pt vertically. Preserved actual file/text/camera/handwriting actions and existing source correction; did not copy fabricated device connection, auto-enhancement, blur metrics or five simultaneously asserted sample errors. Preview screenshot `screenshots/import-native-command-strip.png` checked command strip/cards/actual one-block queue. Queue header icon fallback noticed and changed to supported file_upload for final build. Native preview compilation and final official build passed. No Provider requests. This remains a partial visual correction, not a 1:1 pass.

## Disambiguation hierarchy

Aligned outer 32pt padding, 24pt vertical spacing, inset 16pt status header, 20pt context/candidate gaps, 12pt corner radius and 200pt candidate card height. Short candidate glyphs render at 48pt; long readings stay at 24pt. Added actual ambiguity index/count and explicit selected styling, without source confidence percentages, automatic recommendations or stroke precision claims. Context retains original full draft in a 220pt scroll area. Preview compilation and official UI-only build passed. GUI selected candidate π and AX confirmed selection without submitting a correction; screenshot `screenshots/ambiguity-native-candidate-hierarchy.png`. Associated-image rendering remains unverified in this fixture. No AI/Kernel request. Full 15-page fidelity incomplete.

## Camera toolbar and viewfinder

Matched 16pt top control strip, 16pt title, device controls in header, edge-to-edge 4:3 native camera preview and low-surface mode/action bands. Explicit enable remains required for macOS camera permission; opening the page does not enable hardware or call AI. Displayed actual not-enabled message rather than false captured/connected status. Preview compile, GUI page opening and official build passed; screenshot `screenshots/camera-native-toolbar-viewfinder.png` inspected for aspect ratio and toolbar. No hardware/continuity/photo recognition test, no Provider request. Physical source overlays and full 1:1 fidelity remain incomplete.

## Shared container radius

Source main regions use distinct rounded-xl outer containers and rounded-lg proof rows. Added explicit StitchCard radius: outer containers default 12pt, ProofCard retains 8pt. Compiled preview and official bundle; captured import page `screenshots/import-native-container-radius.png`. Backend SHA audit checked 36 files, none changed; AI audit still 16 events, no new requests. These checks do not establish full 15-page pixel fidelity.

## Per-page title scale

Added adjustable native heading size to remove the uniform 26pt approximation: workspace/preferences now 30pt, step-detail/disambiguation 20pt, formal-detail 24pt, matching the original exported heading classes at desktop widths. Other generic headings use 24pt pending exact source inspection. Preview/official compilation passed; preferences screenshot `screenshots/preferences-native-title-scale.png` saved. No AI calls. This typography change does not prove complete page fidelity.

## Context bars instead of generic hero headings

Inspected original main containers for recognition/verifying/source-mapping/editing. These pages use compact context bars (12pt title text for first three, 16pt for editing), not generic large page headings. Added native context bar with 16pt padding and replaced all four approximations, preserving source-precision explanations and existing actions. Preview and official builds passed; four `*-native-context-toolbar.png` captures collected through native UI state navigation. These are explicit fixtures; no AI or new Kernel run. Remaining layout/action differences prevent full 1:1 acceptance.

## Page-specific app shell

Original success PNG and HTML have full-width 48pt top navigation with no sidebar, unlike the prior generic native shell. Implemented native top navigation for success using existing home/workspace/history/preferences/detail actions. Recognition/camera source sidebars are 240pt, other sidebars 256pt; workspace/recognition/verifying headers 56pt, others 48pt. Preview GUI success state confirms sidebar absent and top actions accessible, capture `screenshots/success-native-top-navigation.png`. Preview/official builds passed. No AI/Kernel run; full page fidelity remains incomplete.

## Per-page content widths and margins

Read all original main container classes instead of continuing one 1440pt/24pt approximation. Native root now uses source maximum widths: preferences 1140, system 1180, ambiguity 1240, step detail 1280, workspace 1720, camera 1580, failure 1520; full-width mapping/editing/recognition/formal pages. Source horizontal margins: welcome 48, ambiguity/import/verifying 32, camera 28, others 24. Source vertical margins vary 20/24/32. Captured all 15 states and AX trees in `screenshots/page-sizing/`. Official and preview builds passed, no AI. Full pixel and interaction acceptance remains incomplete.

## Proof card source correction

Directly inspected success step-card HTML: outer rounded-xl (12pt), inner formula rounded-lg (8pt), formula text-base (16pt), 28pt numbered circle with bold monospaced 12pt numeral. Corrected the earlier unsupported 8pt outer-card approximation and 19pt formula text. Native preview and official builds passed; formal-details capture `screenshots/formal-details-source-step-density.png`. Original mathematical/source strings and verification flags unchanged. No AI call. Full page fidelity not yet proven.

## Failure summary emphasis

Matched white 24pt failure summary container instead of shared success low-surface/32pt treatment. Added actual failed-status error icon and error tint; unresolved ambiguity keeps amber rather than claiming a proven mathematical error. Kernel truth predicate unchanged. GUI explicit failure fixture shows not passed, 3/4 established, first step unproved; saved `screenshots/failure-native-status-emphasis.png`. Preview/official builds passed. No Provider/Lean call; fixture is not real failure verification. Full 1:1 acceptance incomplete.

## Associated handwriting image visual check

Added explicit image/recorded-recognition mode to the separate preview target, constructor-injecting the standalone local fixture client. Production App is unchanged. Original user handwriting image is served locally, paired with its recorded recognition fixture including confirmed leading 2. GUI displayed the image and 16 preserved recognition blocks; `screenshots/recognition-native-real-image.png`. This is image rendering only, not new OCR/AI/Kernel success. Initial preview compile failed due private api access; corrected through existing constructor injection, rebuilt successfully. Revealed an unresolved fidelity issue: LaTeX commands are displayed literally in read-only math. Next change should fix presentation while retaining original edit text.

## Conservative native math presentation

Added Foundation-only MathPresentation adapter for delimited simple LaTeX: Greek/relations/blackboard sets/trigonometric commands/numeric scripts render as native text. Unsupported syntax retains entire original span, including unknown commands/fractions/complex scripts. Only MathText calls it; TextEditor, submissions, source mapping and backend strings remain unchanged. Local Swift checks passed for original preservation, confirmed leading 2, Greek/Unicode, numeric scripts, unknown/fraction fallback and unmatched delimiters. GUI recorded handwriting preview shows readable n ∈ ℕ* and cos nθ, while editor retains original LaTeX; screenshot `screenshots/recognition-native-readable-math.png`. Native preview/official builds passed. This is partial native typesetting, not full LaTeX fidelity; fractions and complex layouts still pending. No AI/Kernel requests.

## Recognition multi-block layout

Matched original 340pt source column. Applied conservative read-only math display to fragment labels too. Bounded source fragment list to a scrollable viewport and fixed editable area to 240pt so 16 actual recorded blocks do not stretch the correction pane. All blocks remain present; this is layout, not an input limit. GUI showed all 16 AX buttons, scrolled to last and selected block 16, original/editor switched to 证明完毕. Capture `screenshots/recognition-native-scrollable-fragments.png`. Preview and official builds passed. No AI submission or new recognition. Full 15-page 1:1 fidelity remains incomplete.

### Native source-image inspection

SourceImage now provides manual SwiftUI zoom, pan and reset for an actual linked image. The recognition Golden Master includes a magnified manuscript inspection card; this implementation exposes visual inspection without inventing source coordinates or pen-level alignment. Missing/unreadable images retain honest empty/error states. Changing the image URL resets the viewport.

The explicit local preview loaded the user's image and previously saved 16-block transcription. Native button QA observed 100% → 150% → 100%, and screenshots were saved as `recognition-native-image-zoom.png` and `recognition-native-image-reset.png`. Drag was exercised but its intermediate visual offset was not separately captured; trackpad magnification remains untested. No recognition, formalization or Kernel request was executed. Full 15-screen pixel fidelity remains incomplete.

### Verification page proportions and stage styling

Compared directly with original `a88d7c66ad8a411d8ec765ac9a255f0a/screen.html`: main split is seven versus five columns, cards use 8-point corners, stage markers are 20 points, stage labels 12 points and descriptions 11 points. The native page now follows those measurements with an adaptive 7:5 content split, a 24-point manuscript card and an actual active-stage spinner. Other stages remain numbered rather than falsely asserting completion. Source-only percentages, timings, cached-memory/PID telemetry and automatic assumption completion remain absent.

Explicit preview screenshot `verifying-native-source-column-ratio.png` confirms the widened right column and all five stage cards. This is UI fixture evidence, not a new live workflow. The manuscript and monitor contents still differ from the sample's four-step document; full 1:1 acceptance remains open.

### Source mapping three-column structure

The original `572475286f1e47eabe0b859baca2de7a/screen.html` uses three equal `col-span-4` panels and a horizontal compact step-pill navigation. NativeSourceMapping now separates manuscript images, recorded transcription and the selected mathematical proof step into equal flexible columns with 12-point gaps and 14-point panel padding. Shared source asset IDs are displayed once instead of once per transcription block. The existing backend sourceRefs still determine highlighted blocks; no mapping semantics or recognition requests changed.

Native preview screenshots `source-mapping-native-three-columns.png` and `source-mapping-native-step-two.png` cover the text-only source record and selecting step 2, which correctly changes its statement and original text. This recorded UI check performs no new AI or Kernel verification. Linked-image mapping state, the source design's image viewport height/header bands and full pixel comparison remain outstanding. Confidence heatmaps, simulated pen coordinates, automatic corrections and engineering telemetry are not presented as actual data.

### Mapping viewport and panel header bands

Compared with the same original HTML: each of the three panels now has a gray toolbar band padded 14 points horizontally and 10 vertically, with 18-point icon and 12-point heading. The mapping manuscript viewport is 470 points high as specified by the original; SourceImage accepts a page-specific height while retaining 220 points for existing recognition/ambiguity uses. Loading, missing and failed images use the same requested viewport height.

Screenshot `source-mapping-native-header-bands.png` confirms native toolbar fill and text-only empty viewport height. Native preview and official Mac App compilation are checked separately. The linked-image mapping state remains unverified; this text record is not evidence of an image-backed mapping result. No new DeepSeek or Kernel request was made. Pixel fidelity for all 15 screens remains incomplete.

### Editing page editor/inspector arrangement

Compared with original `917799af0caf4a87b769a77dac11a5b7/screen.html`: the active editor belongs to the left seven columns and comparison inspector to the right five, using a 20-point gap, 16-point padding and 8-point corners. NativeEditing now uses that arrangement instead of two equal panels with old text first. The right inspector exposes removed and added text using the unchanged deterministic TextRevisionDiff; engineering code and simulated incremental verification/cache claims are not introduced.

Screenshots `editing-native-editor-inspector-ratio.png` and `editing-native-live-text-diff.png` cover native layout and an explicit preview edit. Inserting a line updated the inspector to “新增 1 行” immediately without submitting verification. This is text binding/UI evidence, not AI or Kernel verification. Source sample's proof-flow cards, command strip and side-by-side comparison arrangement remain visual gaps; all 15 pages are not yet accepted as 1:1.

### Step-detail navigation and proportions

Original `23d08e342737439b9983abcd2e2943bd/screen.html` uses eight main columns and four inspector columns, a compact step navigator, 24-point section gaps, a 36-point status icon and 8-point mathematical inset corners. NativeStepDetail now follows these measurements and adds local navigation over the actual recorded steps. It preserves existing row/source/dependency bindings and does not issue re-verification when a step is selected.

Screenshots `step-detail-native-navigation-ratio.png` and `step-detail-native-third-step.png` verify the native layout and switching from step 1 to step 3, showing its correct original content and two recorded predecessor dependencies. Evidence uses the saved proof record, not a new AI or Kernel run. Failure-row detail rendering, the original source's context/goal microgrid and full-page pixel comparison remain outstanding; overall 15-screen 1:1 acceptance is still incomplete.

### Result proof stream and inspector columns

The success and failure originals both specify eight proof-flow columns and four inspector columns, with success gaps of 32 points and section spacing 24, versus failure gaps 24 and spacing 20. NativeResult now applies those measurements below the summary, keeping all actual proof rows on the left and existing explanation/original-source actions on the right. Explanation generation remains an explicit user action; no rendering/navigation call requests AI. Verification predicates and backend are unchanged.

Screenshots `success-native-proof-inspector-columns.png` and `failure-native-proof-inspector-columns.png` cover both explicit UI states. The failure fixture retains 3/4 established rows and “尚未通过”; success uses the previously saved verification record. No new AI or Kernel run occurred. The failure summary is still full-width whereas the original nests it in the left column, and remaining sample/content/header differences prevent full 1:1 acceptance.

### Failure summary nested in main column

NativeResult now separates page composition from its shared result-summary view. As the original failure HTML specifies, the failure summary is inside the left eight-column stack; the inspector starts alongside it. Success retains its full-width summary. The failure mathematical heading is 18 points, metric padding is 10 points with 54-point minimum height and 8-point corners; success section gaps are 32 points. Shared verification data/predicates are unchanged.

`failure-native-summary-left-column.png` confirms top-aligned failure summary/inspector and the preserved 3/4, not-passed state. `success-native-summary-spacing.png` covers retained success composition. Explicit UI fixtures only; no fresh AI/Lean run. Detailed failure diagnosis cards, source-defined header content and matched-data pixel comparisons still remain before 15-screen 1:1 acceptance.

### Expanded unproved-step result card

The original failure page's focal failed-step card uses a tinted header (20-point horizontal / 14-point vertical padding), 24-point number marker, 20-point body padding, 16-point subcard gaps and a 12-point outer outline. UnprovedStepCard now follows this structure for actual unestablished rows on the failure page, separating original text, current mathematical statement and existing verification message. Established rows and success pages retain their existing ProofCard. “尚未证明” remains the status; formalization failure is not asserted to be a mathematical counterexample.

`failure-native-expanded-unproved-step-visible.png` confirms the expanded card; `failure-native-card-detail-binding.png` confirms its action navigates to the corresponding still-unproved step 1. Explicit fixture only, no live AI or Lean request. Source example's invented OCR suspicions, counterexamples, auto-apply repair options and telemetry are not fabricated. Full matched-data pixel acceptance for all 15 pages remains incomplete.

### Welcome gateway hierarchy

Original welcome HTML uses max-w-6xl (1152), three 24-point padded gateway cards, 40-point icons, category badges, title arrows, grouped copy and an action area separated by 24 points. NativeWelcome now follows those measurements, with 16-point inner group spacing, 8-point title/description spacing, 6-point use-case spacing and 8-point button spacing. Only the first gateway's primary action is emphasized; camera/history actions use neutral source styling. The actual supported routes and honest capability descriptions remain unchanged.

`welcome-native-gateway-hierarchy.png` and `welcome-native-gateway-actions.png` cover source-derived hierarchy and buttons. A remaining display defect is visible for a pre-existing multiline draft in the quick-start TextField: its fixed one-line viewport clips the multiline content. Draft data itself remains preserved. Full native multiline quick-input presentation, lower source preview structure and all-page matched pixel acceptance remain incomplete. No live AI or Lean verification was run.


### 首页快速输入栏实验（未接入正式 App）

尝试局部 AppKit NSTextField + 原生裁切容器，截图 `screenshots/welcome-native-clipped-input.png` 可见多行原稿只显示一行。AX 仍保留完整原稿。但粘贴/编辑绑定检查未获得成功结果，后续 CUA 报告 procNotFound。不能以裁切截图证明编辑功能通过。实验保存于 `macos/Preview/Experiments/NativeQuickInput.swift.disabled`，正式源码恢复现有 SwiftUI TextField，不引入实验控件。输入栏多行显示问题仍待修复。未执行新的 AI 或 Lean 验证；15 页尚不声称 1:1。


### Welcome source spacing and icons

Restored source HTML hero width 768, description/input width 576, individual gaps 24/20/16/32/10, hero-to-gateway gap 56 and gateway-to-preview gap 48. Desktop description font is 16. Gateway arrows, scenario icons and all six action icons now use the bundled Material Symbols font; codepoints checked against Google material-design-icons upstream. Actions retain their existing bindings. Button padding is 12 horizontal / 8 vertical, icon 16, gap 6, secondary fill low grey. Native screenshots: screenshots/welcome-native-hero-source-spacing.png and screenshots/welcome-native-source-action-icons.png. Icons were visually inspected in the complete gateway view. No new AI or Kernel validation. Entire-page 1:1 remains unproven; source preview structure and multiline quick-input editing still need work.


### Step detail context/goal and header

Restored source two-column micro-grid below original manuscript, gap 16 and padding 20. Context uses only recorded dependencies with each actual established flag; missing dependencies have an explicit empty state. Goal displays selected row.math and established state, with its saved explanation. No inferred hypotheses or synthetic proof obligations are inserted. Step 3 screenshot shows two recorded dependencies and its correct target; switching from step 1 was checked through native AX. Header now places title/status, step navigation and edit action in one horizontal low-grey band. Edit action navigates to the existing manuscript editor, preserving full multiline draft; AX confirms editing view with no automatic submission. Evidence: screenshots/step-detail-native-context-goal.png and screenshots/step-detail-native-header-context.png. Uses saved record in explicit preview, not a new Kernel check. Remaining source diagnostic-analysis/remediation layout and same-data pixel comparison are still incomplete; no 1:1 claim.


### Recognition three-column and inline editor

Restored source three-column composition: image left, manuscript cards/inline selected editor center, proofreading/action inspector right. Gaps 24; source/image and inspector widths adapt toward source 340/330 on wider windows without shrinking the mathematical center to zero on the current Mac. Selected card padding 18, 2-point primary outline, source rendering plus editable raw transcription in the same card; inactive cards padding 16, radius 12, math font 16, gaps 12. Removed separate large source/editor cards. All 16 existing segments remain accessible in the scroll list. Inspector shows actual selected index/count, explicit verify and copy-current-text actions; source fictional confidence percentages, pixel mapping and automatic normalization claims were not copied as real results. Existing select/save/verify bindings retained. Native screenshot screenshots/recognition-native-inline-three-columns.png confirms original image and selected segment 2 retains its user-confirmed leading 2 in rendered and editable text. Existing recording/fixture, no new OCR or Kernel success. Backend baseline unchanged (36 files), audit remains 16 events. Type-check failure corrected by splitting views and using the actual StitchCard initializer. Same-data pixel comparison, image detail panel and source toolbar remain incomplete; overall 1:1 not achieved.


### Editing command strip and proof flow

Added source-aligned horizontal command strip (24 horizontal / 16 vertical padding, 16-point title, comparison/restore/explicit verify actions), compact mathematical recorded-step cards (14 padding, 20-point number circles, 12-point math, 10-point historical status) around the manuscript editor, and source cyan/primary top indicator. Existing editor remains the full mathematical manuscript, not a Lean editor or synthetic local hot-reverification engine. Previous record flags are labeled historical, never current edited-proof success. Comparison toggle and restoring original manuscript were exercised through native UI; inserting one local test line then Restore returned the full original multiline draft without that line. No verify/AI action was clicked. Screenshot screenshots/editing-native-command-proof-flow.png covers step-3 focus with upstream cards and comparison panel. Later added an explicit focus caption to clarify which recorded step is being compared. Remaining code-centric source features intentionally obey latest default-human-math instruction; full same-data pixel comparison remains unproven. Backend proof pipeline unchanged, no new AI requests.


### Preferences category strip and responsive preview

Restored source title metadata/icon, reset action, four-category horizontal segmented strip (6 padding, 16 radius, 17 icons, 12 labels), 32-point section gaps and 7:5 settings/preview width ratio with 24-point gap. Setting/preview card radius 16. Existing math-size binding and formal-detail toggle remain, categories route to existing input actions and formal record, shortcuts describe exactly the official NativeApp commands. No fake engine version, synchronization timing, unsupported typeface selector, handwriting normalization or Kernel policy settings are exposed as functioning features. Native screenshot screenshots/preferences-native-segmented-layout.png inspected. All four category bodies checked in native AX; font increment 19->20 updated preview and Restore returned 19 with engineering off. Input copy wording subsequently simplified in source. These are UI fixture checks, no Provider or Kernel run. Source font-family/script-ratio controls and full same-data pixel fidelity remain incomplete, so overall 1:1 remains unproven.

## Native system status layout continuation

Implemented the Stitch banner top gradient, low-surface status footer, 24 pt section spacing, and four status cards in a two-column SwiftUI grid. Cards bind to actual local service, task, manuscript, and saved verification state. No automatic healing, backup AI routing, or retry controls were added. Technical diagnostics remain collapsed by default.

Executed: built the explicit fixture preview; inspected its native accessibility tree and screenshot with an unavailable-service fixture and preserved mathematical manuscript; selected Return manuscript and confirmed the complete original mathematical text remained in the workspace. Screenshot: screenshots/system-error-native-four-status-cards.png. This is UI fixture verification, not a new AI or Kernel run.

Backend baseline: 36 files checked, zero changes. AI audit still contains 16 historical events, with zero new requests for this UI check. Overall 15-page visual fidelity remains incomplete; this iteration does not establish a pixel-identical match.

Official app rebuild executed with `python3 scripts/build_mac.py --reuse-backend`: exit 0. Output: /[LOCAL_USER]/Documents/ChatGPT/极简lean 2/dist/极简 Lean.app. Existing packaged backend reused; local ad-hoc signing only.

## Formal inspector proportional layout

Replaced the fixed 390 pt inspector with the source 7:5 split and 24 pt gap. Implemented the gray 16/12 pt header and scrollable native 12 pt tab strip, preserving Lean, MathIR, diagnostics, Statement Lock, and Mathlib content. Copy reads the selected saved content, without generating code or invoking the Provider. Added the source data_object Material glyph from the retained official codepoint listing.

Executed preview compilation and native window inspection. Captured screenshots/formal-details-native-proportional-inspector.png; switched the diagnostics tab and observed the saved verification diagnostics. The screenshot predates the final data_object glyph fix. Header metadata, focused step/code mapping, lower metrics, and identical-data pixel comparison remain incomplete. This is recorded-response UI QA, not new AI or Kernel success.

Final official native build including icon mapping: build_mac.py --reuse-backend exit 0. Backend baseline remains unchanged; AI audit remains 16 historical events, zero new AI calls.

## Formal mathematical step cards

Replaced generic result cards on the explicit formal-details page with source-derived compact 20 pt padding, 24 pt rounded-square numbering, 14 pt heading, 12 pt explanation/formula, 36 pt inset formula panel, 12 pt card gap, and selected-step primary border. Clicking a step now keeps the formal page open and sets the actual selectedStep; the inspector shows its recorded id with an explicit detail navigation. Complete Lean code remains unchanged; no claim of precise code highlight or automatic execution is made.

Preview compilation passed after an initial build was stopped by a source edit during compilation. Native UI selected p3, stayed on formal-details, and displayed current step p3. Screenshot screenshots/formal-details-native-compact-selected-step.png was inspected. Visual scope remains incomplete: code scroll/highlight mapping, source subheader and source-data matched comparison still pending. UI fixture only, no live AI or new Kernel verification.

Official app rebuild --reuse-backend passed (exit 0); backend baseline unchanged; AI audit still 16 historical events, zero new requests.

## Formal source-marker code focus

Verified backend/lean/compiler.py emits explicit `-- 原文步骤: <stepId>` markers in the saved Lean source. The native attributed text now highlights only the corresponding recorded block, preserving the original string, line numbering, text selection, and copy result. Missing, repeated, or newline-bearing ids receive no inferred highlight. This is block-level presentation, not character-level original-image mapping or a tactic execution breakpoint.

Preview build passed. Native UI selected p1 and screenshot inspection confirmed only its lines 4–11 were highlighted; p2 and later remained unhighlighted. Evidence: screenshots/formal-details-native-recorded-code-highlight.png. No AI or Kernel run. Automatic scroll-to-block and complete 15-page source-matched visual comparison remain pending.

## Formal context strip

Replaced the large formal-page heading with the source compact white context strip: 24 pt horizontal / 12 pt vertical padding, 12 pt record status/context, 11 pt inspector state, and an explicit return-to-math action. Status reads the saved record verification predicate; no fictional version, runtime, timing, or live execution labels were copied. Native preview compiled. Screenshot formal-details-native-context-strip.png inspected. Return to math view was clicked and the workspace route was confirmed. Backend baseline remains unchanged, AI audit remains 16 historical events (zero new AI calls). This is UI fixture QA; complete same-data 15-page 1:1 acceptance remains pending.

## Formal footer summary grid

Added the source four-column footer with white 20 pt card, 16 pt gaps, gray 12 pt inner cards, 11 pt mono headings, and 20 pt metric values. Bound proof-step count, established-step count, deduplicated certificate axiom names, and the saved verification predicate. Duration is explicitly not recorded; no invented tactic count, confidence percentage, or timing is used.

Preview compilation passed. Scrolled the native window to the bottom and inspected screenshots/formal-details-native-summary-grid.png: 4 recorded steps / 4 established, 3 recorded axiom names, saved Kernel verified, and absent timing. This verifies UI rendering against an existing record, not a new Kernel run. Backend baseline unchanged; audit remains 16 historical events with zero new requests. Full 15-page 1:1 acceptance remains incomplete.

## Handwriting-backed source mapping inspection

Selected the explicit handwriting display fixture, then navigated to source mapping. Native accessibility and screenshot confirmed a single actual user image, all 16 saved transcription blocks, preserved leading 2 in the blue method-1 formula, and the honest no-verification-step state. No recorded algebra result was falsely attached to this handwriting image. Screenshot screenshots/mapping-native-handwriting-source.png inspected. This is saved-response image rendering, not fresh recognition or Kernel validation.

Then replaced the large context card with the source compact toolbar: 16 pt horizontal / 10 pt vertical low-surface strip, 12 pt slice/context labels, and 11 pt step-precision note. The screenshot above predates this toolbar edit; new toolbar runtime screenshot is still pending. Backend baseline unchanged; AI audit remains 16 historical events, zero new requests. Full 15-page source-matched acceptance remains incomplete.

## Compact mapping toolbar runtime verification

Rebuilt the explicit native preview with the latest toolbar source. Opened the handwriting source-mapping state, clicked image zoom 100% to 150%, then Restore full image and confirmed 100%. All 16 saved blocks remained present and the leading 2 remained intact. Screenshot mapping-native-compact-toolbar-handwriting.png inspected; the compact 12/11 pt toolbar replaces the previous large context card. Updated the 15-page audit to remove the now-resolved image-state verification gap while retaining the missing full same-data pixel comparison. Backend baseline unchanged; audit remains 16 historical events, zero new AI requests. No code changes required beyond the previous built toolbar.

## Import gateway type labels

Matched source section spacing at 24 pt and compact command-title spacing at 4 pt. Added source-style 10 pt mono upper-right tags describing existing picture/PDF, math-text, system-camera, and original-stroke entry points. Corrected the paste and camera Material icons. Existing import actions and input handling are unchanged; no fake clipboard detection, connected-device state, preprocessing toggles, or automated translation were added. Preview build passed and screenshot imports-native-type-badges.png inspected in the native window. Backend baseline unchanged, AI audit remains 16 historical events; zero new AI requests. Full import queue styling and source-matched 15-page pixel acceptance remain incomplete.

## Import queue header and rows

Matched the source low-surface 16 pt header band, 40 pt素材 icon, 20 pt row padding, 14 pt heading, and 12 pt summary. Existing queue content and actions preserved; no simulated progress, failures, timestamps, or filters copied as real states. Preview compiled and screenshots/imports-native-queue-header.png inspected. Clicked the row 校对 action; native accessibility confirmed recognition page, current fragment 1/1, with the complete recorded original text retained in the editor. Backend unchanged, audit remains 16 historical events, zero new requests. Multiple-fragment queue and full source-matched 15-page pixel acceptance still pending.

## Multi-fragment import queue and human math

Inspected all 16 saved handwriting fragments in original order and clicked fragment 2 校对: native recognition editor showed exactly the original leading-2 formula and current fragment 2/16. Found raw LaTeX visible in queue summaries, replaced their Text with the existing conservative read-only MathText presentation. Source payload and editing text are unchanged. Preview compiled; screenshot imports-native-human-math-queue.png confirms readable math and leading 2 in the queue. Unsupported LaTeX still falls back to original text; full mathematical typesetting remains a separate visual gap. Backend unchanged, audit remains 16 historical events, zero new AI requests. Full 15-page visual acceptance remains incomplete.

## Import compact action dimensions

Audited the common button implementation against source import actions. Added an optional compact presentation (12 pt medium text, 12/6 pt horizontal/vertical padding, 6 pt gap, low-surface secondary fill) and applied it only to import header, queue review, and gateway actions. Other page default dimensions remain unchanged. Explicit native preview compilation passed. No runtime screenshot for this latest compact-button edit yet; screenshot verification remains pending. Backend baseline unchanged; audit remains 16 historical events, zero new requests. Full 15-page acceptance remains incomplete.

## Compact import actions native screenshot

Reloaded the already-built latest preview and opened import via the native sidebar. Screenshot imports-native-compact-actions.png inspected: compact command, gateway, and row-review buttons render with the source reduced padding and light secondary fill, no clipping observed in this viewport. Updated the import row of the 15-page visual audit to reflect verified queue and typography progress. No uploads, recognition submissions, or proof verification actions executed. Backend baseline unchanged; audit remains 16 historical events, zero new AI requests. Full identical-data 15-page acceptance remains incomplete.

## Ambiguity context proportions

Read the original source microscope/context layout (5:7, 20 pt gap, left padding16/right20, 12 pt rounded panels). Changed the native equal-width split to source 5:7 using measured panel width; corrected context radius from 4 to 12 and section headings to 12 pt bold. Candidate data, manual choice, and original input preservation unchanged. No confidence percentages, automatic recommendations, batch adoption, or undocumented shortcuts added. Runtime screenshot for this latest edit remains pending; full 15-page acceptance remains incomplete. Backend baseline unchanged; AI audit remains 16 historical events, zero new requests.

## Ambiguity split runtime QA

Rebuilt preview and navigated to the explicit synthetic n/pi ambiguity state. Selected candidate pi; native accessibility showed only the candidate selection change, retained original mathematical text and ambiguity page, without invoking confirmation or verification. Screenshot ambiguity-native-context-proportions-selected.png inspected: source 5:7 context layout, 12 pt headings and rounded panels visible. This synthetic ambiguity is a UI test, not an actual recognition finding. Image-backed ambiguity and full same-data 15-page pixel comparison remain unverified.

## Ambiguity recessed manuscript reference

Replaced the redundant large standalone page heading with the source recessed context-document layer: white 80% surface, 24 pt padding, 70% layer opacity, 11 pt mono reference tag, 12 pt context/read-only label, divider, and 14 pt human-math proposition summary. Original Lean example syntax was not copied into the default human-math page. Candidate selection and confirmation binding unchanged. This latest layer requires a fresh runtime screenshot; full 15-page visual acceptance remains incomplete. Backend baseline unchanged; AI audit remains 16 historical events, zero new requests.

## Recessed ambiguity reference runtime inspection

Rebuilt the current explicit fixture preview and opened the synthetic ambiguity state. Inspected screenshots/ambiguity-native-recessed-reference.png: top read-only human-math reference is visually recessed at 70% opacity; front confirmation remains full contrast with 5:7 manuscript/context and two candidate cards. Original text remains unchanged. This verifies the text-only synthetic state; image-backed ambiguity and all-page identical-data pixel comparisons remain pending. No AI or Kernel execution.

## Bundled font resolution audit

Ran a local CoreText audit over all bundled TTF descriptors and registered them in process. Resolved Manrope to Manrope-Medium, Inter to Inter-Regular, and Times New Roman to TimesNewRomanPSMT; bundled JetBrainsMono-Regular was present. The initial direct Swift interpreter invocation hit the known SDK bridging module collision; reran with the project VFS overlay and absolute module cache, audit exit 0. Changed only Lean-code presentation from system mono 12 pt to bundled JetBrainsMono-Regular 11.5 pt per source inspector. A fresh screenshot for this font change remains pending. No Provider, MathIR, or Kernel changes; full 15-page pixel acceptance remains incomplete.

## JetBrains inspector font runtime verification

Rebuilt explicit preview and opened the formal inspector using saved proof data. Selected p1 and inspected screenshots/formal-details-native-jetbrains-mono.png: JetBrains Mono 11.5 pt source style, line-number alignment, syntax colors, and block highlight remain visible. Scrolled horizontally and observed native scroll value change from 0 to 0.869. No code execution or Provider call. Audit remains 16 historical events. Complete all-page same-data visual acceptance remains pending.


## Workspace theorem paper — native QA

Compared the workspace source article, metadata, and theorem card in Stitch export 6245364fd70c4585a7a02958ec2fa0f5. The native recorded-proof area now uses a white paper container with 32 pt inset, 24 pt section gaps, 28 pt heading, and a recessed theorem card with 20 pt inset, 12 pt heading, and 18 pt human-mathematics text. All text and step states come from the existing record. Existing draft editor and step navigation remain bound to the same store.

Executed: native preview compilation; opened native workspace; inspected AX state and screenshot workspace-native-theorem-paper.png. No AI submission was performed. This is local saved-response UI QA, not new Kernel verification. Full same-data, same-viewport pixel parity remains pending; source compact proof body and workspace editor composition still differ.


## Workspace compact proof body — native QA

Replaced workspace-only result cards with a source-aligned proof body: 4 pt status stripe, 16 pt leading inset, 8 pt inner gaps, 12 pt step heading, 10 pt state badge, and 14 pt mathematical content. Result-page ProofCard remains unchanged. Status and content are taken from the existing ProofRow; no new proof or verification is inferred. Added task_alt and error_outline mappings after screenshot inspection found the fallback architecture glyph. Bundled font cmap confirmed task_alt U+E2E6 and error U+E000.

Executed: native preview compilation and screenshot inspection after icon correction; all four saved steps visible in compact body; first detail action opens step 1 with original source and dependencies. Evidence: screenshots/workspace-native-compact-proof-body.png. No Provider submission performed. Full workspace composition and same-data/same-viewport pixel comparison remain pending.


## Workspace centered theorem — native QA

Fixed the visible alignment mismatch against the Stitch theorem declaration: MathText now accepts an explicit centered presentation option (default remains leading), and only the workspace theorem formula opts in. No mathematical text or record is transformed by this alignment setting. Native preview compilation and actual screenshot inspection confirmed centered theorem and unchanged leading proof body. Evidence: screenshots/workspace-native-centered-theorem.png. Full 15-page same-data pixel parity is still pending.


## Workspace outline and desktop paper dimensions

Read source workspace HTML: outline p-4, gap-3, 18 pt icon, 12 pt bold header, 10 pt count, p-2 nodes; desktop article p-10 and 30 pt title. Native implementation now uses these dimensions. Outline has a client-local text filter, actual established/total count, state glyphs, 12 pt step titles, 10 pt human-readable mathematical summaries, and clear inactive row backgrounds. Original source theorem examples are not substituted for user records.

Executed native build and UI inspection. Entering Steps 2 (Chinese label) leaves only original step 2, clearing restores all four original indices; saved proof body remains unchanged. Screenshots: workspace-native-outline-filter.png, workspace-native-outline-source-density.png, workspace-native-paper-source-insets.png. Desktop paper inset/title visibly updated. No AI submission performed. Workspace toolbar, column composition, and complete same-data/same-size comparison remain outstanding.


## Workspace proportional outline

Replaced fixed 184 pt outline width with a measured content-width quarter, preserving 24 pt column gap and a 184 pt minimum for narrower windows. Geometry updates only presentation state; no Provider or workflow action is attached. Native preview compilation and actual desktop screenshot confirmed wider outline and readable summaries. Evidence: screenshots/workspace-native-proportional-outline.png. Window resize behavior is implemented but not yet explicitly exercised; complete source three-column composition and 15-page same-data parity remain pending.


## Workspace explicit inspector three-column layout

Moved the existing NativeEngineering view from the bottom of the document to the right-hand column when the existing explicit showEngineering setting is on. Measured content width now assigns quarter-width outline and inspector, 24 pt gaps, and the remainder to mathematics. Default false remains unchanged. No new controls or API bindings were added.

Executed: preview compilation; preferences switch off-to-on; workspace screenshot confirming three columns; MathIR tab displays saved IR and Lean tab restores saved source; switch on-to-off and workspace inspection confirms inspector absent and wider mathematical canvas. Evidence: screenshots/workspace-native-three-columns.png and workspace-native-inspector-hidden.png. Existing record remains saved-response UI evidence, not a new Kernel result. Full same-data pixel fidelity remains pending.


Additional executed check: native window zoom changed screenshot dimensions from 2560x1800 to 3456x2030 pixels. The outline expanded proportionally and the mathematical canvas stayed within the window; original four steps and saved draft remained present. Screenshot workspace-native-resized-outline.png inspected. Restored window using native zoom action. This supersedes the earlier note that resize behavior was not exercised. Official UI-only Mac App rebuild completed successfully.


## Workspace proof-first composition and command bar

Re-read Stitch workspace command bar and proof-paper hierarchy. Workspace now uses a compact white toolbar (24 pt horizontal, 10 pt vertical padding; 16 pt title) with existing import/verify and edit navigation bindings. An existing record renders the mathematical paper immediately rather than placing a duplicate full-draft editor above it. Record-free drafts retain the input editor and handwriting action. This only changes client presentation; editing and verification semantics are unchanged.

Executed: native preview compilation, proof-first screenshot inspection; edit action opens complete unchanged original draft; blank-draft action shows empty original input editor with no fabricated proof. Transient AX observation failures were resolved by rereading the same app handle, without restarting. Evidence: screenshots/workspace-native-proof-first.png and workspace-native-blank-input.png. No verify action executed. Complete same-data pixel comparison remains outstanding.


## Native Material Symbols audit and page-specific brand

Audited literal StitchIcon references against native codepoint mappings and bundled font cmap: no missing literal mappings. file_upload maps to the font upload alias; no missing glyph. Read all 15 source exports brand symbols. Workspace, editing, camera, and recognition exports use functions rather than the shared architecture glyph. Sidebar now chooses functions on these four routes; added U+E24A from bundled font cmap. Other routes retain prior brand.

Executed: native preview compilation; home AX confirms architecture; workspace AX and inspected screenshot confirm functions glyph. Evidence: screenshots/workspace-native-functions-brand.png. Remaining three affected routes are implemented but not individually screenshot-tested this turn. No Provider request. This audit covers glyph names and mapping, not complete 15-page pixel fidelity.


## Workspace source thumbnails

Compared Stitch source-asset cards: 48x40 thumbnails, 10 pt image/text gap, 8 pt row inset, 11 pt title, 10 pt summary. Native outline source rows now render actual asset thumbnails with these dimensions. Same assetId appears once in the source outline and displays its actual recognition-fragment count; all non-image blocks remain separate. This is a presentation projection only; sourceBlocks and provenance are not mutated. Read-only summaries use existing MathPresentation.

Executed: preview compilation, handwriting fixture selected, workspace shows one actual image thumbnail with 16 fragments; screenshot inspected (workspace-native-source-thumbnail.png); clicking source opens existing recognition page with 16 blocks. Original draft still shows the confirmed leading 2 in method 1. No recognition or Provider request performed. Exact source crop is not emulated: full original image is shown, consistent with current step-level provenance. Complete 15-page pixel parity remains outstanding.


## Updated complete 15-page native capture baseline

Executed capture of all 15 explicit saved-response routes at a uniform 2560x1800 physical-pixel window: each includes PNG and AX snapshot under screenshots/review15/, plus checksummed manifest.json. Page picker title was checked at every transition. No business-submit action, camera activation, or Provider call was performed. Captures replace obsolete snapshots as current visual evidence, not as a fidelity pass. Inspected recognition, verifying, and success screenshots directly. Other captures are recorded but not yet individually visually compared in this pass.

Re-read formal-details code container: source HTML specifies horizontal overflow and natural height, not a fixed-height scrolling editor. Therefore long native source height alone does not justify imposing a viewport absent from the Golden Master. Same-data comparison is necessary before changing this behavior. Complete source-to-native equality remains unproven.


## Recognition compact proofreading toolbar

Re-read recognition Golden Master secondary header: white background, 24 pt horizontal/12 pt vertical padding, 12 pt title, 15 pt fact_check icon, compact count capsule, right actions. Replaced tall contextual banner with this hierarchy. Counts reflect actual recognition blocks; no invented aligned regions, confidence, version history, or automatic re-recognition. Import and camera controls bind existing explicit routes only. Added fact_check U+F0C5 from bundled font cmap.

Executed native preview compilation and handwriting fixture screenshot inspection. Toolbar shows actual 16 fragments; original image and method-1 leading 2 remain visible below. Evidence: screenshots/recognition-native-compact-toolbar.png. Existing selected-fragment editor and save binding retained; no save or verification action performed this turn. review15 snapshot is now historical for recognition. Full same-data pixel fidelity remains pending.


## Recognition source desktop column widths

Golden Master recognition grid specifies 340 pt source column, minmax(640 pt, 1fr) center, 330 pt inspector, and 24 pt gaps. Native source/inspector now use the exact desktop widths once 1358 pt content is available; below that, scale using the source 340:640:330 proportions with readable minimums. No input or workflow semantics changed.

Executed: native build, handwriting fixture, standard-window screenshot, native zoom to wider 3456x2030 screenshot and visual inspection, then restored window. Both show all three columns, complete selected editor and unchanged source image/16 fragments. Evidence: screenshots/recognition-native-columns-standard.png and recognition-native-columns-wide.png. Same-source-data pixel comparison remains outstanding.


## 原生识别卡标题与源码字体回查

按 Stitch recognition 原始 HTML，原稿对照标题使用 crop_free 17、间距 6、底部留白 8 与细分隔线；原文编辑器使用 JetBrains Mono 14、水平内距 14、垂直 10。保留完整原文编辑，不自动改写数学内容。

SwiftUI 预览实际重新启动，手写图片及 16 个保存片段显示正常，前导 2 保留；截图 screenshots/recognition-native-header-editor.png。预览编译与正式 App 的 UI-only 重建通过，后端 36 文件校验无变化，审计事件仍为 16（本轮新增 AI 0）。此为 UI 显示检查，不是新 AI/Kernel 验证。全 15 页同数据同尺寸视觉验收仍未完成。


## 识别页独立放大对照卡

恢复 Stitch 左栏两张卡的结构：原图总览内距 12、视口 224；下方独立放大卡视口 176、初始 300%，使用真实原图，手动缩放和拖动，不绘制虚假的精确笔画选区、置信度或坐标。SourceImage 默认初始倍率仍为 100%，仅识别页放大卡指定 300%。

实际重启 SwiftUI 预览，加载手写图片及保存的 16 片段，截取并查看 screenshots/recognition-native-loupe.png。独立放大从 300% 到 450%，恢复全图到 100%，上方总览保持 100%；原文前导 2 保留。预览编译、正式 UI-only App 重建和签名检查通过，36 个后端文件不变，审计事件仍为 16，本轮新增 AI 0。未执行新 AI、Lean Kernel 或全 15 页同尺寸视觉验收。


## 工作区侧栏品牌区与导航尺寸

对照 workspace 原始 HTML：品牌区高度 56、水平内距 20、图标容器 28/字形 18、品牌间距 12，并恢复 10 号等宽副标题。工作区导航图标 18、内距 12/8、行间距 4；活跃行改用原设计的浅灰背景及深色文字。其他页面保留各自样式，未加入原型中的未实现资源功能。

实际重启预览、进入数学工作台，截图 screenshots/workspace-native-sidebar-metrics.png 已查看，品牌副标题完整显示、主工作区活跃状态正常。预览编译与正式 UI-only 重建通过，签名验证通过，后端 36 文件不变，审计事件仍 16，本轮新增 AI 0。全 15 页逐项同数据同尺寸视觉验收仍未完成。


## 验证页原稿卡标题栏

按 verifying 导出，原稿卡恢复顶端浅灰独立标题栏：内距 16，图标 18，标题 12 semibold；正文卡内距 24，内层 12。五阶段卡标题到描述间距改为源 mb-1.5 对应的 6。不复制原型的虚构百分比、毫秒、进程 PID 或自动补引理描述；保留任务真实事件状态。

重新启动 SwiftUI 预览，明确选择验证进行中 fixture，实际截图并查看 screenshots/verifying-native-document-header.png。预览编译、正式 UI-only App 重建及签名验证通过；后端 36 文件未变，审计仍 16 事件，新 AI 0。此次仅 UI 显示验证，未重新调用 AI/Lean；15 页同数据同尺寸对照仍待完成。


## 失败步骤卡视觉状态

对照 failure 原始导出：未完成步骤头部状态改为红底白字 11 medium、水平 8/垂直 2 的胶囊，而非警告黄色状态；当前数学陈述子卡增加原设计 account_tree 16 图标及间距 6。仍显示实际“尚未证明”，不擅自归因为逻辑错误或伪造 OCR 置信度。

重启 SwiftUI 预览并选定未完成证明 fixture，查看 screenshots/failure-native-step-badge.png，显示 3/4、内核尚未通过、红色未完成步骤。预览编译、正式 UI-only 重建和签名检查通过；36 后端文件未变、审计仍 16 事件，新 AI 0。不是新的模型或 Kernel 检验，15 页同数据同尺寸验收尚未完成。


## 原稿对应页纯文本与标题图标

源码确认 mapping 为等宽三栏（col-span-4 / gap-3），保留现有三栏布局。原稿栏与识别栏标题改用源 raw_on / spellcheck 18，字形已从捆绑字体 cmap 核对。无图片的文本记录直接显示完整数学原稿，替代 470 高的空图占位；有图记录仍显示真实原图，不新增坐标/笔画定位能力。

实际重启预览选映射页，步骤 1 切到 3，原稿文本保持、右栏陈述与对应原文更新，截图 screenshots/mapping-native-text-manuscript.png 已查看。预览编译、正式 UI-only 重建、签名验证通过；36 后端文件不变，审计仍 16 事件，新 AI 0。尚未完成全 15 页同数据同尺寸 1:1 验收。


## 欢迎页底部三张说明卡

直接查看欢迎页 Stitch 原始截图并读取原始 HTML，补齐底部三列说明卡：顶距 32、列距 20、卡内距 20、图标容器 40/字形 20、图文距 16、标题 14 bold、正文 12/行距 4。translate / psychology / format_image_left 字形均核对字体 cmap。文案对应真实现有能力，不复制原型的“100% 不上云”、秒级转换、50000+ 数量或未实现快捷检索承诺。

实际重新启动预览并滚动到底部，截图 screenshots/welcome-native-feature-cards.png 已查看，三张卡与正文正常显示。预览编译、正式 UI-only App 重建及签名检查通过；36 后端文件未变、审计事件仍 16，本轮新 AI 0。三卡受真实文案换行影响高度仍有差异；欢迎页中段结构也尚未等同原设计的交互演示，未报告为 1:1 完成。


## Welcome proof preview and dependency graph

Restored the source 7:5 manuscript / dependency split, padding 28, heading 16, subtitle 12, divider spacing 20, panel gap 24. The graph renders actual ProofRow.dependencies with all nodes; manual node selection opens the existing detail page. No automatic premise completion or fake verification. Empty records show an honest unverified state.

Recompiled and restarted the native preview, inspected screenshots/welcome-native-proof-graph.png. Corrected edge layering so lines render beneath all node labels, rebuilt and captured again. Clicking node 3 opened its detail with the two matching dependencies. Preview build, official UI-only build and signature verification passed. Backend 36-file hashes unchanged; audit events remain 16, new AI requests 0. Full 15-page same-data/same-size fidelity acceptance remains incomplete, including prototype example selector/content differences.


## Editing side-by-side diff

Restored the Stitch side-by-side comparison rather than vertically stacked previous/current text. Two panes: gap 8, padding 10, heading 10, content JetBrains Mono 11; splitscreen 18 glyph verified against bundled font. TextRevisionDiff and edit invalidation remain unchanged.

Restarted the native preview and selected Editing. Appended a local fixture note: added count became 1, original remained unchanged. Restored original with the existing button: added count returned to 0. Screenshot screenshots/editing-native-side-by-side.png inspected. Preview and official UI-only builds and signature verification passed. Backend 36 hashes unchanged, audit remains 16 events, 0 new AI. Full 15-page fidelity acceptance remains incomplete.


## Camera columns

Matched the source 8:4 columns and gap 20: replaced the fixed 280-point right pane with one third of available width, preserving the existing 4:3 video viewport. Restored account_tree 16 / gap6 / heading12 bold in manuscript card. Camera lifecycle and explicit enable/capture actions unchanged.

Restarted native preview and selected Camera. Screenshot screenshots/camera-native-proportional-columns.png inspected, camera remains not enabled; no permission prompt or AI request. Preview compilation, official UI-only rebuild and signature checks passed. Backend 36 hashes unchanged, audit remains16, new AI0. Physical capture and full15-page same-data fidelity acceptance remain unverified.


## Preferences size presets

Restored source 14/16/18 font-size selection group: gap6, outer padding4, container background, buttons font12 and vertical padding6 with white selected background. Existing slider retained; lower end extended to14 for consistency with the source preset, default19 remains unchanged. No provider or verification logic modified.

Native preview restarted; selected16 and14, label/slider/live preview stayed synchronized. Restored default19. Screenshot screenshots/preferences-native-size-presets.png inspected. Preview build, official UI-only rebuild and signature verification passed. Backend36 hashes unchanged, audit16, newAI0. Full15-page same-data visual acceptance still incomplete.

## Current fifteen-page capture and import footer

Captured all 15 native fixture pages in screenshots/review15-current with AX states and manifest. These are structural review evidence, not a same-data pixel-fidelity acceptance. Replaced the oversized import drop placeholder with a compact 16-point status bar; root file-drop binding is retained. Actual native screenshot: screenshots/imports-native-compact-footer.png. No unsupported Metal or memory statistics were introduced. Backend baseline checked unchanged; AI audit remains at 16 historical events. Native preview compiled and the footer was observed in the running app.

## Ambiguity context viewport alignment

Compared the original exported HTML microscope h-44 (176) against the native 220-point viewport. Native source and math context viewports now use 176 points. A text-only manuscript displays the saved source block text (or the retained draft) instead of a blank image placeholder; the full text remains scrollable. Candidate selection was observed on the running native preview (second candidate selected). Screenshot: screenshots/ambiguity-native-compact-context.png. Candidate cards move upward, but the confirmation action still needs scrolling at the captured window size; full first-viewport fidelity is not achieved. Preview and official UI-only builds succeeded. The 36 backend baseline files are unchanged and the AI audit still has 16 historical events, with no new provider calls.

## Welcome quick input native single-line experiment (rejected)

An AppKit NSTextField configured with usesSingleLineMode compiled and retained the existing multiline string during initial display, but a real native clipboard paste flattened line breaks into spaces, observable in both AX value and the draft preview. The implementation was removed and the prior SwiftUI field restored before packaging. Do not use this configuration for manuscript input. The homepage field visual issue remains open; a replacement must preserve original newlines through paste, editing, and navigation. No provider call was made; the experiment screenshot is not acceptance evidence.

## Welcome non-editing preview preserves manuscript

SwiftUI TextField lineLimit(1) also flattened multiline binding in native observation and was rejected. Kept the original multiline-preserving editable field; only the non-editing display uses a derived single-line Text preview, with no write-back. The field remains in the accessibility tree when unfocused. Native clipboard paste of a three-line square-nonnegativity proof retained all three lines in the field and workspace editor, and after navigation back. Final build was reopened and unfocused AX value retained the full saved manuscript and prior verification record. Screenshot: screenshots/welcome-native-preserved-line-preview.png. Preview and official UI-only builds succeeded. Editing presentation still uses the existing compact field and requires further fidelity review. Backend unchanged (36 baseline files), audit remains 16 historical events, no new AI requests.

## System status header action alignment

Original exported status header uses a horizontal action group with 10-point spacing and compact buttons. Native header used a vertical full-width pair. Converted the existing return/export actions to a compact horizontal group with 10-point spacing. Preserved actual state data and existing actions; no prototype retry, alternate-provider, recovery ETA or fabricated hardware state was introduced. Screenshot: screenshots/system-native-horizontal-actions.png. Preview and official UI-only builds succeeded; native AX confirmed both actions and collapsed diagnostics. Backend baseline unchanged; audit remains 16 historical events. Full status-page fidelity is still unproven because source prototype content differs from real application state.

## System card content/action structure

Separated all four status-card content and action builders. Source-style explanation panels now have 12-point padding and 8-point radius on the low surface, card stack spacing is 12, actions have a separate 12-point top inset and compact buttons. Removed arbitrary 140-point content minimum causing blank space below the buttons. Grid cells align at their top edges. Native screenshot: screenshots/system-native-card-panels.png. Confirmed diagnostic disclosure stays closed by default and reveals only the explicit fixture diagnostic when manually expanded. Native preview and official UI-only builds succeeded. Backend baseline unchanged, AI audit remains at 16 historical events. Cards have different natural heights with real content; source equal-row stretching remains to align. This is not full fifteen-page fidelity acceptance.

## System equal row stretching

Replaced the status grid with two intrinsic-height horizontal rows. Each card stretches its internal vertical stack to the row height and anchors its existing action at the bottom using a zero-minimum spacer. Each column receives exactly (available width - 16)/2 from measured panel width, avoiding content-dependent width variation. Running native preview confirms equal bottom edges and aligned buttons for both pairs; screenshot screenshots/system-native-equal-row.png. Existing content and route actions are unchanged; diagnostic disclosure remains closed. Preview and official UI-only builds succeeded. Backend baseline unchanged, audit still 16 historical events. Full fifteen-page visual acceptance remains outstanding.

## Fifteen-page outer geometry source inventory

Saved source HTML layout candidates and hashes for all 15 screens in page-geometry-source-audit.json. This inventories outer/container classes, not pixel acceptance. Compared native root per-page maximum widths and padding to exported classes. Source-mapping export uses px-4 (16), while the native root inherited 24; gave sourceMapping a dedicated 16-point horizontal inset. Running native screenshot screenshots/mapping-native-page-inset.png confirms three-column content and step navigation remain present. Native preview and official UI-only builds succeeded. The backend baseline remains unchanged and the AI audit remains 16 historical events. Full source/native same-data and same-viewport comparison remains outstanding.

## Actual browser-rendered fifteen-screen source baseline

Served original Stitch exports read-only on localhost:4393 and rendered all 15 in the in-app browser at CSS viewport 1280x900. Full-page JPEG screenshots and DOM viewport/main geometry, source hashes, background color, font-ready state are saved in screenshots/stitch-rendered-1280/manifest.json. All 15 font states are loaded after revisiting the two initially loading cases. Ordinary screenshot was clipped to 1109 pixels despite DOM viewport 1280; full-page screenshot covers the actual 1280 width, so ordinary capture was rejected for width comparison. Browser viewport override was reset. Source prototype data and browser chrome differ from native fixture content and native window chrome; these captures are a source baseline, not same-data pixel acceptance. This turn changed no product source and made no AI requests; backend unchanged, audit 16 historical events. Native source mapping and welcome need structural comparison against these rendered originals.

## Welcome equal feature row and footer

Compared the actual 1280-wide browser source baseline. Native feature cards now use equal measured thirds with 20-point gaps and row-height stretching, preserving all descriptive text. Added the missing footer hierarchy: 48-point section margin, divider, 24-point top gap and 16-point bottom padding, actual service readiness and existing new/import/preferences actions. Shortcut labels reflect NativeApp commands (N/O/comma), not unsupported prototype K/help or invented performance/version data. Explicit zero minimum width prevents the measured columns from stretching the root beyond the available window. Final running screenshot screenshots/welcome-native-equal-features-footer.png shows sidebar unclipped, all three card bottoms aligned and footer visible. Footer preferences navigation was observed and engineering switch remains off. Preview and official UI-only builds succeeded. Backend unchanged; AI audit remains 16 historical events. This does not accept the full fifteen-screen objective.

## Result dependency rail and action hierarchy

Compared browser-rendered success and failure originals. Moved source mapping/export actions to the compact top command row and removed duplicate summary actions. Success rail now begins with the original-proof dependency graph, using existing record rows/dependencies; no synthetic edges or AI requests. Shared native graph also remains on welcome. Screenshot screenshots/success-native-dependency-rail.png records the running result. Clicking step 3 navigated to native step detail with actual two preceding dependencies; AX evidence screenshots/success-dependency-step3.ax.txt. Preview and official UI-only build succeeded (exit 0). All 36 backend baseline hashes unchanged; audit remains 16 historical lines (zero new AI requests). Outstanding: graph currently horizontal while the source result graph is vertical; failure diagnostic rail and full fifteen-page same-data visual acceptance remain unfinished. Build success is not visual acceptance.

## Result layered dependency topology

Replaced success-only horizontal node positions with native vertical layers derived from actual dependencies. Independent ready nodes share a row; dependent nodes appear below. Unknown dependencies do not create invented nodes; cyclic records remain visible without invented edges. Welcome retains its existing horizontal preview. Node widths follow each layer column and graph height follows layer count. Running screenshot screenshots/success-native-layered-dependencies.png shows actual steps 1/2 converging to 3 then 4. Preview and official UI-only builds succeeded. Backend hashes unchanged; audit still 16 events (0 new AI). Source prototype has additional fictional theorem nodes; these were not fabricated. Failure rail and full fifteen-page acceptance remain outstanding.

## Failure inspector hierarchy

Implemented source three-card right rail: four factual status rows, original open-step comparison (96-point minimum), and actual dependency graph (96-point height), then edit/detail/explanation actions. Data derives only from existing record; no fictional OCR confidence, attribution code, automatic premise adoption, retry, or incremental verification promises. Existing generated explanation items/suggestions remain renderable conditionally. Engineering raw status is hidden. Running fixture screenshot screenshots/failure-native-inspector-rail.png confirms layout; this is a synthetic failure UI fixture, not a new failed Lean run. Material rule glyph verified from bundled font cmap f1c2 and added after screenshot. Final official UI-only build succeeded. All 36 backend hashes unchanged, audit remains 16 events, 0 new AI. Remaining fidelity gaps include compact graph node style and whole-page same-data/viewport acceptance; fifteen-screen goal remains open.

## Compact failure graph nodes

Aligned failure graph to source compact 64-point pipeline: 28-point circle state icons, 9-point labels, equal positions, actual edges, and red dashed incoming edges for unestablished targets. Nonadjacent edges curve above intermediate nodes rather than imply false sequential dependencies. Welcome/result layouts remain distinct. Screenshot screenshots/failure-native-compact-topology.png shows actual fixture graph; clicking failed step 1 opened step detail with unproved status and zero recorded predecessors. Preview and official UI-only build succeeded. Backend unchanged; audit remains 16 historical events, no new AI. Fixture is explicitly synthetic failure state. Full fifteen-page same-data acceptance is still outstanding.

## Refreshed complete native inventory

Captured all 15 current native routes, full AX trees and screenshots under screenshots/review15-refreshed. Manifest marks each not_accepted and fixture=true. Compared ambiguity/editing source/native images; editing structure is present but fixture focus differs from source (1 versus 3), so next comparison must match focus rather than rearrange correct layout. Added 15页当前采集记录.md linking every capture and documenting evidence limits. Backend unchanged; audit 16 historical events, zero new AI. No product source changed this turn.

## Ambiguity focus and remaining list

Aligned source hierarchy: fixed spellcheck/18-point title, separate 11-point actual message, count, current panel, horizontal actual ambiguity list and compact footer actions. Focus selects one existing ambiguity rather than stacking full panels; count/list retains all records, no cap or review requirement. Switching clears current candidate only; original explicit resolve action unchanged. Running synthetic n/pi UI fixture selection observed; footer screenshot screenshots/ambiguity-native-focused-footer.png and main screenshots/ambiguity-native-focused-list.png. Current fixture has one ambiguity, so multi-item switching is implemented but not claimed runtime-verified. Preview and final official UI-only builds succeeded. Backend unchanged, audit16, no new AI. Fifteen-page full acceptance remains outstanding.

## Editing three-card inspector

Added source missing right-rail dependency and revision cards below side-by-side comparison, 16-point gaps/padding and 8-point corners. Actual prior proof dependencies, prior established count, selected step and current versus pre-edit text are shown; no invented cache/timing/version claims. Clicking recorded step 3 confirmed preceding rows 1/2 above focused editor and row 4 below. Screenshots screenshots/editing-native-three-cards-step3.png and editing-native-history-card.png inspected. Hide comparison removes all three inspector cards while preserving the native TextEditor; observed AX booleans true. Preview/official UI-only builds succeeded. Backend unchanged and audit16, zero AI. Full fifteen-page 1:1 acceptance not established.

## Recognition goal and open-step full structure

Added recognition center goal target card only when a real existing record has a nonempty goal; no theorem invention before structure. Open-step page now has source bottom two-part explanation panel, explicit collapsed diagnostic disclosure, right top explanation/edit action, and source image preview only for actual associated asset (otherwise actual original text). Explanations use recorded message and original/goal, not invented AI repair schemes, counterexamples, premises or attributed failure. Running captures recognition-native-math-target.png, step-native-open-inspector.png and step-native-explanation-bottom.png inspected; disclosure observed off. Synthetic failed step fixture is UI evidence only. Final status color correction uses existing unproved state (error badge/dot) after screenshot; compiled in final official build but screenshot precedes that color change. Preview and final official UI-only builds succeeded. Backend unchanged, audit16, zero new AI. Source-mapping requires separate final comparison; full fifteen-page acceptance remains unproven.

## Mapping selected original and operation footer

Compared source three-column/items-start layout; preserved independent column heights (did not incorrectly stretch equal heights). Added actual selected-step original card above source-block list, moved left source precision tip into separate lower card, and added source-style full-width operation footer with existing edit/detail routes. Middle proofreading routes to existing recognition view; no new recognition request. Unproved navigation dot derives existing status. Selecting step 3 visibly updated both selected-original and math statement; footer detail opened step 3 preserving its original. Screenshots mapping-native-selected-original-step3.png and mapping-native-operation-footer.png inspected. Preview and official UI-only builds succeeded. Backend unchanged; audit16, zero new AI. Whole-page data/viewport and fifteen-screen acceptance still outstanding.


### Native preferences font cards (2026-10-07)

Added the source three-column font choice card as SwiftUI buttons, with actual bundled KaTeX Main, Latin Modern Math (Computer Modern family), and Euler Math fonts. Preferences explicitly labels the Latin Modern implementation. Font selection changes presentation only; the existing default remains Times New Roman until a user selects a font. CoreText registration now includes OTF in official and preview targets. Fonts and upstream licenses are bundled. No OpenType MATH layout engine or full TeX renderer is claimed.

The explicit fixture preview compiled successfully; accessibility verified Euler selection and restoration of display defaults. Screenshot: `screenshots/preferences-native-font-cards.png`. This is UI fixture evidence, not a new AI or Kernel validation. Backend baseline remains unchanged; AI audit remains 16 historical lines. Further page-level visual alignment remains outstanding; this does not establish 15-page 1:1 acceptance.

Official UI-only build also completed successfully, reusing the unchanged packaged backend. Strict deep ad-hoc signature verification passed; executable links SwiftUI and not WebKit. Developer ID signing/notarization was not performed.


### Native preferences formula preview (2026-10-07)

Replaced the unrelated current-record formula preview with the original Stitch Dirichlet typography sample, built with SwiftUI integral limits and stacked fractions. Added the 20-point grid, font/size chips, and three preview-only highlight choices (20/45/75%). The sample is explicitly labelled as typography rather than Kernel evidence. No backend rules or AI paths were changed. This is a fixed sample renderer, not a general LaTeX/OpenType MATH engine.

Preview build passed. Native accessibility verified 45%→75%→45%, Computer Modern selection updating the Latin Modern chip, and 19→14→19 pt. Defaults were restored. Screenshot: `screenshots/preferences-native-integral-preview.png`. Backend baseline unchanged; AI audit remains 16 historical lines (0 new requests). Fifteen-page same-data visual acceptance remains outstanding.

Official UI-only app rebuild completed; strict deep ad-hoc signature verification passed. No Developer ID/notarization or new AI/Kernel run was performed.


### Native display-only fractions (2026-10-07)

Added SwiftUI rendering of delimited frac/dfrac/tfrac, including nested fractions. Plain supported math uses the existing conservative presentation adapter; malformed or unknown syntax retains the original line. Wide fraction lines scroll horizontally. The parser never edits raw recognition, MathIR, statement, or provider inputs. Accessibility exposes the original formula; the raw editor retains selectable source. This is partial native typesetting, not complete TeX support.

An explicit preview-only fraction fixture uses the pre-existing ambiguous raw response; its Δ denominators remain unconfirmed and are not claimed as recognized truth. Screenshot `screenshots/recognition-native-fractions.png` verifies leading 2 and both stacked fractions. The default saved transcription does not contain these denominators; no production recognition record was replaced.

`python3 scripts/check_native_fraction_display.py` compiled the actual Swift parser and passed: leading 2, both denominators, nested fractions, malformed fallback, unknown-command fallback, plain-text fallback. Backend baseline unchanged and audit stays at 16 historical lines (zero new AI). Full 15-page visual acceptance remains outstanding.

Official UI-only build and strict deep ad-hoc signature verification passed. No new AI, Lean or Kernel verification was executed.

Final preview rebuild passed. One-click fraction fixture loading from the home screen verified selected block 2/16, leading 2, and explicit non-verification label; final screenshot refreshed.


### Workspace default three-column bindings (2026-10-07)

Restored the source 3:6:3 proportions and 24-point gaps when a proof record exists, even with engineering details hidden. The native right rail renders existing goal, variables, assumptions, verification status, selected step, and established-step count. It does not invent source recommendations, timings, probabilities, diagnoses, or AI results. Goal-visible scope ancestry filters variables/assumptions so local induction assumptions do not become external theorem premises. The underlying MathIR and verification predicate are unchanged.

Workspace outline selection now stays in the workspace and updates the current-step binding; explicit detail buttons still open details. Preview build passed. Selecting step3 verified the retained workspace, highlighted outline, current-step math, and hidden advanced engineering inspector. `screenshots/workspace-native-human-three-columns.png` and `.ax.txt` record the final state. The data is the existing recorded algebra case, not the source Cauchy-Schwarz prototype, so this is structural evidence, not pixel-equality acceptance. Backend baseline unchanged; AI audit remains 16 historical lines.

Official UI-only Mac App rebuild and strict deep ad-hoc signature verification passed. No new AI or Kernel run, Developer ID signing, or notarization was performed.


### Imports source-card queue (2026-10-07)

The import list now displays consecutive recognition blocks from the same nonempty assetId as one original-source card, retaining every original block index and input order. Nonconsecutive sources and blocks without an asset ID remain separate; no source is deduplicated or removed. Cards show the actual image thumbnail, first-block math summary, total block count, and existing proofread action using the first original index. This is client presentation grouping only; recognition data, upload behavior, provider, and verification pipeline are unchanged.

Preview build passed after correcting the thumbnail to the existing assetURL API and AsyncImage. Native UI verified 1 original image /16 blocks, all16 retained after entering proofread, final block16 present, and leading2 unchanged. Screenshot: `screenshots/imports-native-source-group.png`. This single-image fixture does not establish multi-file runtime coverage or source-prototype error states. Backend baseline unchanged; AI audit remains16 historical lines (zero new calls). Full15-page 1:1 acceptance remains outstanding.

Official UI-only rebuild and strict deep ad-hoc signature verification passed. No new AI/Lean/Kernel test or notarization was performed.


### Verifying page current-goal and proof-step binding (2026-10-07)

Added a native target card and MathIR proof-step list with original reasons, matching the source mathematical document hierarchy. Each step remains waiting for a verification result; no completed/kernel badge is inferred from task stage. The preserved original draft is available through a disclosure. Stage cards and cancellation keep existing semantics. Engineering remains opt-in.

Necessary client binding: the current job structured event reads its mathIRId through the existing GET artifact endpoint. A given ID is read once in the event subscription; stale jobs cannot publish a snapshot. No new AI POST, provider call, retry policy, backend change, or statement transformation was added. Missing snapshots fall back to the original mathematical draft.

Preview build, official UI-only app build, and strict deep ad-hoc signature verification passed. UI verified the recorded algebra target, exactly3 MathIR proofSteps, waiting labels, and original draft expand/collapse; screenshot `screenshots/verifying-native-goal-steps.png`. Existing local artifact GET returned HTTP200 with matching goal and3 steps (`verifying-artifact-read-check.json`). No new full-job SSE/AI/Lean/Kernel run was executed, so that new live binding is not claimed as end-to-end tested. Backend baseline unchanged; audit remains16 historical lines (zero new AI). Fifteen-page same-data visual acceptance remains incomplete.


### Native sidebar resources and saved Mathlib cards

Restored Stitch sidebar entries 项目结构树 and 学科定理库. The first opens the existing workspace proof outline; the second opens the existing formal-details Mathlib tab. This does not implement a new project-wide graph or a subject-library database. The Mathlib tab now renders every saved declaration in order as a native card instead of a single JSON block. Signatures and raw retrieval JSON are collapsed by default and explicitly expandable. No retrieval or AI request is initiated by these navigation actions.

Actual verification: preview build and official UI-only Mac App build succeeded; codesign deep/strict verification succeeded. Native accessibility inspection confirmed all 20 saved declarations (17 found, 3 without confirmation), including the final mul_two entry. Expanding add_sq displayed the saved statement; collapsing restored the default. Screenshot: screenshots/formal-native-mathlib-cards.png. The 36 protected backend hashes remained unchanged. AI audit remained 16 historical lines: zero new DeepSeek requests. These are UI checks of saved responses, not new AI or Kernel validation.

The 15-page one-to-one visual acceptance remains unfinished; this resource navigation correction does not establish overall pixel parity.


### Workspace-specific Stitch sidebar

Compared the workspace original export (6245364fd70c4585a7a02958ec2fa0f5): its sidebar has a 256px width, 56px brand row, functions icon, subtitle, single 工作空间 navigation group with 4px gaps, gray active workspace item, and a bottom container containing service status and settings. The native workspace now follows that structure instead of inheriting the generic multi-group sidebar. Other pages retain their existing navigation. The status is actual backend readiness, not the source prototype's fictitious Lean version/listening state. Settings opens the existing native preferences.

Preview compiled successfully and was restarted. Accessibility confirmed the workspace label, five navigation items and bottom settings shortcut. Screenshot visually inspected: screenshots/workspace-native-source-sidebar.png. Saved algebra fixture only; no Provider startup or new Kernel verification. Full 15-page pixel parity remains incomplete.

Official UI-only Mac App rebuild and strict deep signature check also passed. Backend baseline: 36 unchanged files; audit: 16 historical lines, zero new AI requests.


### Camera-specific sidebar visual structure

Compared fbfbedfe949c4a21a1fd2637c6df531e original aside. Native camera sidebar now uses its 240px width, 48px functions brand row, Workspace Core navigation, white active multimodal item with ACTIVE badge, Connected Devices region, and bottom status panel. Actual system window controls remain native; no duplicate decorative traffic lights. Device names and fictitious READY/12ms state from the prototype are not asserted. Devices are still selected in the existing camera panel after explicit enablement; sidebar currently provides an honest pre-enable instruction, not a discovered-device list.

Preview compiled and restarted; actual AX and screenshot inspection confirmed the structure. Evidence: screenshots/camera-native-source-sidebar.png. Camera was not enabled, no permission request, physical capture or AI call performed. Recognition sidebar still differs from its source and remains pending; full 15-page one-to-one acceptance is incomplete.

Official UI-only rebuild and deep strict codesign verification passed. Protected backend hashes unchanged; 16 historical audit lines, zero new requests.


### Recognition sidebar layout

Compared 7a7625c9be104027a283d2a5bee6ced4 original aside. The recognition native view now uses a 240pt Lean Lab brand sidebar, 28pt brand row, 20pt vertical group spacing, 工作空间 and 学术资源 groups, compact 2pt navigation gaps, gray 首页 selected styling, and bottom real service status. Native window controls remain native. Existing navigation bindings are retained, so the source's 项目/示例库/数学文档/帮助与反馈 labels are not all reproduced; unsupported destinations remain an explicit fidelity gap. No fictitious Lean v4.7.0 is displayed.

Preview compilation succeeded and app was restarted. Real handwritten-image saved-response fixture rendered 16 fragments, confirmed leading 2 retained. Screenshot inspected: screenshots/recognition-native-source-sidebar.png. No image upload, OCR, AI or Kernel execution occurred. This is a layout correction, not completed 15-page acceptance.

Official App UI-only rebuild and deep strict signature verification passed. All 36 backend baseline files unchanged; audit 16 historical lines, zero new AI requests.


### Welcome sidebar source grouping

Compared c3ce8a585e084d12a1fcf63e43cfd89e original aside. Native welcome now has its own 256pt sidebar: architecture brand, 工作区 with active 主工作区 / 我的证明 / 项目结构树, resources with 学科定理库 Mathlib and 多模态导入, settings with 偏好设置 and 系统诊断. Compact row/group geometry follows the original. Bottom three-row panel uses actual backend readiness and saved-record presence instead of fictitious latency/RAM/version. macOS traffic lights remain native, not duplicated.

Preview compiled and restarted; accessibility and screenshot inspected: screenshots/welcome-native-source-sidebar.png. Saved-response UI only, no new AI or Kernel test. A remaining welcome quick-input visual issue is visible when its multiline value receives initial focus: the single-height field clips multiple lines. Unfocused summary is already one-line; this focused-state issue remains pending. Full fifteen-page parity remains unproven.

Official UI-only rebuild and strict deep signature check passed. 36 backend files unchanged, 16 historical audit lines, zero new AI requests.


### Welcome compact input clipping fixed

Replaced only the welcome quick-input control with a local NSViewRepresentable NSTextView/NSScrollView bridge. SwiftUI retains the page, layout, and collapsed one-line summary. The bridge preserves the original multiline string, uses 20pt paragraph rows in the 20pt viewport, and scrolls to the caret. This addresses the macOS-compatible SwiftUI TextField clipping limitation without flattening submitted mathematics or introducing a web runtime. Existing verify action is retained on Return; Shift-Return inserts a newline.

Preview compiled and restarted. Actual UI paste of four lines (设 x ∈ ℝ。 / 因为 x² ≥ 0， / 所以 x² + 1 ≥ 1。 / 证毕。) preserved all newline-separated text in accessibility and current-draft binding, invalidating old verification state as before. Visually inspected final screenshots show a complete current line without neighboring-line fragments; moving the caret Up displays the prior complete line. Evidence: screenshots/welcome-native-quick-input-multiline.png and screenshots/welcome-native-quick-input-caret-line.png. No verification was submitted; Return/Shift-Return behavior has source coverage only in this check. This correction does not establish overall 15-page parity.

Official UI-only Mac App rebuild and strict deep signature verification succeeded. 36 protected backend files unchanged; audit remains 16 historical lines, zero new AI requests.


### Verifying and import source sidebars

Compared original aside markup for a88d7c66ad8a411d8ec765ac9a255f0a and beedb0783ff343d780172f97cb10c32d. Added page-specific 256pt sidebar structures: verifying uses 56pt text brand row, Workspaces single navigation group, active primary workspace, and bottom service card; imports uses 48pt uppercase text brand, two navigation groups, gray active multimodal item, and bottom environment strip. Retained existing functional destinations. Source mock versions, 98.4% Kernel percentage, zero-errors claim, memory measurements and proof count are not asserted without data. Thus bottom informational content remains an explicit source-content difference, and exact pixel parity remains unfinished.

Preview build succeeded and restarted. Native AX confirmed verifying stage/goal/three MathIR proof steps and all five navigation controls. Clicking its existing import navigation opened native imports. Both screenshots captured; imports visually inspected: screenshots/verifying-native-source-sidebar.png and screenshots/imports-native-source-sidebar.png. Saved-response UI only, no verification submitted or provider started.

Both screenshots visually inspected. Official UI-only App rebuild and strict deep codesign check passed. 36 backend files unchanged; audit remains 16 historical lines, zero new AI requests.


### Shared original settings sidebar

Original exports 00af0d3a9b7f45c9a1a1c1ae92c3db78 and a49fa5f2d7c34742b9fe35851ceb6a18 share the welcome sidebar markup. Native preferences/system now reuse that exact native layout component with page-specific active preferences/system-diagnostics rows. Project tree is in 工作区 and functions Mathlib entry in 资源与推理; removed the extra home entry from these pages to match the original navigation structure. Bottom panel preserves native factual states rather than prototype latency/RAM/version claims.

Preview compiled and restarted. Actual native sidebar click opened preferences then system status; both screenshots visually inspected: screenshots/preferences-native-source-sidebar.png and screenshots/system-native-source-sidebar.png. Settings controls were not changed. Zero AI workflow submitted. Remaining differences include default math font/size relative to the source preset, native window chrome, and status-card content; full 15-page one-to-one acceptance remains incomplete.

Official UI-only rebuild and deep strict signature verification passed. All 36 protected backend files unchanged; audit remains 16 historical lines, zero new AI requests.


### Stitch default mathematics font and size

Original preferences HTML explicitly checks katex and its currentFontName/currentSizePx read KaTeX/16px. Corrected absent-setting defaults to katex/16pt in native math presentation and preferences, and corrected the explicit restore-default action accordingly. Existing persisted choices are not migrated or overwritten. Legacy empty-string font remains Times New Roman until the user chooses a font or restores defaults. Explicit per-component sizes still follow each page's own layout. No submitted math strings or backend objects changed.

Preview compiled/restarted. Before restore, persisted legacy Times New Roman/19 remained, verifying preservation. Actual click 恢复显示默认 changed selected KaTeX card, slider, preview font and size to KaTeX/16. Screenshot visually inspected: screenshots/preferences-native-stitch-default-font.png. Preview saved these defaults; this was a display-only check with no AI/Kernel run. Full mathematical layout support and fifteen-page parity remain incomplete.

Official UI-only rebuild and deep strict codesign check passed. 36 protected backend files unchanged, 16 historical audit lines, zero new AI requests.


### Step / mapping / ambiguity shared source sidebar

Original exports 23d08e342737439b9983abcd2e2943bd, 572475286f1e47eabe0b859baca2de7a and fd82a1525ba64343bb8dc632ab306fbc share the same ungrouped aside. Implemented a shared native 256pt sidebar, 48pt text brand, five rows with 18pt icons / 12pt horizontal / 8pt vertical padding / 4pt gaps, and 12pt-radius bottom status panel. All existing route bindings retained. Font cmap confirms history_edu = 0xea3e and local_library = 0xe54b; these original icons now render natively. Prototype version/memory/latency are replaced with factual local service status. Native window controls remain native.

Preview compiled/restarted and three explicit fixture pages opened through the native page selector. Captured and visually inspected screenshots: screenshots/step-native-source-sidebar.png, screenshots/mapping-native-source-sidebar.png, screenshots/ambiguity-native-source-sidebar.png. Shared navigation and icons visible in all three. Algebra step/mapping use saved responses; n/π ambiguity is explicitly synthetic UI fixture. No new recognition, AI or Kernel validation. Full page parity remains unproven.

Official UI-only App build and deep strict codesign verification passed. Protected 36 backend files unchanged; 16 historical audit lines, zero new AI requests.


### Remaining result / editing / formal sidebars

Compared original exports aade4d47c3a94439a72dbffdffd4a91d, 2feaaf08a73d4aec85452cc9054b752f, 917799af0caf4a87b769a77dac11a5b7 and d18fce13b44e46208ea1729f22244793. Success original has no aside and native already excludes it. Failure now uses the same ungrouped native sidebar as step detail. Formal details now use the original welcome-style grouped sidebar. Editing now has its Workspace header, white active row, five compact navigation items, actual current goal region and bottom status strip. Source Pinned Theories entries and false session sync/RAM/version are not invented as real data; they remain explicit content differences. Editing source's global top bar/aside offset still needs further comparison. Font cmap confirms edit_note glyph 0xe745.

Preview compiled/restarted; three explicit fixture pages opened and screenshots visually inspected: screenshots/failure-native-source-sidebar.png, screenshots/editing-native-source-sidebar.png, screenshots/formal-native-source-sidebar.png. Failure is synthetic partial-status fixture; editing/formal use saved algebra records. No proof submitted, no new AI or Kernel run. This finishes a first pass over page-specific sidebar structures, not full 15-page 1:1 acceptance.

Official UI-only App rebuild and deep strict signature verification passed. All 36 protected backend files unchanged; 16 historical audit lines, zero new AI requests.


### Top header first pass and saved-reference search

Audited all fifteen original export header structures (header-source-audit.json, original hashes and header classes/text). Native generic breadcrumb-only toolbar replaced by NativePageHeader with source-like breadcrumb / search / status / toolbar arrangement, 48pt or 56pt height and page-specific horizontal padding. Camera has the extra multimodal breadcrumb. Existing success header retained. New search field is explicitly scoped to saved Mathlib declarations; Return opens the existing formal-details Mathlib tab, where name/signature case-insensitive filtering shows matches and total. Clearing restores all records; no Provider or Retriever request is sent. This is not a full Mathlib catalog search. Source fake project paths, account controls, readiness/version claims omitted. Source-specific verifying navigation and editing full-width 44pt bar still need implementation; shared toolbar does not prove per-page parity.

Initial preview build failed due to accidentally duplicate pre-existing libraryQuery; corrected by reusing the existing field. Rebuild succeeded and preview restarted. Actual UI search sq_nonneg returned exactly 1 / 20 saved declarations. Clear restored 20 items including last mul_two. Screenshot visually inspected: screenshots/formal-native-header-record-search.png. This is a saved-response UI check, zero new AI or Kernel verification.

Official UI-only macOS build completed successfully with `scripts/build_mac.py --reuse-backend`; deep strict ad-hoc signature verification passed. All 36 backend baseline file hashes remain unchanged. AI audit remains at 16 historical lines: this UI verification introduced zero DeepSeek requests. This first-pass header is not acceptance of all 15 screens as pixel-identical; screen-specific navigation and the editing screen global header remain differences to resolve.

## Editing global toolbar alignment

Inspected the original editing HTML: fixed full-width h-11 toolbar, sidebar below that toolbar. NativeRoot now puts NativeEditingHeader above both sidebar and page only for editing; other screens retain their current shell. Native toolbar is 44 points high with a centered 300-point saved-reference search, 20-point brand mark, and existing details/settings bindings. Real native window controls remain owned by macOS; no duplicate decorative traffic lights, invented account, fake Lean version or fake 14ms status. Preview compiled and rendered successfully. Screenshot: screenshots/editing-native-global-toolbar.png. This is a geometry correction, not acceptance of the entire editing screen or all 15 pages as identical.

Official UI-only rebuild and deep strict signature verification passed. Backend baseline: 36 files unchanged; audit: 16 historical lines unchanged, zero new AI calls.

## Verifying source navigation and context toolbar

Read the original verifying header and context section directly from a88d7c66ad8a411d8ec765ac9a255f0a/screen.html and inspected its image. Replaced the generic breadcrumb with the source-specific 56-point header: split brand, four navigation items at 4-point gaps, 12-point text and 12/6-point item padding, and three 32-point existing action buttons. Library opens the saved Mathlib tab; Axioms opens existing Lean details and Kernel axiom metrics. Both bindings were exercised in native preview without proof submission. The context section now matches the source two-row left layout with 16-point padding, actual stage chip and status pill, and actions on the right. Workspace and camera shared header insets corrected to source 16 and 20 points respectively. No invented account/version/timing or estimated completion values.

Preview build initially rejected View.tracking on macOS 12; moved tracking onto Text. One subsequent build was invalidated by an in-flight source edit; final unchanged-source preview build passed. Captured and visually inspected screenshots/verifying-native-source-navigation-context.png. All rendering is SwiftUI. This does not prove all 15 screens pixel-identical; document/progress/state differences remain to inspect.

Official UI-only build and deep strict signature verification passed. 36 backend baseline files unchanged; AI audit remains 16 historical lines, zero new DeepSeek calls.

## Verifying document source row geometry

Read original stage and document sections. Pipeline padding/grid gap already match the source 20/12 points. Corrected NativeVerifyingDocument to source side-by-side numbered marker and content (12-point gap, 20-point marker, 12-point padding), inner content spacing 4 points, 12-point formula with 8-point white inset, and 8-point outer corners. Goal formula now 14 points and 8-point corners. All three saved MathIR steps and reasons remain intact; current waiting state remains actual, no fake closed state or timings. Preview build passed and screenshot screenshots/verifying-native-document-source-rows.png was captured and visually inspected. Full page fidelity remains incomplete, especially richer source right-panel content versus available live task data.

Official UI-only build and deep strict signature verification passed. Backend baseline 36 unchanged files; 16 historical AI audit lines unchanged, zero new DeepSeek requests.

## Result navigation and complete current capture refresh

Read the actual result header export. NativeTopNavigation now follows its 48-point full-width geometry: 12-point uppercase brand, central 4-point padded rounded navigation group, four 12-point links with 14/6-point padding, gray selected Workspace and three 32-point native action targets. Uses existing workspace, saved Mathlib/Lean details, history, and preferences bindings. No decorative duplicate traffic lights or invented account action. Preview build passed. Captured all 15 routes through the explicit fixture picker into screenshots/review15-current, including AX trees and SHA-256 manifests; all are 2560×1800 window captures. These replace stale capture evidence for current-state review, not acceptance. Result screenshot and original Stitch screenshot visually inspected: remaining proof-card density and right-rail differences are clear and should be addressed next. The capture run did not start Provider or submit proofs.

Capture encoding is JPEG, confirmed with Pillow; current files use .jpg extensions and the manifest records actual dimensions and encoding. Official UI-only build and deep strict signature verification passed. Backend baseline: 36 unchanged files; AI audit: 16 historical lines unchanged, zero new requests.

## Result proof-card status and saved-evidence rail

Compared original result HTML and same-width rendered source capture, not the small 383×512 thumbnail. Existing proof-card outer padding (20), spacing (16), marker (28) and formula size (16) already match source and were retained. Replaced pill with source rectangular check/status badge (11-point mono, 10/4-point padding, radius 4), added source explanation icon and actual dependency count in the footer. No fake tactic list or elapsed time.

Added the two missing source rail roles using saved records: Mathlib retrieval summary (17 found /20 saved in this fixture) and Kernel credential summary (4/4 established, current mathematical interpretation). Engineering contents start folded; disclosure retains every saved declaration, no slicing or truncation. Actual native UI expansion and scrolling confirmed first sq_add and final mul_two reachable; details button uses existing formal detail binding. Preview compiled, top/lower screenshots captured and lower screenshot visually inspected. Existing explanation and original-source actions remain. There are still differences from the source in overall rail composition and folded engineering content, so this is not 1:1 acceptance.

Official UI-only rebuild and deep strict signature verification passed. 36 backend baseline files unchanged; historical audit remains 16 lines, zero new DeepSeek requests.

## Result summary hierarchy and breakdown fold interaction

Inspected source quick-metric ribbon and breakdown heading. Success metrics now use source 11-point labels, 18-point bold values and 4-point vertical gaps; failure retains existing sizes. Added source heading marker (8×16) and factual established/total badge. The source whole-group collapse interaction now controls human step explanations only, preserving every formula, actual dependency count and all four detail actions. Native UI test: default open → collapse hides all four explanations while retaining mathematics and 4 detail actions → reopen restores all four explanations and control label. No provider request, proof mutation, new rule or engineering disclosure. Screenshots: success-native-breakdown-expanded.jpg and success-native-breakdown-collapsed.jpg; collapsed screenshot visually inspected. Preview compilation passed. Still not full 15-page 1:1 acceptance.

Official UI-only build and deep strict signature verification passed; 36 baseline backend files unchanged, 16 historical AI audit lines unchanged, zero new requests.

## Result next-action hub

Read original next-action hub: within left column after all step cards, container fill, radius12, padding24, text gap4, action gap12, button horizontal14/16 and vertical8. Added NativeResultContinuation with this geometry and existing source mapping/editing bindings. Uses actual verified status and current mathematical interpretation, not source fake reusable-theorem registration or unsupported library synchronization. Native preview build passed; screenshot success-native-continuation-hub.jpg captured and visually inspected. Actual button interaction opened editor with original mathematical text and previous/current comparison intact; no new proof request. Updated stale visual audit table while preserving incomplete global acceptance.

Official UI-only build and deep strict signature verification passed. Backend baseline 36 files unchanged; AI audit 16 historical lines unchanged, zero new requests.

## Failure source summary geometry

Read original failure summary markup. Replaced shared success-style summary for failure with NativeFailureSummary: white24-point card, 36-point error icon, 16-point icon/text gap, 12-point attribution label, 18-point factual open-step heading, 12-point message and top-right actual established/total badge. Added source four-slot strip (12-point gap and outer padding, 10-point item inset, 4/8-point corner radii) bound to saved mathematical step, ambiguity, formalization and Kernel facts. Retains actual mathematical goal and all step cards. No invented logical cause, Lean error code, timings or source sample degeneracy claim. Preview compiled; synthetic failure fixture confirmed first actual open step1, 3/4 established and absent source invented L4-NON-SEQUITUR. Screenshot failure-native-source-summary.jpg captured and visually inspected. This is explicit UI fixture validation, not new Kernel failure or repair success. Right attribution panel and full same-data acceptance remain incomplete.

Official UI-only build and deep strict signature verification passed. 36 backend baseline files unchanged; AI audit remains16 historical lines, zero new DeepSeek requests.

## Failure inspector matrix source styling

Read source right-column matrix, correction window and impact graph. Existing three card layout uses source20-point padding, 20-point card gaps and matching12-point titles. Corrected matrix row typography to12-point headline with semantic16-point icons, source4-point vertical gaps, neutral container fill for saved formalization/no unresolved ambiguity, and source header tracking0.5. Open-step and unpassed Kernel rows remain error-colored. No fake OCR confidence, invented failed/recognized classification, source ISO version, new prerequisite or inference. Preview compiled; native failure fixture confirmed no unresolved ambiguity, saved formal record and unpassed Kernel. Screenshot failure-native-source-status-matrix.jpg captured and visually inspected. This is local UI fixture evidence only; full fidelity remains unproven.

Official UI-only rebuild and deep strict signature verification passed.36 backend baseline files unchanged;16 historical AI audit lines unchanged, zero new DeepSeek requests.

## Failure passed-step folded rows

Original failure source renders established steps as folded white16-point rows with24-point check,12-point marker/content gap,12-point title and11-point math; existing native failure used full success cards for every established step. Added NativeEstablishedStepFold only for established rows in failure; unproved rows retain complete UnprovedStepCard. Source compact failure section heading is12 points. Fixed unproved explanation vertical sizing to preserve full text. No records or proof statuses modified. Native preview compilation passed; synthetic failure shows all three established rows folded and unproved original derivation visible. Actual step2 expand shows saved explanation, then collapse restores all3 folded rows. Screenshot failure-native-folded-passed-steps.jpg captured and visually inspected. No provider request. Full 15-page same-data fidelity is still unverified.

Official UI-only build and deep strict signature verification passed.36 backend baseline files unchanged,16 historical audit lines unchanged, zero new DeepSeek requests.

## Failure step-list gap

Original failure Step-by-Step Proof Breakdown uses flex-col gap-3 (12 points). Wrapped only result step rows in a dedicated stack using12 points for failure and preserving24 for success. Outer summary/header gaps retained; no record, provider or verification logic changes. Native preview compilation passed. This incremental spacing change has not yet been re-captured in the UI; prior folded-row interaction captures remain historical. Backend36 hashes unchanged,16 audit lines unchanged; zero new AI requests. Full1:1 acceptance remains incomplete.

Official UI-only build and deep strict signature verification passed for this step-list spacing change.

## Current result recapture and failure-gap rendered verification

Restarted latest compiled preview, refreshed review15-current/05 and06 images/AX and corresponding manifest hashes. Captured failure-native-12-point-step-gap.jpg after scroll and inspected render: all three established rows stay folded, tighter row gaps are visible, full unproved card remains. Success full explanations remain open by default and its collapse control remains present. No code change or redundant rebuild this turn; prior official build remains current. Capture is explicit local fixture only and does not prove complete15-page pixel fidelity.


### 步骤详情导航与标题层级：实际原生检查

- 按 Stitch 步骤详情原始 HTML，对齐上下文栏：面包屑在标题上方，左侧间距 4，栏水平内边距 24，步骤按钮垂直内边距 6。使用实际工作空间、原证明与步骤状态，未加入原稿中的虚构路径或自动修复操作。
- 重新编译 NativePreview，实际打开步骤 1；画面保存为 screenshots/review15-current/07.jpg。点击步骤 2 后，标题、原文、目标与当前步序均切换为保存记录中的步骤 2；没有发起 AI 或新的核验。
- UI-only 正式 App 构建成功，深层严格签名检查成功。36 个后端基线文件校验无变更；AI 审计仍为 16 条历史记录，本轮新增真实请求为 0。
- 本项完成局部层级和导航对齐，不构成 15 页逐像素 1:1 验收；其余页面仍需要继续与原稿比较。


### 步骤详情原稿卡片与检查器层级

- 从原始 Stitch HTML 核对原稿卡片的标题下留白 12、内容间距 16、声明区内边距 16、标签 11、公式 18 与垂直留白 12；SwiftUI 已应用。保留原始数学内容，没有引入原型示例中的虚构诊断或自动补前提。
- 右栏依赖和原稿来源补齐 16 点图标、标题副标签与标题下 4 点留白；恢复底部返回原证明入口，依据已有 verified 状态选择结果页。
- NativePreview 真实窗口检查并保存 07.jpg/07.ax.txt；点击返回后显示原有 4/4 保存结果，没有生成新核验。正式 UI-only App 构建和严格签名校验成功。36 个后端基线文件均未变化，审计仍为 16 条历史记录，新增真实请求 0。
- 未完成范围：同源数学内容的全页像素对照、失败详情状态与上下文/目标卡片细节。此项不作为 15 页 1:1 完成声明。


### 步骤上下文与目标卡片：未完成状态实测

- 对照原始 Stitch HTML，将上下文计数与目标状态恢复为 10 点等宽字标签，水平内边距 6、垂直 2、圆角 4；上下文条目间距 8、条目内间距 4，目标内容间距 4、数学内容垂直留白 4。提取 NativeStepContext 解决大型 SwiftUI 表达式的类型检查问题，未改变数据或业务调用。
- 使用显式未完成 fixture（第一步未证明，3/4 已核验）打开步骤详情，目标实际显示未闭合。截图：screenshots/step-native-open-goal-context.jpg。点击返回原证明全览后仍显示未完成结果和内核尚未通过。此数据为 UI fixture，不是新 Lean 验证。
- 预览与正式 UI-only App 构建成功，深层严格签名检查通过。后端 36 文件 SHA256 无变更，AI 审计仍为 16 条历史记录，本轮新增请求 0。
- 剩余视觉差异包括步骤导航活动项颜色、同源数学样例密度和整页像素对照；15 页 1:1 尚未证明完成。


### 状态颜色与导航强调

- 修正步骤导航当前项始终使用主色的问题：已核验步骤主色，未完成步骤红色，非当前项保留中性色。与 Stitch 原稿当前失败步骤红色强调一致，原有步骤记录及判断保持不变。
- 失败摘要中零项未解决歧义改用中性色，实际存在未解决歧义才显示琥珀色，避免将 0 项显示成警告。
- 在 NativePreview 中实际打开未完成证明与步骤 1，截图 step-native-error-active-navigation.jpg 确认当前项文字与圆点均为红色；重新载入已保存通过记录确认主色导航与已闭合目标。刷新 review15-current 的 06/07 画面、AX 与校验值。
- 预览编译、正式 UI-only 构建和签名检查通过。36 个后端基线文件无变化，审计仍为 16 条历史记录，新真实调用 0。
- 本项为状态视觉修正；同源数据的全页像素对照与其余页面差异尚未完成，目标继续进行。


### 形式化页命题元信息与数学步骤对应

- 按 Stitch 形式化页原始 HTML 恢复命题卡片元信息行（11 点）、24 点标题、标准命题标签（11 点）、数学内容（13 点）、16 点内边距及 12 点说明文字。命题卡与步骤列表间距恢复 24。独立 NativeFormalStatement 为客户端表现组件。所有数学及状态来自保存记录，未复制原型虚构版本、耗时、百分比。
- 原生预览实际点击步骤 2，左侧卡片选中，右侧显示 p2 并高亮对应 Lean 行 13–20，数学内容保持原证明。截图 formal-native-statement-and-step-selection.jpg；15.jpg/15.ax.txt 与 manifest 已刷新。
- 预览编译、正式 UI-only App 构建及签名检查通过。36 个后端基线文件无变化，审计仍 16 条历史记录，新请求 0。
- 仍未完成：源稿同数据密度与整页像素对照、检查器工具条视觉及其他页面细节；不作为 15 页 1:1 完成声明。


### 检查器工具条与标签图标

- 按 Stitch 检查器原始 HTML，复制图标改为 16 点、等宽标签 11 点、按钮内边距 6；标签添加 15 点语义图标、图文间距 6、垂直内边距 6，保留 12 点文字、水平内边距 12 与横向滚动。保留实际五个标签和现有内容绑定。
- NativePreview 实测 MathIR 标签显示保存的 proofSteps，再回到 Lean 显示 import Mathlib。刷新 15.jpg/15.ax.txt 与 manifest。切换标签未生成新记录或新 AI 请求。
- 预览编译、正式 UI-only 构建、深层严格签名检查通过；36 个后端基线文件无变化，AI 审计仍 16 条历史记录，新增请求 0。
- 当前宽度下后部标签通过横向滚动访问，未添加源原型未实现的导出按钮、伪 LIVE AST 或虚构检查状态。整页同源数据像素对照及剩余页面差异仍需继续。


### 形式化步骤焦点强调

- 对照 Stitch 活动步骤卡片，补齐 6 点左侧主色条，当前标题改粗体，当前公式区左缩进 28（其他步骤 36）。圆角与现有 2 点选中边框保留。
- 原生预览实际选择步骤 2，右侧仍显示 p2 并高亮对应 Lean 代码。截图 formal-native-active-step-rail.jpg。
- 预览编译、正式 UI-only 构建和严格签名校验成功。后端 36 个基线文件无改动，审计仍 16 条历史记录，新 AI 请求 0。
- 此为局部视觉对齐，不构成 15 页整体验收；同源样例的全页对照仍待完成。


### 15 页对照证据尺寸审计

- 实际读取全部 15 份 Stitch 渲染图片与 15 份原生截图的图片尺寸和 SHA256，生成 15-page-comparison-evidence.json 与本地 15-page-comparison.html。该页面仅为 QA 证据查看器，不纳入 Mac App 运行时。
- 原生截图均为 2560×1800（1280×900 点）；14 份原稿宽 1280，识别校对原稿因横向溢出实际宽 1622。原稿多数为全页高截图，900 点原生截图不能代表完整页面；两侧数学样例也不同。此前宽度相同或窄图比较不能支持 1:1 验收。
- 下一步应优先处理识别页宽度与溢出，再使用同源样例和一致可视范围检查主要页面几何。此次未构建 App、未调用 AI，不将证据清单报告为视觉通过。


### 识别页上下文工具条分组

- 提取 NativeRecognitionHeader，对齐原稿 24 水平 / 12 垂直内边距、16 分组间距、12 点上下文与 15 点校对图标。窄窗口操作分行，达到原稿完整三栏宽度时同一行排列。片段计数读取实际 blocks，导入和相机绑定保持原有行为。没有添加原型虚构置信度、审核或还原规则。
- NativePreview 实际载入手写图片与已有识别响应：工具条显示 16 个片段，原文中的法1前导 2 仍显示。截图 recognition-native-context-actions.jpg。仅显示检查，没有新识别或 Kernel 验证。
- 预览编译、正式 UI-only 构建和签名验证成功；后端 36 个基线文件无变化，审计仍 16 条历史记录，新 AI 请求 0。宽窗口 1646 点同源对照尚未执行，15 页整体验收仍未完成。


### 三页上下文栏重复留白修正

- 识别、步骤详情与形式化页的上下文工具条移除外层重复 24 点水平和顶部留白，工具条填色延伸到主内容区边缘，正文卡片仍保持原稿 24 点边距。步骤详情上下文栏去除整块圆角，符合原稿全宽 section。
- 三页原生窗口截图均已实际查看：recognition-native-full-width-context.jpg、step-native-full-width-context.jpg、formal-native-full-width-context.jpg。识别截图使用已有手写样例；其他使用保存代数证明。首次批量采集识别时实际落在验证中，已纠正并重新采集识别页，未将错误截图作为识别证据。
- 预览编译、正式 UI-only 构建、深层严格签名验证通过；后端 36 个基线文件无改动，AI 审计仍为 16 条历史记录，新请求 0。
- 尚未完成同源数学数据的整页像素对照与剩余页面差异；15 页 1:1 目标保持进行中。


### 偏好页标题区操作比例

- 对照 Stitch 标题右侧操作，恢复保存提示圆点 8、图文间距 8、等宽文字 12、水平内边距 12 / 垂直 6；恢复默认按钮图标 15、文字 12、图文间距 6、圆角 12；操作组间距 12。保留原有本机偏好存储及默认恢复行为，没有加入云同步或假耗时。
- NativePreview 实际打开偏好页，保存画面 preferences-native-header-save-controls.jpg；KaTeX/16 默认显示正常。此次未点击恢复按钮，不覆盖现有偏好。
- 预览编译、正式 UI-only 构建及严格签名验证成功；后端 36 个基线文件无变化，审计 16 条历史记录，新请求 0。其余页整体验收与同源数据像素对照仍未完成。


### 偏好页卡片标题与说明留白

- 原稿字体区和尺寸区标题与说明为 2 点留白；原实现将两者放在 20 点整体间距中。现已分组恢复 2 点，卡片主内容间距 20 保留。字体卡片选中图标从 12 点改为原稿 16 点。没有增加原型中的上下标比例产品设置。
- NativePreview 实际打开偏好页并查看截图 preferences-native-card-title-spacing.jpg，标题说明紧凑、KaTeX/16 显示正确。未改动用户偏好值。
- 预览编译、正式 UI-only 构建和深层严格签名验证通过；36 个后端基线文件无变化，AI 审计仍为 16 条历史记录，新请求 0。整页同源对照和剩余页面差异继续进行。


### 全部 15 页当前版本重新采集

- 从重新启动的 NativePreview 首页依次切换全部 15 个显式样例，每页检查 AX 页面选择值与预期标题一致，再保存当前截图和 AX。review15-current 的 01–15 均重新采集。
- 添加 scripts/update_ui_comparison_evidence.py：只读取本地截图 / AX 并刷新尺寸、格式、SHA256 和对照证据，不启动 App 或 Provider，不宣称像素验收。实际运行成功，15 份均为 2560×1800 JPEG。
- 实际查看导入、相机未启用、系统未就绪页面：导入四类输入及保存原稿可见，相机未启用提示可见，系统状态四卡可见。没有启用物理相机或执行新业务验证。其余页面完成采集和身份检查，不报告为整页视觉通过。
- 36 个后端基线文件无变化，AI 审计仍 16 条历史记录，新请求 0。没有客户端代码变化，本轮未重复构建 App。下一步用这批画面进行同源数据与相同可视范围的逐页修正。

## Import card source alignment
Compared the original Stitch import HTML with NativeImports. Kept the existing four approved input actions. Aligned icon tile colors, top alignment, JetBrains Mono tags with 2-point vertical padding, and 4-point title/description spacing. Native preview and official UI-only App builds passed; ad-hoc signature verification passed. Backend baseline: all 36 files unchanged. AI audit remains 16 historical lines: 0 new API calls. This change has not yet received a fresh screenshot comparison; no pixel acceptance is claimed.

## Native mapping toolbar and import rendering check
Read original mapping HTML and its 1280-point source render. Extracted NativeMappingHeader: one continuous full-width low-surface region with context and step navigation; horizontal padding 16, vertical padding 10, row spacing 10 and navigation top inset 4. Step pills use 4-point vertical padding, 10-point inactive / 12-point active horizontal padding. Status comes from the selected saved proof row; no fabricated timing, pixel coordinates or confidence. Existing navigation only; no AI action added.
Fresh preview screenshots: screenshots/imports-native-icon-card-alignment.jpg, screenshots/mapping-native-unified-context-toolbar.jpg, screenshots/mapping-native-toolbar-step-two.jpg. Actual native window verified all four import cards, full-width mapping context and step 2 selection updating original/math content. These use saved records and explicit fixtures, not new Kernel execution. Source/native mathematical samples differ, so these do not establish whole-page pixel acceptance.
Native preview build, official UI-only rebuild and ad-hoc codesign verification passed. Backend baseline 36/36 unchanged; AI audit remains 16 historical lines, zero new real requests.

## Ambiguity candidate hierarchy
Compared original ambiguity export card structure. Added NativeAmbiguityCandidate with 20-point padding, 12-point corners, 24-point numbered tile, selected/alternative 11-point capsule, 48-point single-character mathematical glyph, adjacent actual Unicode metadata, candidate-text inset and footer selection intent. Complex candidate strings retain existing MathText. Source confidence scores, automatic adoption/replacement and fabricated semantic assertions were not copied.
Fresh native preview verified two explicit synthetic candidates n / pi, selecting candidate 2 updates the capsule, numbered tile, border and footer; selection did not confirm a revision or run AI. Screenshot: screenshots/ambiguity-native-candidate-hierarchy.jpg. The sample is synthetic UI data, not a new recognition or Kernel result. Original source and native sample data differ; whole-page pixel acceptance remains unproven.
Final preview build, official UI-only rebuild and ad-hoc signature verification passed. Backend 36/36 unchanged. AI audit remains 16 historical lines; 0 new API requests.

## Camera mathematical draft grouping
Read original camera export and kept its 4:3 preview, 8:4 columns, 20-point column gap and 16-point right-card padding. Added NativeCameraDraft using actual current record goal and all MathIR proof-step text in grouped human-math cards (8-point spacing, 10-point inset, 4-point internal spacing, 11-point math/title). Original full draft remains available via explicit disclosure; records absent still show the editable draft. No provider, pipeline or camera capture change. Camera header description gap now 4; enable action uses source compact button dimensions.
Fresh native preview showed goal and all three recorded proof steps. Expanding the original disclosure showed the full preserved draft. Screenshots: screenshots/camera-native-grouped-math-draft.jpg and screenshots/camera-native-original-expanded.jpg. Camera was not enabled; no physical capture, continuity camera or new recognition was tested. These saved-response UI checks do not prove complete visual fidelity or new Kernel execution.
Preview and official UI-only builds passed. Backend baseline 36/36 unchanged; AI audit remains 16 historical lines, zero new calls.

## Welcome lower preview typography
Compared original welcome export: 7:5 preview split, 24-point gap, 16-point panel padding, 8-point panel corners, 12-point source mathematical body and 12-point monospace panel headings. Updated NativeWelcomeProofPreview corners, original-math size and bundled JetBrains Mono SemiBold titles. Font PostScript name confirmed from bundled font tables. Existing original draft and all actual dependency nodes remain present; no automatic completion action or prototype theorem facts copied.
Fresh native window scrolled to the lower preview and displayed full original, four dependency nodes, saved-record status and the three explanatory cards. Screenshot: screenshots/welcome-native-original-preview-typography.jpg. Explicit fixture / saved response only; zero new AI or Kernel executions. Sample content differs from Stitch prototype and complete 1:1 acceptance remains unproven.
Native preview and official UI-only builds passed.

## Welcome hero natural reflow
Original export desktop values checked: Sigma 30, input 14, compact button vertical inset 6, description max width 576. Updated native Sigma and both input display/editor fonts, removed manual newline from description and aligned button inset. Existing title, wording, draft and submit actions unchanged.
Fresh native screenshot screenshots/welcome-native-hero-reflow.jpg shows natural two-line description and readable input preview. A subsequent AX input focus attempt reported offscreen; a coordinate attempt did not establish editor focus. Therefore this round does not claim focused editing passed. No text edited or submission triggered. Previous independent editing evidence is not a substitute for this check.
Preview and official UI-only builds passed. Backend baseline 36/36 unchanged, audit 16 historical lines: zero new real AI calls. Whole15-page 1:1 acceptance remains unproven.


## 首页原生编辑器焦点回查

正式 UI 构建和 codesign 验证实际通过；主程序链接 SwiftUI/AppKit，没有 WebKit。NativeQuickInput 现在通过 becomeFirstResponder / resignFirstResponder 同步焦点，而非等待 textDidBeginEditing。独立显式 fixture 窗口中，聚焦后使用 Command-Up 和 Down，实际显示题目与下一行原文并随光标滚动，完整多行字符串仍在 AX 中。证据：screenshots/welcome-native-focused-multiline-visible.jpg。先前 blank focused 截图不作为成功证据：光标所在空白行与焦点状态不是同一问题，本轮没有宣称所有滚动边界已验收。没有提交证明或运行 AI。后端基线 36 个文件未改变，AI 审计仍为 16 行历史记录。15 页逐像素视觉验收、真实摄像头与连续互通相机仍未完成。


## Preferences segmented navigation: source alignment

Compared the original Stitch HTML for 00af0d3a9b7f45c9a1a1c1ae92c3db78. Native navigation now uses bundled Material Symbols: functions, edit_note, terminal and keyboard. Verified the font cmap for keyboard/e312. Selected icon uses primary color. Source geometry retained: gap4, container padding6/radius16, item padding16/10/radius12, icon17/gap8, minimum item width170 with horizontal scrolling. Narrow-window runtime behavior has not yet been checked.

Preview rebuilt and launched; all four tabs were visible and selecting the shortcuts tab displayed its content. Evidence: screenshots/preferences-native-source-tab-icons.jpg. Official UI-only App rebuild succeeded. No proof submission or AI request occurred. Saved font16 and hidden engineering preferences were preserved. Full-page 1:1 acceptance remains incomplete, including sizing controls and the remaining tab content.


## Preferences size control alignment

Extracted NativePreferencesSize and aligned the implemented base-size control to the Stitch source: card spacing24, grouped control spacing10, container radius12, button radius8, bundled JetBrains Mono numeric value, standard-size annotation and Retina guidance. Existing continuous size adjustment remains available. No inactive script-ratio toggle was added: its missing renderer binding is still a fidelity gap, as is the full sizing-card two-column layout.

Preview compilation succeeded and the updated control was visually checked at the saved KaTeX16 setting. Evidence: screenshots/preferences-native-sizing-control.jpg. No preferences were changed during QA. Backend baseline36/36 remains unchanged; audit file remains16 historical lines, zero new AI requests. This does not establish whole-page or 15-page acceptance.


## Script rendering and preferences binding

Added display-only native TeX scripts to the existing fraction parser: braced and single-character upper/lower scripts, recursive fractions in scripts, and combined upper/lower scripts sharing one column. Unsupported commands and malformed groups return nil so the original line remains visible. No original mathematical text, MathIR or verification data is changed. The 70/80 script-ratio preference is stored locally and used by the renderer and the integral limits in the preferences preview. The sizing card now has the source two-column layout, gap24; the existing base-size slider remains available. Reset restores ratio80.

Actual preview compilation succeeded. UI switched 80 to70 and back to80; evidence screenshots/preferences-script-ratio-70.jpg and preferences-script-ratio-80.jpg. Font KaTeX16 and engineering-off remained unchanged. Local compiled Swift parser checks passed for paired scripts, malformed script fallback, unknown command fallback, nested fractions and confirmed leading2. Combined-script visual placement still needs a dedicated rendered check; full TeX including roots/matrices is incomplete. No AI calls were needed.


## Native script placement visual validation

Added a dedicated display fixture sheet to the separate Preview app, not the official App. Six formulas cover combined scripts in both input orders, fraction contents, fractional exponents, malformed groups and unknown commands. Initial visual inspection revealed fractional exponents were too low. Height-based alignment corrected that but lowered ordinary subscripts excessively, so final implementation uses height-based alignment only for scripts containing fractions and preserves normal-script offsets. Final screenshot native-tex-script-placement-current.jpg shows paired scripts sharing a column, normal subscripts, raised fractional exponent and original malformed/unsupported TeX. No clipping observed in these six cases. This is local display evidence, not an AI or Kernel test and not full TeX certification.

Parser check script passed. Preview build initially failed because its script collected only PreviewApp.swift; changed it to include the Preview directory Swift sources and rebuilt successfully. These sources remain outside the production compilation. No backend or verification logic changes. Root notation, matrices and full-page source-matched acceptance remain outstanding.


## Viewport QA correction

Original Stitch HTML search found no sqrt command; root-renderer work is therefore not a confirmed page-fidelity requirement and was not added. The separate native Preview now includes Visual QA / Toggle fixture toolbar (Command-Shift-P), allowing captures without the extra fixture toolbar consuming page height. The window title and existing fixture notice remain explicit. Production App is unchanged. Compilation/runtime verification are recorded separately below when executed. This improves comparison conditions, not pixel acceptance by itself.

Preview compilation succeeded; after restart, Visual QA appeared in the native menu. Command-Shift-P removed the fixture controls from the accessibility tree. Captured screenshots/welcome-native-clean-viewport.jpg. The production build was not changed by this preview-only adjustment. The remaining title bar, fixture notice and different mathematical sample still need accounting in comparisons; this capture alone does not establish equal content viewports or 1:1 acceptance.


## Workspace document toolbar geometry

Compared source 6245364fd70c4585a7a02958ec2fa0f5: document toolbar is full-width, padding24/10, two rows gap8, second-row top4, rather than a floating rounded single-row card. NativeWorkspace now restores that geometry, title tracking and bundled mono step-count metadata. Second row uses existing camera/import/source-mapping/formal-details actions with Material Symbols14, label11, horizontal10/vertical2 and radius4. No source auto-verification or unsupported formatting controls were made into product rules. Full source formatting ribbon remains a fidelity gap.

Actual preview compilation succeeded; native window showed the full-width two-row toolbar and all four existing action labels. Evidence screenshots/workspace-native-fullwidth-two-row-toolbar.jpg, captured with fixture toolbar hidden. The saved four-step algebra record remained intact. No verification submission, OCR, AI or new Kernel run. This is geometry progress, not full-page acceptance.

Toolbar source-mapping action was clicked: native route changed to source correspondence and showed the selected step with original text. Official UI-only build and codesign verification succeeded. No proof resubmission.


## Workspace proof outline source alignment

Compared the original outline: card padding16/gap12, step-list gap6/top4, icon16/top2, row padding8, active radius8. Native outline now separates list spacing from card spacing, uses source filter_list14 glyph, mono10 counters/status badges, one-line math summaries and selected primary semibold title. All original math remains in the record and selected-step inspector; no step count cap or model call added.

Preview compilation succeeded. Selected step3: active badge moved to step3, step1 reverted to its actual established status, right inspector showed the complete step3 statement while remaining on the workspace. Screenshot: screenshots/workspace-native-compact-outline-step3.jpg. All four recorded steps remain present. This is saved-record display, not new Kernel verification. Full source sample/content comparison remains incomplete.


## Workspace source asset card alignment

Source asset tray uses header icon18, card gap12, thumbnail48x40 with cover crop, title11 and excerpt10. Native card now matches these dimensions, uses bundled collections_bookmark/e431 (font cmap verified), one-line excerpt and a right-aligned actual fragment count for image assets. No fake OCR confidence or inferred image position is displayed. Cropping is thumbnail-only; original asset and all source blocks remain intact.

Preview compilation succeeded. Text-source card appeared, click opened source correspondence with full multiline original and selected step. Screenshot workspace-native-source-card-compact.jpg. Image cover-crop and image-count badge still require image-loaded runtime validation; this text-source test does not prove them. No AI or new Kernel run occurred. Full-page pixel acceptance is still incomplete.


## Image-source runtime check and unverified draft reading

Loaded the existing user handwriting image through the explicit local fixture asset endpoint (HTTP 200), with the previously saved recognition response. Native workspace displayed the actual image thumbnail and 16-fragment badge; clicking the asset opened all 16 recognition blocks. This closes the earlier image-loaded display-check gap, without new recognition or AI requests. Screenshot: screenshots/workspace-native-image-source-16-fragments.jpg.

Found and corrected raw TeX being the default view for a nonempty, unverified draft. NativeWorkspace now renders human mathematics by default and exposes the unchanged TextEditor through an explicit edit/read toggle. Empty input still opens the editor. Actual native toggle check preserved all 16 source lines and the user-confirmed leading 2 in method 1, then restored the math reading view. Screenshot: screenshots/workspace-native-unverified-human-math.jpg. No proof statement, source content or verification status was changed.

These checks use explicit UI fixtures and saved responses, not new AI recognition or Kernel validation. No DeepSeek request was submitted. Full 15-page source-matched visual acceptance remains incomplete.

Official UI-only macOS build succeeded; codesign --verify --deep --strict succeeded (ad hoc signing). Backend baseline: 36/36 files unchanged. AI audit remains at 16 historical lines; 0 new DeepSeek requests in this UI check.


## Result summary seal and metric separation

Compared original success export aade4d47c3a94439a72dbffdffd4a91d: status seal uses workspace_premium24 in a 40x40 primary15% tile, horizontal20/vertical12 padding, radius12, label11 and value14. Native summary now matches those dimensions. The source ribbon has margin-top24 plus padding-top24; the native stack gap24 now adds top24 to the ribbon, restoring the 48-point separation. No source sample version, timestamp or fake metrics were copied.

Bundled font cmap verified workspace_premium at e7af and the explicit glyph mapping was added. Preview compilation succeeded, and actual native screenshot shows the badge, all four metrics, four recorded proof steps and the dependency graph. Screenshot: screenshots/result-native-kernel-seal-source-spacing.jpg (fixture toolbar hidden). This is saved-record display, not a new Kernel run. No result explanation or verification action was clicked. Full-page visual acceptance remains incomplete.

Official UI-only build and strict deep codesign verification succeeded. Backend baseline 36/36 unchanged; AI audit remains 16 historical lines, with 0 new requests.


## Result proof-card typography and explanation spacing

Compared original success export step-card: 28-point circular mono number, semibold14 heading, Material check14 and mono semibold11 status. Native card now uses the bundled JetBrainsMono-SemiBold and source check glyph e5ca (font cmap verified). Explanation and dependency footer are grouped with source spacing10 and footer top8; psychology16 has source top2. Card20 padding, radius12 and math16/padding16 remain intact. No sample strategy, dependency, time or named theorem was invented.

Preview compiled successfully. Actual native result displayed all four recorded steps. Collapse/expand removed and restored only explanations; proof formulas, dependencies and status remained. First card detail opened step1 with the complete original multiline statement and 1/4 indicator. Screenshot screenshots/result-native-proof-card-source-spacing.jpg captured with QA toolbar hidden. No AI or new Kernel verification; full 15-page visual acceptance remains incomplete.

Official UI-only build and strict deep codesign verification succeeded. Backend 36/36 unchanged; AI audit remains 16 historical lines (0 new requests).


## Result evidence rail source typography

Original success export uses library_books20/security20, bold14 card headings, mono11 counter and certificate data padding14. NativeResultEvidence now matches these values, including source terminal15 and link12. Bundled glyph cmap confirmed library_books/e02f and security/e32a. No sample percentage, blockchain claim or fabricated version was added.

Preview compiled. Actual native expansion showed the saved 20-item retrieval list; scrolling to the tail exposed mul_two, the final saved item, and the credential card with 4/4 recorded steps and verified status. The first observation did not contain offscreen tail items; scroll verification resolved that visibility limitation. Screenshot screenshots/result-native-evidence-expanded-tail.jpg. This is local saved-record display, no retrieval or AI request and no new Kernel verification. Full-page 1:1 acceptance remains incomplete.

Official UI-only macOS build and strict deep codesign verification passed. Backend 36/36 unchanged; audit remains 16 historical lines, 0 new DeepSeek requests.


## Verifying document header and theorem typography

Compared a88d7c66ad8a411d8ec765ac9a255f0a: document header horizontal16/top16/bottom12, followed by body top20/horizontal24/bottom24. Native now matches those dimensions. Goal label uses bundled mono semibold11, tracking0.6, gap2 to the formula; step numbers use bundled mono12. All saved MathIR steps remain rendered without invented passed/current-goal status.

Preview compiled; actual verifying fixture showed the saved MathIR goal and three proofSteps, each waiting for a verification result. This saved MathIR has three steps, distinct from the four-row completed verification record. Screenshot screenshots/verifying-native-document-source-spacing.jpg. No task submission, cancellation, AI call or new Kernel run occurred. Full-page visual acceptance remains incomplete.

Expanded retained-original disclosure showed the complete original proof. Official UI-only macOS build and strict deep codesign verification passed. Backend 36/36 unchanged, audit remains 16 historical lines, 0 new requests.


## Failure summary source geometry

Compared 2feaaf08a73d4aec85452cc9054b752f: error_outline22 inside36 square/radius8 with top2; headline18 tight tracking; classification strip margin24, top20/bottom12/horizontal12 and marker8. NativeFailureSummary now restores those source values. Existing facts remain bound to open rows, ambiguity records and Kernel status; no source sample failure attribution or confidence copied.

Preview compiled and actual native failure fixture showed step1 unproved, three of four rows established and Kernel not verified. This failure record is an explicit synthetic UI fixture, not a new Lean failure result. Source action opened step1 correspondence with the complete original multiline proof and unproved status. Screenshot screenshots/failure-native-summary-source-spacing.jpg. No AI call, proof submission or new Kernel check. Full 15-page visual acceptance remains incomplete.

Official UI-only Mac build and strict deep codesign verification passed. Backend 36/36 unchanged; audit 16 historical lines, 0 new DeepSeek requests.


## Failure inspector layout and source icons

Compared original failure right rail: Material cancel/warning/check_circle16, crop18 and hub18; detail top2, source field outer container12 with inner96-height/high background/radius4, footer top4; compact graph64 with vertical8. Native inspector now restores these values and bundled glyphs (font cmap verified). Neutral ambiguity and formal-record icons remain factual, with no invented OCR confidence, resource cause or theorem assumption.

Preview compilation succeeded. Actual native screenshot showed the four factual status rows, two-level original field and dependency impact card. Source button opened the first unproved row and retained complete original mathematical text plus step-level precision. Screenshot screenshots/failure-native-inspector-source-layout.jpg, QA toolbar hidden. Failure status is an explicit synthetic UI fixture; this is not a new Lean failure result. No provider call or new Kernel verification occurred. Whole 15-page visual acceptance remains incomplete.

Official UI-only build and strict deep codesign verification passed. Backend 36/36 unchanged; audit remains 16 historical lines, 0 new requests.


## Step context source typography

Compared 23d08e342737439b9983abcd2e2943bd: context item mono semibold11 and mathematical content11; flag14 Material glyph; target explanation on-surface ink. NativeStepContext now restores these styles. Bundled flag/e153 cmap verified. Existing source-derived card padding20, gap12, two-column gap16 remain. No source sample premises or failure causes added.

Preview compiled. Native step1 had zero recorded dependencies; switching to step3 updated title/3-of-4 indicator, both original and target text and showed exactly the saved step1/step2 dependencies. Screenshot screenshots/step-native-context-two-dependencies.jpg. This is saved verified-record display, not new AI or Kernel work. Full-page visual acceptance remains incomplete.

Official UI-only Mac build and strict deep codesign verification passed. Backend 36/36 unchanged; audit remains 16 historical lines (0 new requests).


## Editing history source timeline structure

Replaced the flat two-row history presentation with NativeEditingHistory, matching original 917799af0caf4a87b769a77dac11a5b7 Module C: card16/radius8/gap12, timeline left12 with two-point track at left6, item8/gap10, ten-point dots/top4, active ring2 and fill, mono12 headings, detail gap2 and info14 notification/padding8. Bundled history/e889 and info/e88e glyphs verified. Only current and previous local drafts are available; no fabricated third version, timestamps, cached proof or Kernel success was added.

Preview compiled. A local fixture edit replacing the trailing blank line with a display-check line changed counts to one added/one removed and timeline to editing. Screenshot screenshots/editing-native-source-timeline.jpg confirms the track and both entries. Restore-original action returned zero additions/removals and the unchanged-original badge. No verification submitted. These are local UI fixture interactions, no new AI or Kernel result. Whole 15-page acceptance remains incomplete; this resolves a structural history-card gap, not the full editing page.

Official UI-only Mac build and strict deep codesign verification passed. Backend 36/36 unchanged; audit remains 16 historical lines, 0 new AI requests.


## Formal inspector source toolbar and actions

Original d18fce13b44e46208ea1729f22244793 inspector defines copy-full-Lean, export .lean and close controls with Material16 icons and six-point padding. NativeEngineering now provides all three; copying uses the complete saved leanCode regardless of active tab. Export uses a local AppKit NSSavePanel for the native file-extension selection, writing the exact saved string atomically. Close hides the inspector and returns formal-details view to the mathematical workspace. Tab icons now use source code/account_tree/memory/hub and the existing extra Statement Lock lock icon, all bundled cmap-verified. No LIVE AST claim or provider request added.

Preview compiled with one macOS12 deprecation warning for NSSavePanel.allowedFileTypes; build succeeded. Actual native save exported inspector-toolbar-export-20261008.lean (1848 bytes), byte-for-byte matching saved formal.leanCode; SHA256 ea192967a11340eec0230e377ba03da30a522a56791b45ea579da6a2616f6207. Step2 selection updated inspector to p2; close returned to workspace retaining selected step2 and all four recorded steps. Screenshot screenshots/formal-native-toolbar-step2.jpg. Clipboard output itself was not inspected. No AI or new Kernel run. Full 15-page source-matched visual acceptance remains incomplete.

Official UI-only build and strict deep codesign verification passed. The same allowedFileTypes deprecation warning remains. Backend 36/36 unchanged; AI audit remains 16 historical lines, 0 new requests.


## Fresh 15-page capture without QA toolbar

All 15 current native routes were recaptured at 2560x1800 pixels (1280x900 window points), with the explicit QA toolbar hidden. Previous captures preserved in screenshots/review15-before-clean-viewport-1791390857. Each route selection was verified in a separate .route.ax.txt before hiding controls; each .ax.txt is the actual hidden-toolbar screen state, independently asserting the picker is absent. The metadata refresher now validates those separate sources and records toolbar visibility from actual displayed AX, not a assumed flag. Dimensions, JPEG encodings and hashes all refreshed.

Contact sheet screenshots/15-page-clean-top-viewport-contact.jpg pairs source top900 CSS pixels with native900-point windows for structural review only; source recognition is wider and its crop omits its right overflow. This does not normalize titlebar/fixture notice or mathematical sample content, and does not prove pixel acceptance. Full source images remain intact. Current explicit text fixtures leave image/camera surfaces empty; those screenshots cannot prove image-loaded fidelity.

Visual review still shows workspace formatting-ribbon gaps, image/content-density gaps in recognition and ambiguity, incomplete camera runtime state, and preferences tabs2-4 differences. The recent result/failure/step/editor/formal changes are now represented in the complete evidence set, but whole15 acceptance remains not established. No AI provider started, no task submitted, no new Kernel run. Backend 36/36 unchanged and AI audit remains16 historical lines.

## Native preferences shortcut card follow-up

Compared the original Stitch tab-shortcuts markup with NativeApp.swift menu bindings. Updated only the SwiftUI presentation to a two-column grid, 16-point gaps, 14-point row padding, 12-point corners, descriptive labels and bundled monospace keycaps. Listed only the five existing native menu shortcuts; did not introduce the source export’s automatic proof completion, symbol conversion, or fabricated configuration path. Official UI-only build and strict deep ad-hoc signature verification passed; executable links SwiftUI and no WebKit. Existing allowedFileTypes deprecation warning remains. No live AI request or new Kernel run was executed. This follow-up has not yet received fresh runtime screenshot acceptance; the prior 15-page capture predates this change.

### Shortcut card runtime evidence

Rebuilt NativePreview and opened the new binary through native CUA. Selected preferences / shortcuts, hid the QA toolbar, and captured screenshots/preferences-native-shortcut-grid.jpg (2560 x 1800). All five menu bindings are visible in two columns, including the last preferences row; descriptions and keycaps are unclipped. This is explicit UI fixture evidence only, with no AI or Kernel execution. The original Stitch shortcut examples contain unimplemented automatic completion and a fabricated config path, so those contents were not copied; the source geometry was retained for actual supported menu actions. Whole-page 1:1 acceptance remains unestablished.

## Step context equal-height source layout

Compared source 23d08e342737439b9983abcd2e2943bd micro-grid: two columns, 16-point gutter, 20-point inset and equal outer card heights. NativeStepContext now measures intrinsic content before applying the common maximum height; it does not truncate dependencies or impose a fixed sample-specific height. Actual CUA screenshots step-native-equal-context-zero.jpg and step-native-equal-context-two.jpg show aligned top and bottom card edges for saved step 1 (zero dependencies) and step 3 (two dependencies), with the height shrinking after the step change. Original math, statuses and source mappings remain unchanged. NativePreview compilation passed. These are saved-record UI checks, not new AI or Kernel validation. Whole 15-page fidelity is still not established.

Official UI-only rebuild and strict deep signature verification also passed. Backend baseline: 36/36 files unchanged. Existing export allowedFileTypes deprecation warning remains.

## Centered mathematical assertion follow-up

Source step-detail assertion uses centered display math. Native step original and goal now explicitly request MathText centered alignment; actual CUA screenshot screenshots/step-native-centered-original.jpg confirms the three original algebra lines centered, preserving the separate leading-aligned source excerpt in the inspector. Fixed a shared inconsistency: parsed TeX fraction/script lines now measure their scroll viewport and honor the existing centered option, while oversize content retains horizontal scrolling. The shared parsed-line path needs a dedicated centered fraction screenshot before visual acceptance; plain saved algebra screenshot alone does not prove that path. NativePreview compilation passed. Local fraction display checks passed leading 2, denominators, nested fractions and malformed/unknown/plain fallbacks. No live AI or new Kernel execution. Whole 15-page 1:1 acceptance remains unproven.

Official UI-only rebuild and strict deep ad-hoc signature verification passed; existing file-panel deprecation warning remains.

## Parsed math alignment runtime acceptance

Added an alignment toggle only to macos/Preview/NativeMathDisplayFixture.swift (excluded from official build). Rebuilt the explicit preview, opened its sheet through CUA, captured native-tex-alignment-left.jpg and native-tex-alignment-centered.jpg, and toggled back. Actual pixels show paired superscript/subscript, a stacked fraction and a fraction exponent move to the horizontal center of their cards; left alignment restores correctly. Malformed and unknown-command fallbacks retain their source text. This closes the short parsed-line centering visual check left pending in the previous entry. Oversize horizontal scrolling is not newly runtime-verified by these six short cases. Official App/backend unchanged in this turn; no Provider or Kernel request. Whole 15-page same-content fidelity remains unestablished.

## Workspace source action placement

Source 6245364fd70c4585a7a02958ec2fa0f5 places export in the first toolbar row, import and a symbol reference in the second. Replaced the redundant first-row import with the existing native original-text exporter; retained the second-row import. Added the source symbol-reference entry as a SwiftUI popover with explicit local clipboard copy buttons. The export truthfully says original text, not unimplemented LaTeX/PDF. Source HTML provides no palette contents/layout; the popover is a native application binding, not a claim of screenshot-identical source popup. CUA accessibility verified all 30 symbol controls present, opening/closing the popover, opening the existing save panel with 原证明.txt and cancelling without writing a file. Did not execute a copy during QA, to preserve the user clipboard; copy runtime acceptance is pending. Screenshots workspace-native-symbol-reference.jpg and workspace-native-source-actions.jpg. Original draft, saved 4/4 result and source mapping remained intact. No AI/Kernel request. H1/H2/bold/italic/block-format ribbon remains missing; full workspace fidelity is not accepted. NativePreview build passed.

Screenshot review: workspace-native-symbol-reference.jpg captures the parent window without the transient native popover; it is toolbar evidence, not palette pixel acceptance. Palette accessibility bindings were inspected, but its actual raster capture remains pending.

Official UI-only App rebuild and strict deep ad-hoc signature verification passed. Backend baseline 36/36 unchanged.

## Imports responsive source layout

Compared source beedb0783ff343d780172f97cb10c32d grid-cols-1/md:grid-cols-2/lg:grid-cols-4 and flex-col/lg:flex-row header. NativeImports now changes between 1/2/4 columns using measured content width; the source viewport thresholds 768/1024 account for the 256-point sidebar and 32-point side padding (content thresholds 448/704). Header actions stack beneath the heading below the large breakpoint. Existing four supported input modes, import selection, source groups, handwriting and camera bindings are unchanged. Native CUA dragged the real preview window from 1280 to 892 points and back: four equal 224-point cards become a 2x2 grid with 16-point gutters; narrow header displays title/description then actions without truncation. Final screenshots imports-native-responsive-wide.jpg (2560x1800) and imports-native-responsive-narrow.jpg (1784x1800). One-column branch is below the current native minimum window width and was not runtime tested. No camera permissions, clipboard paste, AI recognition or Kernel run were invoked. Source export’s fabricated blur rules, neural hardware counters and conversion gates were not added. Full source-content/import-state parity remains unaccepted. NativePreview compilation passed.

Official UI-only build and strict deep ad-hoc signature check passed. 36/36 backend baseline hashes unchanged. Existing allowedFileTypes deprecation warning remains.

## Source-math display fixture and single-line formula regions

Extracted four formula/explanation blocks directly from success-screen aade4d47c3a94439a72dbffdffd4a91d into tests/fixtures/ui/stitch-cauchy-display.json via scripts/extract_stitch_math_fixture.py. Fixture records source SHA and display-only provenance; formal data is empty, all steps unproved, kernelVerified=false and simulated=true. The source literal &implies is preserved. These source mathematical claims and illustrative dependency edges are not audited proof facts. The explicit NativePreview toggle uses this fixture only for visual comparison; production Provider/runtime are not replaced.

Source overflow-x-auto formula regions now use a native horizontal ScrollView for plain math: workspace goal and result ProofCard. Narrative text and ordinary workspace step content still wrap. CUA verified workspace formula remains single-line, responds horizontally, and result step 2 fits on one line; saved screenshots workspace-stitch-math-scroll-start.jpg, workspace-stitch-math-scroll-tail.jpg and result-stitch-math-single-line.jpg. The horizontal gesture showed movement, but full far-end traversal was not established; filenames do not imply end-of-content acceptance. Restored the saved real 4/4 record after QA. No AI or new Kernel execution; historic audit still 16 lines. Whole 15-page same-content/state pixel acceptance remains outstanding.

NativePreview compilation and official UI-only build passed; strict deep ad-hoc signature verification passed. Backend baseline 36/36 unchanged. Existing allowedFileTypes deprecation warning remains.

## Long-formula traversal revalidation

Revalidated previous scroll evidence: coordinate and AX horizontal gestures did not establish an actual content-offset change or visibility of the final closing parenthesis. Prior cursor movement must not be counted as formula scrolling. Added native scroll indicators to plain-math horizontal regions to expose a direct native scrolling affordance. Full end traversal remains pending; this is not accepted pixel/interaction parity. No Provider invoked.

## Confirmed native horizontal extent

Process inspection established preview PID 40574 predated the rebuilt executable. Quit and relaunched independent Preview through CUA. New plain-math ScrollView exposes AX horizontal scrollbar; setting its value 0→1 changed the visual content offset and showed final g(x)² dx) including closing parenthesis. Evidence workspace-math-end-confirmed-scrollbar-overlap.jpg. This also exposed overlay scrollbar crossing formula baseline; added 8-point bottom clearance inside the plain-math scroll content. End traversal confirmed on the prior indicator build; clearance raster acceptance remains pending. No AI or Kernel invocation.

Official UI-only build and strict deep signature verification passed; backend baseline 36/36 unchanged. Eight-point clearance is compiled but not yet independently captured in the preview.

## Formula clearance and preference header adaptation

Relaunched the new preview and set actual horizontal AX scrollbar to 1. workspace-math-end-clearance.jpg shows the complete final g(x)² dx) with scrollbar below the formula baseline: 8-point clearance is runtime verified. NativePreferences header now follows source flex-col/md:flex-row at 720-point measured content width (768 viewport less two 24-point gutters), extracting heading/actions without changing settings bindings. Preview compilation passed. Narrow preference branch not runtime verified and may be below the native minimum width; no acceptance claim. No Provider or Kernel request.

Official UI-only App rebuild and strict deep signature verification passed; 36/36 backend baseline files unchanged. Whole 15-page fidelity remains unaccepted.

## Preferences mathematical settings responsive layout

Replaced unconditional two-column math settings with wide 7:5 split and narrow vertical stack; right track uses CSS twelve-column gap geometry (W+24)*5/12-24, retaining 24-point spacing. CUA relaunched compiled preview, checked 1280-point window and resized to 892 points: preview stacks after all controls and is reachable by scrolling; header actions stack, font options/settings stay intact. Screenshots preferences-native-responsive-wide.jpg, preferences-native-responsive-narrow.jpg and preferences-native-responsive-narrow-preview.jpg. No setting was changed or reset. Preview build passed.

Source main is w-full with a fixed 256px aside, whereas the native shell reserves sidebar space. Current breakpoints apply to measured native content, not source outer viewport: exact breakpoint/pixel parity is therefore NOT accepted. This remaining shell difference needs whole-page reconciliation; functional responsiveness alone is not 1:1 completion. No AI/Kernel invocation.

Official UI-only rebuild and strict deep signature verification passed; backend baseline 36/36 unchanged. Overall 15-page fidelity remains unaccepted.

## Correction: source shell wrapper and responsive thresholds

The previous side-overlay claim was wrong: preferences source has an outer div.pl-64 wrapping header and main. Native reserved sidebar geometry is aligned with this structure. Source shell audit now includes afterAsideWrapper for all 15 exports. Corrected native preferences breakpoints to measured content 464 (768 minus 256 sidebar minus 48 gutters) for header, and 720 (1024 minus 304) for 7:5 math split. Previous 720/976 thresholds delayed switching by a sidebar width. Prior shell-overlay limitation is superseded; whole-page pixel acceptance is still outstanding.

Corrected threshold preview compilation, official UI-only build and strict deep signature verification passed. Backend 36/36 unchanged. Corrected breakpoint runtime capture still pending; prior responsive screenshots used delayed thresholds. No AI or Kernel run.

## Corrected preference breakpoints: runtime evidence

Relaunched current compiled preview and physically resized 1280→892→1040→1280 points. Corrected layout: 892 keeps header actions on the same row and stacks mathematical controls/preview; 1040 activates 7:5 split. Screenshots preferences-corrected-breakpoints-wide.jpg, preferences-corrected-breakpoints-892.jpg, preferences-corrected-breakpoints-1040-before-equal.jpg. No settings changes or AI/Kernel run. Unequal font-card heights at 1040 found; added intrinsic maximum-height preference measured before stretching, preserving text and font choices. Equal-height raster verification pending.

Equal-height Preview compilation, official UI-only App build and strict deep signature verification passed. Backend baseline 36/36 unchanged. Font-card equal-height runtime remains pending; no broad 15-page acceptance.

## Font-card equal-height runtime acceptance

Relaunched compiled preview. At 1040 points all three font card tops/bottoms align despite wrapped names/details; restored 1280 and measured layout shrank back without retained height. CUA screenshots preferences-font-cards-equal-1040.jpg and preferences-font-cards-equal-1280.jpg. No font selection, size, script ratio, reset or engineering toggle changed. Re-selected explicit preferences route, captured fresh route AX then hidden-toolbar AX and review15-current/13.jpg; comparison evidence hashes refreshed. This establishes the equal-height behavior only; complete preference page/source content and whole 15-page pixel acceptance remain unproven. No new AI/Kernel request. No source changes this turn, so previous compiled App remains current.

## Workspace editor ribbon audit

Source workspace includes nine missing controls: H1, H2, B, I, Theorem, Lemma, Proof, inline math, display math. Source labels/interaction intent and required presentation-only bindings recorded in workspace-editor-gap.json with source SHA. Existing workspace text editor has plain-string binding and no selection/paragraph-format model. No fake controls or implicit mathematical assumptions added. Integration remains required before workspace acceptance. This audit does not claim implementation or whole-page fidelity.

## Workspace typography binding implementation

Added SwiftUI H1/H2/B/I group for editable drafts, backed by local NativeDraftEditor NSTextView selection typography. Selected characters/paragraph fonts change without adding Markdown/TeX tokens to the string; text edits use existing editDraft binding. Font family honors saved native.mathFont; normal editor size preserves previous Stitch.math() 19pt. Roles and inline/display math controls remain missing. Saved-record workspace does not yet expose this typography group. Initial Preview compilation passed; actual selection action/string invariance runtime QA pending. Formatting is currently view-local, not persisted/exported attributed metadata. No AI or Kernel invocation. These limitations prevent ribbon/page acceptance.

Official UI-only build with selected-font preservation and strict deep signature verification passed; backend baseline 36/36 unchanged. Typography runtime QA remains pending.

## Native editor verification, 2026-10-08

The production entry is NativeApp.swift / SwiftUI App / WindowGroup. The actual executable links SwiftUI, AppKit, AVFoundation and CoreText, without WebKit. All 15 page states remain native SwiftUI; exported Stitch HTML is reference material.

CUA found and reproduced lost editor focus after the first input into an empty draft. Fixed the binding to retain editing mode. Fresh preview confirmed continuous editing and Return as a newline, without verification submission. Added existing project KaTeX Bold / Italic / BoldItalic fonts. Exercised B/I on a selected formula and H1/H2 on its introductory paragraph. After quitting, the decoded preview-only plist preserved exactly the expected 48-character mathematical string including newlines. No Markdown formatting was inserted.

The official Mac App compiled and packaged successfully; strict deep ad-hoc codesign verification passed. All 36 backend baseline hashes remained unchanged. No new DeepSeek or Kernel calls were made. Screenshots: screenshots/workspace-draft-bold-italic.jpg and screenshots/workspace-draft-heading.jpg.

Limitations: formatting is view-local, without rich-text persistence/export; the five remaining role/math editor controls are still missing. Font QA covered KaTeX only. Saved-record toolbar and full 15-page pixel acceptance remain incomplete.

The preliminary defaults CLI string comparison failed because CLI output escapes Unicode. Direct plist decoding confirmed exact equality.

### Complete draft ribbon bindings, 2026-10-08
- Inspected original workspace export: role group has 6-point primary/secondary/tertiary dots; formula group uses 12-point semibold mono; added missing divider and italic I label. All nine draft controls now exist.
- Added local attributed presentation-role tags for Theorem/Lemma/Proof, paragraph spacing, selected inline math font and centered display-math paragraph. These do not alter backend MathIR or assumptions and do not insert dollar signs into mathematical text.
- CUA clicked all five added controls. Display-math paragraph centered visibly; selected mathematics and surrounding paragraphs remained unchanged. Role tags are source-reviewed; their individual stored attribute values have not been independently inspected at runtime.
- After quitting isolated preview, decoded native.originalDraft exactly matched expected 41-character string. Screenshot: screenshots/workspace-nine-tools-block-math.jpg.
- Official UI-only App build passed. Backend baseline 36/36 unchanged. No Provider calls or new Kernel checks. View-local formatting persistence, saved-record ribbon and full same-data 15-page acceptance remain open.

### Recognition source grid fidelity, 2026-10-08
- Source export explicitly uses grid-cols-1 below xl (1280-point viewport), then [340px minmax(640px,1fr) 330px], 24-point gaps/padding. Previous native implementation incorrectly kept three compressed columns at every width.
- Corrected threshold to 992 content points (1280 minus 240 sidebar and 48 gutters). Narrow viewport stacks source, transcription and inspector; wide viewport keeps 340/640+/330 and horizontal overflow. Width measurement is on the constrained outer container.
- CUA: 1280-point three-column layout, horizontal scrollbar at 1 exposing the entire inspector, 1040-point single-column layout, then return to wide. Evidence: recognition-source-columns-1280.jpg, recognition-source-columns-scroll-end.jpg, recognition-source-single-column-1040-fixed.jpg.
- Found image-view state reuse while changing layout: magnifier fell from 300% to 100%. onChange(initialZoom) alone did not fix it. Explicit view identities and State(initialValue: initialZoom) fixed initialization; fresh 1280-to-1040-to-1280 QA kept overview 100% and magnifier 300%. User-adjusted zoom persistence across remount remains untested.
- This is original handwriting with saved transcription, no new recognition or Provider calls. Source design data differs, so full pixel acceptance remains unestablished. Initial single-column screenshot without -fixed is historical before zoom fix.
- Final official UI-only build and strict deep ad-hoc signature verification passed; 36/36 backend baseline hashes unchanged.

### Source responsive grid audit and two native page fixes, 2026-10-08
- Parsed grid class attributes from all 15 original Stitch HTML exports; saved source-responsive-grids.json. This is source evidence, not acceptance of all native breakpoints.
- Step detail source is grid-cols-1 lg:grid-cols-12, so the native switch is at 720 content points (1024 viewport minus 256 sidebar and 48 gutters). Right panel keeps the exact one-third available width rather than an unrelated 280-point minimum.
- Editing source is grid-cols-1 xl:grid-cols-12, so the native switch is at 976 content points (1280 viewport minus 256 sidebar and 48 gutters). Wide 7:5 layout remains; narrow comparison moves below editor and recorded steps.
- Added NativeResponsiveStack using SwiftUI HStack/VStack for macOS 12 compatibility, with no AppKit page layout or WebView.
- Fresh CUA preview confirmed step detail 1280 double-column / 892 single-column; editing 1280 double-column / 1040 single-column. At 1040, outer scrollbar reached comparison, dependencies and editing history. Returned to 1280. Original draft remained unchanged; zero added/removed lines.
- Screenshots: step-responsive-1280.jpg, step-responsive-892.jpg, editing-responsive-1280.jpg, editing-responsive-1040.jpg, editing-responsive-1040-comparison.jpg. These use saved records, without new Provider or Kernel verification.
- Backend 36/36 baseline hashes unchanged. Remaining: other source breakpoints, header wrapping, same-source-content full-page and pixel acceptance.
- Official UI-only App build and strict deep ad-hoc signature verification passed.

### Verifying and result source-grid fidelity, 2026-10-08
- Verified source wrappers: verifying px-8 (32), sidebar 256; success px-6 (24), no sidebar. Native padding already matched these values.
- Verifying source grid-cols-1 lg:grid-cols-12: threshold 704 content points equals 1024 viewport minus 256 sidebar and 64 gutters. Preserved wide 7:5 split and removed unrelated minimum inspector width.
- Success source grid-cols-1 lg:grid-cols-12: threshold 976 content points equals 1024 viewport minus 48 gutters. Narrow moves side cards beneath proof cards; wide remains 8:4 with gap 32.
- Failure source grid-cols-12 has no responsive single-column rule. Kept its dual columns at all supported widths and removed 280-point inspector minimum to maintain source proportion.
- Fresh CUA observed verifying 1280/892 double/single-column; success 1280/892 double/single-column; scrolled narrow success to its side cards. Failure 1280/892 remains dual-column. Returned window to 1280. Failure captures retain scroll position and are not normalized top-viewport comparisons.
- Evidence: verifying-responsive-1280.jpg, verifying-responsive-892.jpg; success-responsive-1280.jpg, success-responsive-892.jpg, success-responsive-892-inspector.jpg; failure-proportional-1280.jpg, failure-proportional-892.jpg.
- Explicit saved-record / partial UI fixture only. No new AI requests, no new Kernel verification. Backend 36/36 baseline hashes unchanged. Full same-source-data pixel acceptance remains unestablished.
- Official UI-only build and strict deep ad-hoc signature verification passed.

## Workspace and camera responsive QA — 2026-10-08

Source exports use workspace grid-cols-1/lg:grid-cols-12 with p-4/lg:p-6, and camera grid-cols-1/xl:grid-cols-12. Implemented those layout breakpoints in SwiftUI; removed extra minimum widths from their wide columns. CUA confirmed workspace at 1280 points has three columns and at 892 points stacks them with 16-point content padding. Camera at 1280 points has two columns and at 1040 points stacks them. Restored the preview window to 1280 points. Camera stayed disabled; no capture, recognition, or verification was submitted.

Evidence: screenshots/workspace-responsive-1280.jpg, workspace-responsive-892.jpg, camera-responsive-1280.jpg, camera-responsive-1040.jpg. Saved algebra record only; no new DeepSeek or Kernel validation. Narrow camera inspector is below the top viewport; this turn confirmed its AX presence, not its full scrolled raster. User-adjusted local view state across responsive remounts is not verified. Full 15-page same-content pixel acceptance remains incomplete.

Official UI-only Mac build completed successfully with reused backend. Strict deep ad-hoc signature verification passed. Executable links SwiftUI/AppKit/AVFoundation/CoreText and no WebKit. Backend baseline 36/36 hashes unchanged. Not Developer ID signed or notarized.

## Ambiguity responsive layout — 2026-10-08

Compared original fd82a1525ba64343bb8dc632ab306fbc HTML: comparison grid lg/1024, candidate grid md/768, card padding p-6/md:p-8, wrapper px-4/md:px-8. Replaced fixed horizontal comparison with SwiftUI responsive stack (content threshold 704 = 1024 - 256 - 64), and candidates with a two-column LazyVGrid above content width 448. Card/wrapper padding matches md rule. App minimum window width 820 means below-md branch is not reachable in current supported window sizes; do not claim runtime QA there. CUA checked 1280 two comparison columns and 892 stacked comparison; restored 1280. Saved algebra record plus explicit preview-only n/pi ambiguity fixture; no resolve request, no AI or Kernel call. Screenshots ambiguity-responsive-1280.jpg and ambiguity-responsive-892.jpg. Narrow candidates were below viewport; their raster was not inspected. Full same-math pixel acceptance remains unproven.

Follow-up CUA scroll at 892 points confirmed both candidate cards remain two columns, with full labels and actions visible. Screenshot ambiguity-responsive-892-candidates.jpg supersedes the narrow-candidate raster limitation above. No selection or submission action was performed.

Official UI-only rebuild completed; strict deep ad-hoc signature verification passed. No new AI/Kernel validation and no full 15-page acceptance claim.

## System responsive layout, 2026-10-08

Original system HTML uses lg/1024 for the header and md/768 for the card grid. Implemented native header stacking and card breakpoints. Runtime exposed self-measured width feedback: fixed-width cards expanded the measured container and prevented narrow mode. System view now receives available content width from NativeRoot (window minus sidebar and gutters), removing that feedback. CUA fresh preview at 1280 and 892 points showed full sidebar, buttons and two-column cards without previous horizontal overflow. Evidence system-responsive-1280-final.jpg and system-responsive-892-final.jpg. The narrow status summary still renders too tall versus the source flex-wrap intent; not accepted as 1:1, despite attempted grouping. Earlier system-responsive-892.jpg documents failed overflow, and -fixed images are intermediate. Do not treat filenames containing final as full fidelity acceptance. md single-column branch is below the current 820-point minimum window and not runtime tested. No new AI, recognition, repair or Kernel calls; explicit saved UI fixture only. Full 15-page same-content acceptance remains incomplete.

Official UI-only build completed; strict deep ad-hoc codesign verification passed. Backend reused unchanged. Narrow status strip fidelity remains open; build success is not design acceptance.

## System compact summary correction — 2026-10-08

Replaced the generic responsive summary wrapper with explicit HStack/VStack branches and separate statusSummary/taskSummary views. Previous nested grouping still rendered an excessively tall narrow strip; do not attribute that to an unproven compiler cause. Freshly compiled/relaunched preview visibly confirms at 892 points: status title and two status values share one row, task information occupies the next row, action buttons and two-column cards remain inside the viewport. Saved system-summary-1280.jpg and system-summary-892.jpg. Restored 1280-point window. These supersede the earlier narrow-summary limitation; overall source pixel acceptance still unproven. Only explicit UI fixture was used, with no AI or Kernel calls. Backend 36/36 SHA baseline unchanged.

Official UI-only App rebuild and strict deep ad-hoc signature verification succeeded. Full 15-page 1:1 acceptance remains open.

## Welcome responsive layout — 2026-10-08

Compared source c3ce8a585e084d12a1fcf63e43cfd89e: px-6/lg:px-12, preview grid-cols-1/lg:grid-cols-12 with 7/5 split, gateway and features md:grid-cols-3. NativeWelcome now receives window width, computes content width without self-measurement feedback, and passes an explicit lg flag/width to preview. Removed additional 240-point inspector minimum. CUA at 1280 visibly shows side-by-side original and dependency preview; at 892 original stacks above dependency panel and horizontal padding is 24 points. Saved welcome-responsive-preview-1280.jpg, welcome-responsive-preview-892.jpg, and -892-bottom.jpg. Initial captures retain scroll position, not normalized source viewport. Lower capture was saved but not independently raster inspected in this turn. Restored window to 1280. md below-768 branch is outside current minimum window and untested; full same-content pixel acceptance remains open. Saved algebra fixture only, no new AI/Kernel. Backend 36/36 hashes unchanged.

Official UI-only build and strict deep ad-hoc signature verification succeeded. Full 15-page fidelity acceptance remains unproven.

## Formal details responsive layout — 2026-10-08

Original d18fce13b44e46208ea1729f22244793 uses fixed 12-column grid with children col-span-12/xl:col-span-7 and col-span-12/xl:col-span-5. Implemented xl 1280 window breakpoint: dual columns above it, stacked main and inspector below it. Available content width comes from root; removed self-measurement and extra 300-point inspector minimum. CUA 1040-point window visibly shows full-width statement and four proof steps, followed by full-width inspector with five tabs and horizontally scrollable code. Screenshots formal-responsive-1280.jpg, formal-responsive-1040.jpg, formal-responsive-1040-inspector.jpg. Restored 1280 points. Saved algebra record only, no new Lean/Kernel/AI calls. Backend 36/36 hashes unchanged. Full same-content pixel acceptance remains open; source literal metadata and four-column metric narrow behavior are not newly accepted.

Official UI-only Mac build and strict deep ad-hoc signature verification succeeded. These do not establish full 15-page fidelity acceptance.

## Source mapping responsive layout — 2026-10-08

Source 572475286f1e47eabe0b859baca2de7a has grid-cols-12, but each child is col-span-12/xl:col-span-4. NativeSourceMapping now stacks below the 1280-point window breakpoint and uses source 14-point horizontal padding. CUA visibly confirmed three columns at 1280 and full-width original followed by recognition panel at 1040. Saved mapping-responsive-1280.jpg and mapping-responsive-1040.jpg; restored 1280. Lower third panel was present in AX but not separately scrolled/raster inspected. Saved algebra record only; no new AI/Kernel requests. Backend 36 baseline hashes unchanged. Full same-content pixel acceptance remains incomplete.

Official UI-only Mac build succeeded; strict deep ad-hoc signature verification passed. This is not Developer ID signing/notarization or full visual acceptance.

## Result grid fidelity — 2026-10-08

Re-read original failure 2feaaf08a73d4aec85452cc9054b752f: fixed grid-cols-12 container does not mean permanently dual columns; children are col-span-12/xl:col-span-8 and col-span-12/xl:col-span-4. NativeResult now receives width and window breakpoint from parent, removes self-measurement feedback, and stacks failure below 1280. Success retains original lg 1024 breakpoint. Right-column width uses (contentWidth - 2*gap)/3, accounting for 12-grid track gaps rather than two flexible columns with a simple 2:1 ratio. CUA observed failure dual columns at 1280, full-width main at 1040, and after scroll the full-width failure inspector and original correspondence card. Saved failure-responsive-1280.jpg, failure-responsive-1040.jpg, failure-responsive-1040-inspector.jpg. Success shared component visibly checked at 1280 and 892: result-grid-1280.jpg, result-grid-892.jpg. Restored 1280. Success lower inspector was not separately scrolled this turn. Existing saved algebra and explicit failure fixture only, zero new AI/Kernel calls; 36 backend baseline files unchanged. Same-content full-page pixel acceptance remains incomplete.

Official UI-only build and strict deep ad-hoc signature verification succeeded. Responsive source inventory now includes child column spans for all 15 pages, avoiding container-only breakpoint inference. Full visual acceptance remains open.

## Twelve-track column geometry — 2026-10-08

Original workspace children span 3/6/3, step detail 8/4, formal details 7/5 with 24-point grid gaps. Added StitchGrid.width using track-span geometry (available + gap)*span/12 - gap, replacing simple ratios that omitted internal track gaps in these three pages. CUA fresh preview at 1280 visibly checked workspace three columns, step1 details and formal inspector with current selected step/code highlight. Saved workspace-grid-tracks-1280.jpg, step-grid-tracks-1280.jpg and formal-grid-tracks-1280.jpg. Existing saved algebra only; no AI or Lean/Kernel execution. No new narrow, draft-only or engineering-expanded workspace checks in this turn. Other grid ratios remain to audit; these captures do not prove all 15 pages or same-content pixel matching. Backend baseline 36 files unchanged.

Official UI-only Mac build and strict deep ad-hoc signature verification succeeded. This is not notarization or 15-page visual acceptance.

## Remaining 5-track panels — 2026-10-08

Re-read actual Stitch classes for verifying (7/5 gap24), ambiguity (5/7 gap20 inside padded card), editing (7/5 gap20 xl), and welcome proof preview (7/5 gap24 lg). Applied StitchGrid.width to their five-track panels; removed editing extra minimum width. CUA fresh 1280 preview visibly inspected welcome original/dependency preview, verifying goal/steps/current-status, and explicit ambiguity original/context/candidates. Saved welcome-grid-tracks-1280.jpg, verifying-grid-tracks-1280.jpg, ambiguity-grid-tracks-1280.jpg. Some captures retain prior vertical scroll and are not normalized source comparisons. Editing first inspection exposed a real breakpoint defect: measured scroll content was narrower than the window, so 1280 stacked incorrectly. Corrected editing to receive parent width and window xl flag, removed local measurement. Rebuilt and visibly confirmed editing dual columns at1280 and stacked at1040, saved editing-grid-tracks-1280.jpg and editing-grid-tracks-1040.jpg, restored1280. Narrow lower comparison panel not independently scrolled this turn. Existing saved algebra/explicit ambiguity only; no edits submitted, no new AI/Kernel. Overall 15-page same-content pixel acceptance remains incomplete.

Official UI-only build and strict deep ad-hoc signature verification passed; 36 backend baseline files remain unchanged. No new real AI/Kernel. Full 15-page visual acceptance remains open.

## Camera / equal source mapping grid — 2026-10-08

Camera original fbfbedfe949c4a21a1fd2637c6df531e uses xl 8/4 gap20. NativeCamera now receives window breakpoint from root and uses four-track span geometry; content measurement remains only for actual width. CUA visually confirmed dual preview/control columns at1280 and stacked preview at1040 with camera disabled throughout. Saved camera-grid-tracks-1280.jpg and camera-grid-tracks-1040.jpg. Restored1280. Source mapping changed flexible HStack to equal-width three-column LazyVGrid, preserving xl stack behavior and step-level correspondence. CUA visibly checked the three aligned/equal panels at1280, saved mapping-equal-grid-1280.jpg. No narrow mapping, image-loaded or lower camera controls raster check in this turn. Existing saved algebra display only; no camera activation, no AI/Kernel execution. Full same-content 15-page acceptance remains incomplete.

Official UI-only Mac build and strict deep ad-hoc signature verification succeeded. Backend baseline36 unchanged; zero new real AI/Kernel. Full15 visual acceptance remains open.

## Preferences window breakpoint — 2026-10-08

Re-read original 00af0d3a9b7f45c9a1a1c1ae92c3db78: math panels use lg 1024 and heading md 768 viewport breakpoints. NativePreferences now receives viewportWidth from parent, keeping actual content measurement only for track widths. This prevents scrollbar width from forcing an early stack at1024. Formula preview uses shared five-track span geometry. CUA fresh preview visibly confirmed dual columns at1280 and1024, stacked at892; screenshots preferences-window-grid-1280.jpg, preferences-window-grid-1024.jpg, preferences-window-grid-892.jpg. Restored1280. No preference changed; no new AI/Lean/Kernel execution. Lower stacked formula preview and alternate tabs were not independently inspected this turn; full15 same-content pixel acceptance remains incomplete.

Official UI-only Mac App build completed successfully; strict deep ad-hoc signature verification passed. Executable links SwiftUI and no WebKit. Backend baseline36 unchanged. No new real AI/Kernel calls. This does not prove Developer ID signing/notarization or full15 visual acceptance.

## Verifying / step viewport breakpoints — 2026-10-08

Re-read original a88d7c66ad8a411d8ec765ac9a255f0a and23d08e342737439b9983abcd2e2943bd: both main grids use lg1024. NativeVerifying and NativeStepDetail now receive parent window wide flag, retaining measured content width solely for five/four-track geometry. CUA confirmed verifying1280/1024 dual and892 stacked, step1024 dual and892 stacked. Saved verifying-window-lg-{1280,1024,892}.jpg and step-window-lg-{1024,892}.jpg. Restored1280. Saved algebra record only, no new AI/Lean/Kernel execution. At1024, verification status explanation truncated; added vertical fixedSize to permit wrapping. That follow-up awaits new preview inspection below. Lower stacked inspectors not separately scrolled this turn. Full15 same-content pixel acceptance remains incomplete.

Follow-up fresh preview CUA at1024 confirmed the full verification status explanation wraps to two lines with no ellipsis. Saved verifying-status-wrap-1024.jpg; restored1280. This supersedes the truncated status in verifying-window-lg-1024.jpg. Zero new real AI/Kernel.

Official UI-only build and strict deep ad-hoc signature verification passed. All36 backend baseline files unchanged. This is not Developer ID signing/notarization or full15 fidelity acceptance.

## Import / ambiguity viewport breakpoints — 2026-10-08

Re-read source fd82a1525ba64343bb8dc632ab306fbc andbeedb0783ff343d780172f97cb10c32d. NativeAmbiguity now uses actual viewport md768 for card padding/candidate columns and lg1024 for original/context split. NativeImports gateway uses viewport md768 two columns/lg1024 four columns and heading lg1024. Measured width remains for ambiguity track geometry only. CUA visibly confirmed import four columns at1280/1024 and two at892, ambiguity dual original/context and two candidates at1024 without selecting candidates. Screenshots were emitted in tool output; subsequent save/narrow-ambiguity captures hit ScreenCaptureKit invalid-parameter/noWindowsAvailable despite fresh AX reads. Narrow ambiguity not newly verified. No imports, camera activation, new AI/Lean/Kernel. Backend baseline36 unchanged. Full15 same-content pixel acceptance remains open.

Filesystem inspection confirms imports-viewport-1280.jpg, imports-viewport-1024.jpg, imports-viewport-892.jpg and ambiguity-viewport-1024.jpg were saved successfully before the later UI observation errors. Narrow ambiguity remains unverified this turn.

Official UI-only Mac App build succeeded; strict deep ad-hoc signature verification passed. No new real AI/Kernel calls. This is not notarization or full15 fidelity acceptance.

## Recognition xl / narrow ambiguity follow-up — 2026-10-08

Re-read recognition7a7625c9be104027a283d2a5bee6ced4: grid1/xl[340_minmax640_330] gap24. NativeRecognition now receives viewport xl1280 flag from parent, retaining measured width for center expansion. CUA actual1280 displayed fixed-width source/center with horizontal overflow and right inspector exposed by horizontal scroll. At1040 content stacks; separately scrolled to full-width center/inspector/actions. Saved recognition-xl-1280.jpg, recognition-xl-1280-inspector.jpg, recognition-xl-1040.jpg, recognition-xl-1040-inspector.jpg. Restored1280. Header independent wrapping remains unchanged; source image-loaded behavior not newly checked. Narrow ambiguity892 follow-up successfully captured stacked original/context, ambiguity-viewport-892-confirmed.jpg; lower candidates not independently scrolled. All QA uses saved algebra/explicit ambiguity, no changes submitted, no new AI/Lean/Kernel. Backend baseline36 unchanged. Full15 same-content pixel acceptance remains incomplete.

Official UI-only Mac App build and strict deep ad-hoc signature verification passed. Full15 visual acceptance remains open; build/signature checks do not establish pixel fidelity or notarization.

## Recognition header content fit — 2026-10-08

Source7a7625c9be104027a283d2a5bee6ced4 uses flex-wrap with16gap and12vertical/24horizontal header padding. Removed arbitrary1358content threshold from NativeRecognitionHeader. Intrinsic component widths are measured using preferences and compared with available content width; existing context/status/actions remain, no fabricated alignment/confidence/compatibility claims or unimplemented history/revert actions. Applied source per-button10horizontal/4vertical padding and15-point Material icons. First icon file_download lacked project mapping and visibly fell back to architecture; corrected to mapped download and fresh1280 CUA confirmed proper downward arrow. Header one-row visibly confirmed1280/892/820 for current short content; wrap branch for longer contents not exercised. Screens recognition-header-fit-1280-final.jpg supersedes1280 initial;892/820 captures precede icon correction. At820 global navigation truncates and sidebar shrinks, separate remaining layout issue. Restored1280. Saved algebra only, no requests/actions submitted, zero new AI/Lean/Kernel, baseline36 unchanged. Full15 same-content pixel acceptance still incomplete.

Official UI-only Mac App build and strict deep ad-hoc signature verification passed. No new AI/Kernel; full15 visual acceptance remains open.

## Root navigation sizing — 2026-10-08

NativePageHeader preserves intrinsic breadcrumb/status widths and permits search to shrink. NativeRoot fixes sidebar width and assigns remaining window width to content; root fills the window before measuring geometry. An intermediate intrinsic-width implementation stayed at820 after resizing to1280; corrected before official packaging. CUA actual preferences1280→820→1280 confirmed fixed256 sidebar, full breadcrumb/service label, single-column narrow layout and restored full-window dual-column wide layout. Screens navigation-root-preferences-1280.jpg and navigation-root-preferences-820.jpg. Earlier recognition navigation-root-820.jpg precedes final root fill correction; recognition final header bound is implemented but not newly captured this turn. Backend baseline36 unchanged. Explicit saved-response UI preview only, zero new DeepSeek/Lean/Kernel calls. Full15 same-content pixel acceptance remains incomplete.

Official UI-only Mac App build succeeded and strict deep ad-hoc signature verification passed. This does not establish notarization or full15 pixel fidelity.

## Page scroll indicator source alignment — 2026-10-08

Re-read workspace6245364fd70c4585a7a02958ec2fa0f5 original export: global injected CSS explicitly hides scrollbars. Root native page ScrollView now hides indicators; scrolling remains enabled. CUA actual workspace1280 top and bottom captured, workspace-hidden-page-scrollbar-top.jpg / workspace-hidden-page-scrollbar-bottom.jpg. Real scroll moved utility header out of view and revealed complete final step and right summary; no visible vertical indicator, native scroll accessibility remains. This change covers outer page scroll only; inner scroll controls remain separately implemented. Recorded algebra fixture only, no verification submitted, zero new AI/Lean/Kernel. Backend36 baseline unchanged. Full15 same-math same-viewport fidelity acceptance remains incomplete; current workspace header and saved-record toolbar still differ from source.

Official UI-only App rebuild succeeded; strict deep ad-hoc signature check passed. Not a notarization or pixel fidelity assertion.

## Workspace dedicated header — 2026-10-08

NativePageHeader now selects dedicated workspace header, parent supplies viewport width. Original6245364fd70c4585a7a02958ec2fa0f5 header h56 px16 gap16, mono breadcrumb gap6, right gap12, xl status capsule and white search capsule informed implementation. Real status only, no fixed Lean4.8 or account avatar; existing preferences/details actions remain. Missing pending glyph corrected to mapped info before final QA. CUA1280 shows separate status/search and820 hides xl status while retaining full breadcrumb/search/actions; restored1280. Screens workspace-native-header-1280.jpg / workspace-native-header-820.jpg. View-mode group still missing, saved-record ribbon incomplete; no full1:1 claim. Explicit saved algebra preview only, zero new AI/Lean/Kernel, baseline36 unchanged.

Official UI-only build succeeded, strict deep ad-hoc signature verified. Full15 same-content pixel acceptance remains incomplete.

## Workspace view selector — 2026-10-08

Implemented source header three-button view group (12pt labels, h8/v4 button padding,2 group padding,r8 background). NativeStore view-only workspaceView binds header to workspace body: mixed full outline/math/inspector; pure math full-width body hides outline/inspector including engineering; step view filters existing rows to selected row, preserving original numbering and defaulting to first when selection absent. No business requests or backend changes. CUA1280 actual pure math showed all4 rows/full-width math, step view showed step1 then selecting outline step2 updated only current body/inspector, switching mixed restored4 rows with selection preserved. Screens workspace-view-math.jpg / workspace-view-step2.jpg. Narrow selector fit and draft-only mode not exercised this turn. Saved fixture only, zero new AI/Lean/Kernel, backend36 unchanged. Full15 same-content pixel acceptance remains incomplete; saved-record typography ribbon still pending.

Official UI-only App build and strict deep ad-hoc signature check passed. Full15 pixel fidelity not established.

## Workspace selector narrow fit — 2026-10-08

Actual820 after selector addition exposed right-action clipping and content overflow. Reduced search minimum width and priority; intermediate search field became unusably narrow. Final narrow(<1024 viewport) search trigger opens existing saved Mathlib tab; wide retains query field. This compact breakpoint is native layout adaptation, not yet proven1:1 to source md search label. CUA820 confirmed complete breadcrumb, all3 view buttons and both actions, no root overflow. Saved workspace-selector-narrow-820.jpg; actual search click opened saved20-item Mathlib display with query field, no live calls. No new AI/Lean/Kernel; source toolbar full fidelity and15-page same-content pixel acceptance remain incomplete.

Official UI-only build succeeded; strict deep ad-hoc signature verified. Backend36 unchanged. Not full visual acceptance.

## Native radical display — 2026-10-08

Common display-only parser/view now handles braced sqrt radicands recursively, including fractions and scripts. Native Path sizes radical and overbar to measured radicand extent. MathText dispatch recognizes sqrt without needing accompanying scripts/fractions. Malformed/empty groups and unsupported syntax fall back to original text; no edit/MathIR/submission changes. CUA explicit8-case native display sheet visibly showed root over 1+x²/y_(n+1), left and centered; existing fraction/script cases rendered and malformed sqrt/unknown command preserved source. Screens native-radical-left.jpg / native-radical-centered.jpg. This is native display fixture QA, not source-matched page pixel comparison or complete TeX engine. Indexed roots/matrices/large-operator layout remain unsupported; backend36 unchanged, zero new AI/Lean/Kernel. Full15 1:1 acceptance remains incomplete.

Official UI-only Mac App rebuild succeeded; strict deep ad-hoc signature check passed. This is not notarization or full15 fidelity acceptance.

## Fifteen-source math inventory / symbol coverage — 2026-10-08

Generated source-math-coverage.json from all15 selected original HTML exports, excluding script/style content. Source evidence found common int/implies/langle/rangle/oint/equiv/land/vdash/Phi/cdots/blacksquare/checkmark/sinh commands absent from conservative display adapter. Added deterministic Unicode mappings only. Actual Swift adapter executable passed5 checks (integral, implication/conjunction, angle brackets, contour integral, unknown fallback). First standalone compilation failed local SDK SwiftBridging mismatch; project existing vfsoverlay and canonical absolute module-cache path resolved it. Check source retained in math-symbol-check/main.swift. No new page screenshot QA for these mappings, no full-TeX/pixel acceptance claim. Left/right sizing, text styling, integral limits and other complex math remain pending. No AI/Lean/Kernel calls or backend edits.

Official UI-only build succeeded and strict deep ad-hoc signature verified. Full15 source-matched visual acceptance remains incomplete.

## Standard TeX delimiter directives — 2026-10-08

Source inventory across workspace/recognition/verifying/failure/mapping/formal-details includes left/right directives. Added shared nesting/token validation and removal of sizing directives, retaining visible ordinary or angle delimiters and removing invisible dot delimiter. Applied before fraction tokenization so full paired directives validate before segment rendering. Unknown delimiter tokens, dangling/right-before-left directives fall back to original source. Actual compiled production MathPresentation passed9 checks including4 delimiter cases; actual compiled NativeFractionParser passed6 nested fraction/root delimiter and malformed cases. Parser harness substitutes only Stitch font/color dependencies, not parser/AI/Lean. Checks retained math-symbol-check and math-delimiter-check. Standard delimiter glyphs only: stretching to fraction/root height remains pending. No new rendered page evidence, no full1:1 assertion. No backend changes or AI/Lean/Kernel calls.

Official UI-only build succeeded; strict deep ad-hoc signature verified;36 backend hashes unchanged. Full15 pixel acceptance remains incomplete.


## Saved workspace typography controls — 2026-10-08

Original workspace HTML/PNG shows nine formatting controls also available for document content. Native workspace previously hid these controls whenever a saved verification record existed. Made the same native ribbon available with saved records and used existing inline NativeDraftEditor when a typography action begins. Actual CUA fixture-only QA: B action entered inline editing, unchanged mathematical text retained saved verification; subsequent text insertion removed old record/step checkmarks and passed status using existing editDraft invalidation. No verification button was clicked. Screens workspace-saved-typography-toolbar.jpg, workspace-saved-typography-editing.jpg, workspace-edited-record-invalidated.jpg. Nine controls visibly available; only B transition and text invalidation were exercised in this turn, not all nine individual effects. Formatting persistence/export and full15 same-content pixel acceptance remain incomplete. Zero new AI/Lean/Kernel calls;36 backend hashes unchanged. Official UI-only App rebuilt successfully; strict deep ad-hoc signature check passed (not notarization).


## Recognition inline preview alignment — 2026-10-08

Compared original recognition HTML (7a7625c9be104027a283d2a5bee6ced4): original active card previews the current expression and offers clear, whereas native previously displayed old block text. Native preview now binds current recognitionEdit, with compact clear action affecting only unsaved local text. Goal card padding20, formula18/padding14/radius8 and inactive row mono12 label match source metrics. Actual native fixture QA showed existing fractional expression, clear removed input and preview, new unwrapped input stayed source text conservatively, then delimited x²+y²≥0 rendered native superscripts and inequality. No save/verify/recognition request was executed. Screens recognition-inline-live-preview-fraction.jpg / edited.jpg / delimited.jpg. Image fixture currently lacks usable asset URL and displayed unavailable; image rendering was not validated in this turn. Source confidence chips and precise stroke overlays cannot be claimed from step-level real data. Full15 same-content pixel comparison remains incomplete. Official UI-only build and strict deep ad-hoc signature passed;36 backend hashes unchanged; zero new AI/Lean/Kernel calls.


## Recognition local image binding and native image interaction — 2026-10-08

Previous recognition visual QA had an unavailable image because preview did not start its backend and qa-image was resolved as an HTTP asset. Added nullable recognition image environment binding (production default nil), populated exclusively by separate PreviewApp with the existing original-handwritten-proof fixture bundled by preview build script. Shared SourceImage now decodes local file URLs with NSImage and uses the same SwiftUI viewport, gestures and controls as existing HTTP images; HTTP AsyncImage branch remains. This is client presentation/application binding, not a provider fixture substitution. Original photo is included only in the independent QA preview bundle, not official App resources. Actual CUA at1280: overview100%, second viewport300%, plus changed to450%, drag visibly shifted handwritten lines, restore reset to100%. Saved recognition-local-image-overview-zoom.jpg, recognition-local-image-drag-450.jpg, recognition-local-image-reset.jpg. No AI, backend startup, save/verify or Kernel request.36 backend hashes unchanged. Images are genuine supplied handwriting, recognition text is saved response; this proves native display and interaction, not new recognition accuracy, exact stroke localization or full15 same-content pixel fidelity.

Official UI-only build succeeded; strict deep ad-hoc signature verified. Full15 pixel acceptance remains incomplete.


## Verification stepper source states — 2026-10-08

Read original verifying screen a88d7c66ad8a411d8ec765ac9a255f0a: active stage bold12 with mono10 Running, later stage waiting and70% opacity,11pt explanatory line spacing. Added these native display states based on existing event-to-activeStage mapping and matched pipeline title. Earlier stages retain neutral numbering: event position alone cannot support fabricated green Kernel passes. Actual independent fixture at1280 showed all5 columns, active Kernel Running and final waiting, no overlapping labels; saved verification-stepper-running-waiting.jpg. Attempted narrow-window check returned noWindowsAvailable; narrow verification not claimed. No AI/Lean/Kernel or product workflow change;36 backend hashes unchanged. Full15 same-content pixel fidelity remains incomplete.

Official UI-only App rebuild succeeded and strict deep ad-hoc signature check passed.


## Stable QA viewport menu / narrow verification audit — 2026-10-08

Repeated resize-drag operation failed noWindowsAvailable while authoritative getApp/getState still showed the running fixture. Added820/1280 point content-size commands solely in separate PreviewApp Visual QA menu. Actual menu action yielded1640px screenshot, proving820pt viewport. Narrow verification exposed English nav word splitting and crowded5-stage headings. Original header links use ordinary unbroken English words. Set native nav label intrinsic horizontal sizing and removed outer header extra fixed gaps/minimum spacers to match source justify-between intent. Five-stage narrow card crowding remains pending; no broad narrow acceptance claim. Preview menus never ship in official build. No AI/Lean/Kernel.

Rebuilt preview and actual820 menu action: all4 nav labels single-line; intermediate brand truncation exposed and corrected by intrinsic brand sizing. Final screenshot verification-header-single-line-820.jpg shows complete brand,4 labels and3 actions inside header. Pipeline narrow crowding still unresolved, not claimed1:1. Backend36 hashes unchanged.

Official UI-only build and strict deep ad-hoc signature passed. Official builder compiles macos/Native only; QA viewport menu excluded. Full15 pixel acceptance incomplete.


## Verification stage description source clamp — 2026-10-08

Original stage descriptions explicitly use line-clamp-2. Native had unlimited description expansion; applied two-line limit retaining full accessibility text. Tried intrinsic single-line Running badge at820, actual screenshot showed active title squeezed out and column widths redistributed. Rejected and reverted intrinsic badge change; preserved only source-backed description clamp. Rejected evidence verification-stepper-narrow-rejected-intrinsic-running.jpg is diagnostic, not passing screenshot. Native preview still contains rejected intermediate binary until next rebuild; official build uses corrected source. Narrow stage heading/badge layout remains incomplete; source-matched browser820 evidence is needed before choosing layout. No AI/Lean/Kernel, backend36 unchanged. Full15 fidelity incomplete.

Corrected-source official UI-only build succeeded; strict deep ad-hoc signature passed. No complete narrow or15-page acceptance claim.


## Verification equal grid columns / measurement loop repair — 2026-10-08

Source is md:grid-cols-5 gap3, meaning equal track widths. Native flexible HStack distributed widths by intrinsic content. Added deterministic column width (page content minus40 card padding minus48 gaps)/5. First implementation retained descendant geometry panelWidth; actual1280→820 exposed stale width lock/whole page overflow. Replaced panelWidth with root viewport-derived content width min1440(viewport-256)-64 and removed descendant geometry update. Actual intermediate820 now fitted root and equal5 columns, but height constraint truncated headings. Tried intrinsic-height preference normalization; final route-switch QA did not establish reliable verifying screen, so removed the whole preference measurement/height state. Final source retains equal columns, root width input, intrinsic vertical sizing and existing86 minimum, with no preference feedback. Final exact source not yet runtime screenshot verified; equal heights and narrow heading fidelity remain unproven. Earlier verification-equal-columns-1280.jpg is intermediate evidence, not final acceptance. No AI/Lean/Kernel;36 backend hashes unchanged. Full15 source-matched fidelity incomplete.

Final corrected-source official build succeeded; strict deep ad-hoc signature passed. Runtime visual QA of this final revision pending.


## Final equal-column revision runtime recheck / centered QA window — 2026-10-08

Rebuilt independent preview from final corrected Native source (no stage-height preference), confirmed route actually verifying before toggling toolbar.820 resize yielded capture with white bottom/right clipping; could not treat it as reliable page overflow evidence. Added center() after setContentSize solely in PreviewApp QA menu, rebuilt, actual menu action produced complete1640x1800 screenshot. Saved verification-final-equal-columns-centered-820.jpg. Final runtime confirms root width shrinks and5 equal column widths, with complete page capture. Does NOT establish full fidelity: stage headings and Running still over-wrap, individual card heights differ, header brand visually truncates despite prior sizing correction. These are pending defects. No new official Native changes in this turn; preview-only centering excluded from official build.36 backend hashes unchanged, zeroAI/Lean/Kernel. Full15 acceptance incomplete.
## Verification stage grid at 820 pt

The source HTML uses five equal-width grid tracks above the 768 pt breakpoint, with each row stretching to the tallest stage. Native SwiftUI previously rendered five tracks with different heights and truncated the longest stage labels. The native verification cards now use a common width and a deterministic common height derived from the available stage width. Their header accepts vertical wrapping. The explicit fixture preview at 820 pt shows all five cards equal in height and the full stage labels and `Running` text; evidence: `screenshots/verification-equal-height-820.jpg`. The underlying job stage and proof status bindings did not change.

The explicit preview compiled, the formal app was rebuilt with `scripts/build_mac.py --reuse-backend`, and `codesign --verify --deep --strict` passed. All 36 backend baseline hashes match. This was a fixture UI inspection with zero DeepSeek and zero Lean requests. Full 15-page same-data visual acceptance remains open.
## System status strip at narrow desktop width

The system page's native status strip previously switched to a vertical stack at a 720 pt content width, although the original Stitch flex row and the actual status labels fit at the 820 pt window minimum. Lowered the native row threshold to 500 pt content width, keeping the vertical fallback below that size. The current 820 pt fixture shows service, retained manuscript, and task state on one line without truncation or horizontal overflow: `screenshots/system-status-one-line-820.jpg`. This is a layout change only; the labels still reflect actual local state, without the prototype's fictional retry/self-healing controls or telemetry.

Native preview and official UI-only builds passed; strict deep ad-hoc signature verification passed. All 36 backend baseline files match. No DeepSeek or Lean call was made for this UI check. Full 15-page 1:1 visual acceptance remains open.
## Full-size reference render for all 15 Stitch screens

Rendered each supplied `stitch-current/<screen-id>/screen.html` in a local browser at a consistent 1280×900 CSS-pixel viewport and saved the full page to `golden-1280/<route>.png`. The route-to-Stitch-ID, dimensions, and SHA-256 mapping is `golden-1280/manifest.json`. Fourteen full captures are 1280 pixels wide; recognition's source export horizontally overflows to 1622 pixels, which is source behavior rather than a native screenshot defect. These captures are substantially more legible than the provided 383-pixel thumbnails and now form a consistent visual reference for all 15 pages. They contain the Stitch prototype's fictional sample content and are *design* evidence, not production AI/Lean results. Native fixture content differs, so these references do not yet prove same-data pixel parity.

On the success page, the source's context row uses three small background pills. NativeResult previously rendered one plain breadcrumb. It now renders two linked pills and an active pill containing the actual saved mathematical goal, while retaining the existing mapping/export/edit actions. Native preview AX and screenshot `screenshots/success-native-source-breadcrumb-1280.jpg` confirm the goal and actions remain visible at 1280 pt. No saved record or verification flag changed.

The preview compiled; the official SwiftUI App rebuilt with the packaged backend reused, and strict deep ad-hoc signature verification passed. All 36 backend baseline files match. The local reference rendering and fixture QA issued no DeepSeek or Lean request. Whole-page 1:1 acceptance remains open.

## Camera captured-review state and honest fixture binding — 2026-10-08

The Stitch camera reference shows a captured page waiting for review, whereas the native page previously showed only a disabled live viewfinder. The native camera now retains photo bytes after an actual AVFoundation capture, presents the image for review, supports retake, and starts the existing image-import/recognition binding only after the user selects “使用照片并开始识别”. The right column in this state now says the photo has not been recognized or verified; it no longer pairs a new trigonometric photograph with an unrelated saved algebra proof. The independent QA executable injects the user-supplied handwriting image into this captured state and labels its local preview; its preview button cannot submit the image. Production has no fixture URL.

Actual GUI inspection at 1280 pt confirmed the handwritten image and the unverified label in `native-current-1280/camera.png`. Clicking “重新拍摄” removed the photo and restored the capture controls. This checks local native state and display only: no physical camera capture, image recognition, DeepSeek, Lean or Kernel operation was run. The preview and official App builds passed; strict deep ad-hoc signature verification passed. All 36 backend baseline hashes match. The remaining page layouts and same-content 15-page pixel acceptance are not yet complete.

## Preferences font samples — 2026-10-08

Compared the original 1280 px Stitch preferences render with the native 1280 pt QA render. The three font sample cards already matched the source column widths, but were about 100 pt tall against the source's approximately 128 pt cards. Raised their minimum height to 128 pt and removed the extra teal selection border; the selected font remains indicated by its checkmark. Actual refreshed native GUI capture is `native-current-1280/preferences.png`. The preview and official App compiled, strict deep ad-hoc code-sign verification passed, and all 36 backend baseline hashes are unchanged. This was fixture-only visual QA; no DeepSeek, Lean or Kernel request was made. The 15 pages are not yet accepted as same-data 1:1 replicas.

## Aligned failure and step-detail QA states — 2026-10-08

The original Stitch failure and step-detail designs show a failed third step with earlier steps established and the fourth step blocked. The independent native preview had shown a failed first step on the failure page and a verified first step on the detail page, preventing meaningful state comparison. The preview now derives both QA states from the same local saved algebra proof, mutating only its explicit display fixture: steps 1–2 remain established, step 3 is unproved, step 4 is blocked, and the visible aggregate/feedback flags reflect that hypothetical outcome. The preview removes certificates from the hypothetical failed and blocked steps and aggregate. It is display-only test data, not a complete backend verification record. The preview notice explicitly says this is a local unproved-step sample, not a new AI or Kernel result. Production record parsing and status logic are unchanged.

Actual GUI accessibility inspection showed step 3 selected and unproved, two established predecessors, and the fourth step blocked. Updated 1280 pt captures: `native-current-1280/step-detail.png` and `native-current-1280/failure.png`. This improves like-state visual comparison; the mathematical problem and explanatory copy still differ from the Stitch sample, so same-data 1:1 acceptance is not proven. The preview compiled. No DeepSeek, Lean or Kernel request was made. The official App did not need rebuilding because only the separate QA preview executable changed.

## Camera review state consistency — 2026-10-08

The captured photo preview still showed an “启用相机” action and a right-hand card saying the camera had not been enabled. In a real capture-review state those labels contradicted the visible photo. The native camera header now swaps device-enablement controls for an “已拍摄 · 待确认” state pill after capture. Its right-hand card reports local photo preview or actual camera capture, and explicitly says recognition and verification have not been submitted. This only changes presentation around the existing capture and import binding; no provider, MathIR or Lean logic changed.

The independent SwiftUI preview with the supplied handwritten image showed the captured state and no enable-camera action; updated screenshot: `native-current-1280/camera.png`. The preview and official App built, strict deep ad-hoc signature verification passed, and all 36 backend baseline hashes match. No camera hardware, DeepSeek, Lean or Kernel call was made for this visual check. The source system-status page's fictional retry progress and telemetry remain excluded from production UI; full 15-page same-content visual acceptance remains open.

## Formal inspector tabs at 1280 pt — 2026-10-08

The native inspector's right column is about 390 pt wide at the design reference viewport. Its five original tabs were clipped after the long English “Statement Lock” label. Shortened only the visible label to “命题锁定”, retained its Statement Lock help and data binding, and reduced icon, text and horizontal spacing so Lean, MathIR, diagnostics, Statement Lock and Mathlib all fit in the column. The original Stitch panel has four tabs; the fifth native Mathlib tab remains necessary for the saved retriever record and now fits without hiding another view.

Actual native QA screenshot `native-current-1280/formal-details.png` shows all five complete labels. Clicking “命题锁定” displayed the saved statement hash and binder map; clicking Mathlib displayed saved retrieval entries without running a new search. The official App rebuilt, strict deep ad-hoc signature verification passed, and all 36 backend baseline hashes match. This was local fixture UI QA with no DeepSeek, Lean or Kernel calls. Same-data 15-page 1:1 visual acceptance remains open.
### 识别校对页：原稿完整宽度核对（2026-10-08）

Stitch 识别页的 1280 px 视口导出实际横向延伸至 1622 px。独立 SwiftUI QA 预览增加仅用于视觉检查的 1622 pt 窗口选项；在此宽度下加载用户手写原图与既有 16 片段识别响应。初次截图显示第三栏存在但右侧被裁切：三栏最小宽度合计超过可用区域约 24 pt。将中栏最小宽度由 640 pt 调整为 600 pt 后，重新编译并重启预览，同宽截图确认原图、中栏校对和右侧片段检查及操作按钮均完整呈现，横向滚动条消失。截图：`native-current-1622/recognition-handwriting.png`（3244×1800 Retina）。

这次修改仅影响 SwiftUI 识别页布局；手写识别内容仍来自保存响应，法1前导 2 保留，没有发起 DeepSeek、Lean 或 Kernel 请求。正式 macOS App 使用未更改的已打包后端完成 UI-only 重建，严格深层代码签名验证通过；36 个后端基线文件哈希全部一致。与 Stitch 的同数据逐像素、全页 15 屏验收仍未完成。

## 多模态导入页：原稿顶部空间对齐（2026-10-08）

对照 `golden-1280/import.png` 和原生 1280 pt 截图，Stitch 介绍卡约从 y=80 到 218 pt，四个入口从 y=243 pt 开始；原生介绍卡先前约从 y=107 到 199 pt，入口约 y=223 pt。仅在桌面四列布局中，将介绍卡内容最小高度定为 98 pt，并将该页内容上移 24 pt。重新编译并实际打开独立 SwiftUI QA 预览后，截图 `native-current-1280/import.png`（2560×1800 Retina）显示介绍卡约 y=84–222 pt、四个入口约 y=246 pt，顶部结构与原稿更接近。窄窗口布局保持原先流式排列；导入与校对按钮仍指向原业务动作。

正式 macOS App 使用未变的后端包完成 UI-only 重建，严格深层签名验证通过；36 个后端基线文件均未改变。这是保存响应的视觉 fixture 检查，没有 DeepSeek、Lean 或 Kernel 请求。页面里的原稿数据与 Stitch 演示数据不同，不构成同数据逐像素验收；其余 14 页和全页差异仍需继续逐项验证。

## 验证通过页：结论卡和步骤区纵向基准（2026-10-08）

将 `golden-1280/success.png` 与原生保存记录预览对照，Stitch 的结论卡约为 y=144–465 pt，逐步核验区从约 y=496 pt 开始；原生版导航行和结论卡整体偏低，结论卡偏矮。仅对成功结果页内容上移 24 pt，并将结论卡内部最小高度增至 256 pt（外卡约 320 pt）。实际重建并打开 SwiftUI QA 预览后，更新截图 `native-current-1280/success.png`（2560×1800 Retina）：结论卡约 y=146–465 pt，步骤区约 y=497 pt 开始。失败结果布局不受此条件化修改影响；证明状态、核验指标、步骤记录和依赖图数据绑定未改。

正式 App 的 UI-only 构建与严格深层代码签名验证通过，36 个后端基线文件哈希未改变。此次仅以已有记录进行界面检查，没有新的 DeepSeek、Lean 或 Kernel 调用。原稿与 fixture 的数学内容不同，且 Stitch 为 1770 px 全页截图，当前原生证据为 900 pt 窗口视图；15 页的同数据全页 1:1 验收仍未完成。

## 偏好设置页：标题、标签栏与双栏卡片纵向对齐（2026-10-08）

对照 `golden-1280/preferences.png` 与原生 1280 pt 页面，双栏宽度及字体样张高度已接近原稿，但标题、标签栏和卡片整体低约 32 pt。仅对桌面宽度下的偏好设置内容上移 32 pt，窄窗口流式排列保持原样。实际重建并打开独立 SwiftUI QA 预览后，`native-current-1280/preferences.png`（2560×1800 Retina）显示标签栏约从 y=196 pt 开始（原稿约 y=194 pt），双栏卡片约从 y=277 pt 开始（原稿约 y=274 pt）。设置项及持久化绑定未改。

正式 macOS App UI-only 重建及严格深层代码签名验证通过；36 个后端基线文件全部未变。本次仅查看本地 fixture UI，没有 DeepSeek、Lean 或 Kernel 请求。原稿中的版本、同步速度和服务状态等演示数据未被伪装成实际运行状态；15 页的完整同数据视觉验收仍未完成。

## 修改原证明页：第 3 步同状态对照与前序卡片高度（2026-10-08）

原 Stitch 编辑页聚焦 Step 3，原生 QA 截图先前却聚焦 Step 1。独立预览在进入编辑页时现在选中保存记录的第 3 步，保留前两步作为同状态对照；这只改显式 UI fixture，不影响正式 App 默认选步或验证。对照后发现 Stitch 前两张既有步骤卡约各 100 pt，而原生每张约 48 pt，导致主编辑卡过早出现。正式 SwiftUI 的已保存步骤卡现至少 100 pt 高，并在第二层呈现同一记录的 `row.original` 原稿文本，而非默认加入 Lean 代码。实际原生截图 `native-current-1280/editing.png`（2560×1800 Retina）显示前两步和“对照步骤 3”，活动编辑卡约 y=419 pt 开始，接近原稿约 y=425 pt。原稿数学内容与 Stitch 演示的柯西-施瓦茨证明不同，不能据此宣称逐像素相同。

正式 macOS App 已 UI-only 重建，严格深层代码签名验证通过；36 个后端基线文件哈希不变。编辑、提交验证与记录状态绑定未改；本次仅使用保存响应观察界面，没有 DeepSeek、Lean 或 Kernel 请求。15 页完整同数据全页验收仍未完成。

## 首页：首屏标题、输入与路径卡纵向对齐（2026-10-08）

对照 Stitch `golden-1280/welcome.png` 与原生 1280 pt 首页，内容宽度基本吻合，但状态胶囊、Σ 图形、主标题、输入条和三张验证路径卡整体低约 30 pt。仅在桌面宽度下将首页内容上移 32 pt，不改窄窗口布局或输入/验证绑定。重新编译并实际打开独立 SwiftUI QA 预览后，`native-current-1280/welcome.png`（2560×1800 Retina）显示标题顶部约 y=225 pt（原稿约 y=228 pt），路径卡顶部约 y=564 pt（原稿约 y=558 pt）。本机服务状态仍按实际状态显示，未复制原稿虚构的版本、延迟与示例核验结论。

正式 macOS App 完成 UI-only 重建并通过严格深层代码签名验证；36 个后端基线文件哈希一致。本轮只使用保存记录查看 UI，没有 DeepSeek、Lean 或 Kernel 请求。原稿为 1836 px 全页截图，当前原生证据只覆盖 900 pt 视口；全 15 页同数据、全页 1:1 验收仍未完成。

## 系统状态页：真实状态与顶部布局（2026-10-08）

对照 `golden-1280/system-error.png`，原生状态页的顶部介绍卡偏低、下方双栏过早出现。桌面布局现将顶部内容上移 28 pt，并给卡片内容保留 160 pt 最小高度。实际重新编译、重启独立 SwiftUI 预览后，`native-current-1280/system-error.png`（2560×1800 Retina）显示顶部卡片从约 y=80 pt 开始，状态条和双栏分组保持完整。曾尝试更高卡片，但出现无内容的大块空白，已在同轮缩回；当前顶部仍比 Stitch 设计短，未声称 1:1。

Stitch 参考包含演示用的自动重试进度、AI 服务遥测和资源指标，当前正式 App 没有这些可核实数据，因此本页只绑定本机服务是否就绪、运行任务、保留原稿及既有核验记录。独立 QA 截图明确标注为本地错误状态 fixture。正式 macOS App 已 UI-only 重建，严格深层代码签名验证通过，36 个后端基线文件哈希不变。本轮没有 DeepSeek、Lean 或 Kernel 请求；同数据全页 15 屏逐像素验收仍未完成。

## 首页：多行数学草稿的折叠预览与编辑（2026-10-08）

此前首页快速输入条把已有多行证明强制放在 20 pt 单行视口，预览只拼接全文并截断，聚焦后也仍只显示一行。现在折叠态显示原稿首行和实际非空行数；用户点击后，原生 AppKit 文本控件局部展开到 104 pt 多行编辑区，首次聚焦定位草稿开头。其余首页仍由 SwiftUI 实现，输入绑定保持 `store.editDraft`，开始核验仍调用既有 `store.verify`，原稿没有被压平成单行。实际 1280 pt QA 预览点击后，`native-current-1280/welcome-multiline-active.png` 显示题目、目标式和证明开头；可访问性树仍含完整原稿。输入一个临时 ASCII 字符后，AX 显示它出现在原稿首部；首次发现 ⌘Z 无效，于是为这个 AppKit 控件启用撤销支持。重新编译并重启后复测，同样输入再按 ⌘Z，AX 确认原文恢复。未点击核验按钮。

独立 QA 使用本地保存记录，未运行 DeepSeek、Lean 或 Kernel。正式 macOS App 已 UI-only 重建并通过严格深层代码签名验证，36 个后端基线文件哈希一致。展开态是输入交互状态，不等同 Stitch 静态首页图；15 页同数据全页 1:1 验收仍未完成。

## 原稿对应页：手写原图与历史未通过记录同屏（2026-10-08）

此前 `source-mapping` 的原生截图仅使用纯文本保存记录，无法检查 Stitch 三栏布局中的真实图片状态。独立 SwiftUI QA 预览现可加载已经保存的 `handwritten-mathir-kernel-live.json` 和原用户手写图片；记录中的 MathIR 含 11 个来源片段、12 个证明步骤，最终 `kernelVerified=false`。预览将图片仅作为本地显示资源，不向后端重新上传或调用 Provider。正式 App 仍按记录的 asset ID 向本机后端取图；本地图片覆盖只由独立 QA 预览注入。

实际 GUI 在 1280 pt 窗口显示左侧手写原图、中间来源片段与高亮、右侧所选步骤的数学陈述和“尚未证明”状态。点击第 2 步和第 10 步后，AX 均确认相应原文与数学陈述同步切换。步骤条在 12 个均未证明的历史步骤下原先重复显示长状态而拥挤；现在非选中项显示状态圆点、选中项保留文字，并为每个按钮保留完整可访问状态。截图：`native-current-1280/source-mapping-handwriting.png`（2560×1800 Retina）。

Stitch 原稿使用另一道数学题，并绘制了细粒度图上框选、OCR 信心和自动修复选项。历史数据只提供步骤级来源，当前图片不显示虚构的笔画框或字符坐标，三栏因此还不是同数据 1:1。正式 macOS App 已 UI-only 重建，严格深层签名验证通过；36 个后端基线文件哈希未变化。这轮没有新 DeepSeek、Lean 或 Kernel 请求。15 页全页视觉验收继续保持未完成。

## 原稿对应页：照片视口占比（2026-10-08）

复查手写映射截图与 `golden-1280/source-mapping.png`，源设计在左栏以较大比例展示纸张，原生 100% 全图将横向照片中的竖版纸张缩成了视口中央的小图，周围留白过多。此页的 `SourceImage` 现以 180% 初始缩放显示；实际 GUI 截图 `native-current-1280/source-mapping-handwriting.png` 显示整张纸明显更大、原稿笔迹更可辨，三栏位置与步骤状态未变。点击“恢复全图”后，AX 从 180% 回到 100%，用户仍能查看完整原图。对其他长宽比照片的默认裁切尚未逐一验收。

核对自定义公式视图后，先前 AX 中显示的 LaTeX 源串只是读屏标签；视觉截图里的三角表达式已渲染为数学文字，因此没有改 MathPresentation、MathIR 或输入数据。正式 App UI-only 重建及严格深层签名验证通过；36 个后端基线文件不变。没有 DeepSeek、Lean 或 Kernel 调用；这仍不是 15 页的同数据全页 1:1 验收。

## 歧义确认页：真实手写样例与纵向基准（2026-10-08）

旧 QA 截图将代数证明原稿与凭空添加的 `n / π` 候选读法放在同一页，不能用于同状态视觉核对。独立 SwiftUI 预览在进入“符号歧义”时现在加载已保存的手写三角多项式记录：MathIR 有 4 处未决歧义，第一处的两种读法围绕蓝色下划线及下方小符号。左侧显示同一手写原图，图片只通过 QA 环境注入；正式 App 仍使用本机 asset ID。点击候选项仅改变本地选中样式，未点击“按此选择修改原文”。状态继续显示待确认与历史未通过核验，不伪装成已证明。

对照 `golden-1280/ambiguity.png`，原生底稿卡原先较短、页面起点较低，主卡状态区也较短，使候选卡提早出现。桌面版将底稿卡内容最小高度设为 124 pt（外卡约 172 pt）、状态区最小高度 128 pt，并将本页内容上移 28 pt。实际重编译重启后的 `native-current-1280/ambiguity-handwriting.png`（2560×1800 Retina）显示底稿卡约 y=76–244 pt、主卡约 y=268 pt 开始、状态区约 y=300–428 pt、候选卡约 y=746 pt 开始，接近原稿相应布局。窄窗口布局没有套用这些桌面高度。

原 Stitch 图包含示例笔画局部裁切、置信度、自动推荐和批量替换；本历史记录缺少可验证的笔画坐标与置信度，当前界面只呈现实际可知的原图、原文和候选读法。因此仍不能认定为同数据 1:1。正式 macOS App UI-only 构建及严格深层签名验证通过，36 个后端基线文件哈希不变。本轮没有新的 DeepSeek、Lean 或 Kernel 请求；15 页全页验收仍未完成。

## 核验中页：纵向基准（2026-10-08）

对照 `golden-1280/verifying.png`，原生页的输入摘要、流水线和双栏内容整体约低 28 pt。仅在宽窗口将 `NativeVerifying` 的页面内容上移 28 pt；窄窗口保持原布局。重新编译独立 SwiftUI 预览并经实际 GUI 截图保存为 `native-current-1280/verifying.png`。在 1280×900 pt 视口中，输入摘要顶部约 y=84 pt、流水线顶部约 y=184 pt、双栏顶部约 y=370 pt；Golden 相应位置约 y=80、185、372 pt。

预览中的证明内容和 `verifying` 状态是显式 QA 样例，不能解释为正在执行的 Lean 任务。此轮只核对布局，没有调用 DeepSeek、Lean 或 Kernel。正式 App 已用未变的打包后端重新构建，严格深层签名验证通过，36 个后端基线文件哈希不变；15 页同数据全页 1:1 验收仍未完成。

## 偏好设置页：字号卡与开关布局（2026-10-08）

对照 `golden-1280/preferences.png`，原生版原先在字号卡增加一条不在 Stitch 原稿中的滑杆，并把“按需查看形式化”单独放在下一张卡，导致左栏分段与高度偏离参考。现在字号卡保留 14/16/18 pt 三种可选值，移除多余滑杆，并把现有“显示形式化细节”开关放到字号卡底部。开关仍准确表达其真实功能，没有将它改名为 Stitch 示例中不同含义的数学渲染开关。字体选项继续使用本机内置字形，改为与原稿接近的简短风格说明，不显示未经核实的字体包大小。

重新编译独立 SwiftUI 预览，并在隐藏 QA 工具栏后保存实际 GUI 截图 `native-current-1280/preferences.png`；1280×900 pt 视口中顶部双栏卡约 y=277 pt，尺寸卡约 y=534–792 pt。正式 App UI-only 重建及严格深层签名验证通过，36 个后端基线文件哈希不变。本轮没有 DeepSeek、Lean 或 Kernel 调用。这仍不是 15 页同数据全页 1:1 验收。

## 多模态导入页：四卡入口对应（2026-10-08）

对照 `golden-1280/import.png`，原生四卡原先依次为文件、数学文本、相机、手写，和 Stitch 的拖入、剪贴板、相机、文档四栏不对应。现调整为拖入/选择文件、剪贴板粘贴、系统相机、文档导入；这些入口仍绑定已有文件导入、粘贴与相机动作。手写画布保留在页面下方操作条，实际通过 AX 点击后出现手写原稿画布、撤销笔画和识别按钮。文档卡没有声称已支持未实现的结构树解析。

独立 SwiftUI 预览重编译后，在隐藏 QA 工具栏的 1280×900 pt 视口保存 `native-current-1280/import.png`，四卡仍约在 y=246 pt 开始，与 Golden 约 y=243 pt 的几何位置接近。Golden 的五条不同状态、耗时、模型识别结果和硬件数据是示例，当前页面只显示实际保存的一份原稿和一个片段，未伪造五项队列。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件哈希不变。本轮没有 DeepSeek、Lean 或 Kernel 调用；同数据全页 1:1 尚未达成。

## 系统状态页：提示卡与诊断卡组纵向基准（2026-10-08）

`golden-1280/system-error.png` 的顶部提示卡约 y=80–357 pt，诊断卡组约 y=421 pt 开始；原生页原先顶部提示卡约 y=80–281 pt，使后续卡组提前约 70 pt。将宽窗口提示区最小高度调至 236 pt，并加入当前原稿字数、是否已有核验记录和存在时的诊断码等真实可读字段。没有使用 Stitch 示例中未发生的 Provider 超时、沙箱重连、内存保护、索引失败或自动重试数据。

重新编译独立 SwiftUI 预览，并在隐藏 QA 工具栏的 1280×900 pt 视口保存 `native-current-1280/system-error.png`；顶部提示卡约 y=80–354 pt，诊断卡组约 y=423 pt 开始。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件哈希不变。没有 DeepSeek、Lean 或 Kernel 调用。页面状态内容仍与 Golden 示例不同，不能视为 1:1 全页验收。

## 首页：空输入状态对应（2026-10-08）

`golden-1280/welcome.png` 的核验输入框为空，显示提示文字；旧原生 QA 截图却把已保存代数证明预先填入，无法对照同一输入状态。仅调整独立 `NativePreviewApp`：进入首页时把输入草稿清空，保留已保存记录供下方示例展示，其他页面仍由原录制样例载入。生产 App 的用户草稿保存和提交流程未改动。

重编译独立 SwiftUI 预览后经实际 GUI 与 AX 检查：首页输入框为空并显示“粘贴推导文本，或输入原题与证明…”提示；截图保存为 `native-current-1280/welcome.png`。这使首页输入状态可与 Stitch 原稿比较，仍不代表下方示例数学内容同数据，或 15 页全页 1:1 完成。没有调用 DeepSeek、Lean 或 Kernel；本轮没有重建未改动的正式 App。

## 摄像头页：拍摄照片视口与完整原图切换（2026-10-08）

`golden-1280/camera.png` 的纸张填满主拍摄视口；原生预览此前将 16:9 的真实手写照片 `scaledToFit` 放入 4:3 区域，上下留白较大且笔迹偏小。拍摄后的照片现在默认以 `fill` 显示，并在原稿预览标题栏提供“显示全图 / 填满视口”切换。切换仅改变视口裁切，不更改照片数据，也不影响照片确认或识别提交；相机实时取景沿用原有预览行为。

独立 SwiftUI 预览重编译后，经实际 GUI 使用用户提供的手写三角多项式照片验证：默认填满视口，点击“显示全图”出现完整照片，再点击“填满视口”恢复放大显示。填充状态截图保存为 `native-current-1280/camera.png`。QA 样例仍显示“尚未识别或验证”，没有生成假 OCR 叠加层或设备遥测。正式 App UI-only 重建和严格深层签名验证通过，36 个后端基线文件哈希不变；本轮没有 DeepSeek、Lean 或 Kernel 调用。此页仍非同数据全页 1:1。

## 形式化细节页：顶栏避让与内容起点（2026-10-08）

对照 `golden-1280/formal-details.png`，原生工具条和双栏内容整体偏低。首次尝试将整个页面上移 28 pt，实际 GUI 截图发现工具条被应用顶栏遮挡，已撤回该位移。最终仅在宽窗口上移 12 pt；重新编译独立 SwiftUI 预览并在 1280×900 pt 视口检查，工具条保持完整可见，双栏首卡约 y=137 pt，较原先约 y=149 pt 接近 Golden 的约 y=119 pt。截图保存为 `native-current-1280/formal-details.png`。更大位移需要先改变顶栏布局，不能以遮挡操作按钮为代价。

页面仍展示当前保存的代数证明及其真实记录字段，Stitch 原图中的柯西–施瓦茨定理、实时 AST、耗时和形式化置信度并非本记录，不予填造。Lean/MathIR/诊断只在主动打开该页时显示。正式 App UI-only 重建和严格深层签名验证通过，36 个后端基线文件哈希不变；没有 DeepSeek、Lean 或 Kernel 调用。此页未达到同数据全页 1:1。

## 识别校对页：三栏同时可见（2026-10-08）

对照 `golden-1280/recognition.png`，原生识别页已有原图、识别文本和校对侧栏三个区域，但固定宽度合计超出 1280×900 pt 视口；右侧栏落在横向滚动区外，截图只显示两栏。改为按页面可用宽度分配 26%／48%／26%，列间距 16 pt，使三栏同屏。未更改识别、校对保存或验证提交逻辑。

重新编译独立 SwiftUI 预览，使用用户手写三角多项式照片及已保存的 16 个识别片段，在实际 GUI 中确认三栏同屏，并保存 `native-current-1280/recognition-handwriting.png`。第二片段保留用户确认的 `2cos(k+2)θ` 前导 2。右栏只展示实际片段编号、核对提示与业务按钮，不填造 Stitch 示例的置信度或笔画级定位。正式 App UI-only 重建及严格深层签名验证通过，36 个后端基线文件哈希不变；没有调用 DeepSeek、Lean 或 Kernel。三栏结构接近 Golden，但数学样例及文案不同，仍未达到同数据全页 1:1。

## 符号歧义页：原图显示核对（2026-10-08）

对照 `golden-1280/ambiguity.png` 和手写样例的原生截图，确认两栏上下文、候选读法卡与步骤导航结构已实现。曾尝试将原图默认放大至 250%，实际 GUI 截图发现该倍率居中裁掉了本题靠上的蓝色笔迹，因此已撤回；最终保留完整原图及用户可操作的放大、拖动控件。当前来源映射只保证步骤级，不能据此自动给某个笔画定位。最终 100% 全图状态的截图已重新保存到 `native-current-1280/ambiguity-handwriting.png`。

同时修正识别页空状态：没有原稿片段时显示“尚未载入原稿片段”，不再显示矛盾的“当前片段 1 / 0”。独立 SwiftUI 预览和正式 App 重新编译通过，严格深层签名验证通过，36 个后端基线文件哈希不变。没有 DeepSeek、Lean 或 Kernel 调用；符号歧义页与 Stitch 的示例数学数据仍不同，不能认作同数据全页 1:1。

## 数学工作台：工具栏完整显示（2026-10-08）

对照 `golden-1280/workspace.png`，原生工作台的三栏首卡与原稿几何位置接近，但 1280 pt 宽窗口里排版工具栏末端的“形式化细节”被截断。收紧该行按钮的字号和水平内边距后，实际 GUI 截图确认 H1/H2、定理/引理/证明段、公式、手写/截图、导入原稿、符号速查表、原稿对应、形式化细节均可同屏看见。截图更新为 `native-current-1280/workspace.png`，仍使用已有代数证明记录。

独立 SwiftUI 预览与正式 App 均重新编译成功，正式 App 严格深层签名验证通过，36 个后端基线文件哈希不变。没有调用 DeepSeek、Lean 或 Kernel。工作台布局继续采用 Stitch 的三栏与操作层级；Golden 中的柯西–施瓦茨例题和动态遥测不是本保存记录，不据此填造，也未达到同数据全页 1:1。

## 验证进行中页：已完成处理阶段标记（2026-10-08）

对照 `golden-1280/verifying.png`，原生顶部状态卡、五阶段管道和下方双栏的几何位置已经接近。此前在任务事件表明流程已进入“内核核验”时，前三个处理阶段仍显示灰色数字。现在由已有的 `stage` 决定：当前阶段保留运行指示，已经越过的阶段显示青色勾，后续阶段仍显示等待。这个勾只指处理阶段已越过，不推断某个证明步骤或 Kernel 已通过。

独立 SwiftUI 预览重编译后，在实际 GUI 的已保存任务状态样例中确认前三阶段显示完成标记、内核核验显示 Running、结果整理显示等待；截图更新为 `native-current-1280/verifying.png`。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件哈希不变。没有调用 DeepSeek、Lean 或 Kernel；Golden 的动态耗时、PID、缓存和证明通过状态没有真实对应数据，因此未填造。同数据全页 1:1 仍未完成。
## 原稿对应页横向照片显示（本轮）

用户提供的 4000×2252 横向照片在约 300×470 pt 的左栏中按全图适配时，手写纸张只占很小的中央区域。`SourceImage` 现支持仅由原稿对应页启用的“适合高度”：根据本地图片宽高比和实际栏宽计算缩放，默认显示照片的完整高度；较宽部分在水平方向裁切。点击“恢复全图”可随时查看未经裁切的整张照片。其它输入页仍保持原有显示方式，步骤对应仍为步骤级，不宣称笔画或字符定位。

独立 SwiftUI 预览重编译，在实际 GUI 用用户手写三角多项式照片检查：默认可见从题干至底部结论的完整高度，点击“恢复全图”后横向黑边及整张原图均可见；截图保存于 `native-current-1280/source-mapping-handwriting.png`。正式 App UI-only 重建与严格深层签名验证通过；36 个后端基线文件哈希不变。未调用 DeepSeek、Lean 或 Kernel。此页仍未完成同源数学数据的整页 1:1 像素验收。

## 首页保存记录的原稿预览

全页滚动核对发现：独立预览为对齐 Stitch 的空输入状态清空了草稿，但仍保留核验记录；下方预览于是右侧有步骤关系，左侧数学原稿却空白。`NativeWelcomeProofPreview` 现在优先显示当前非空草稿；草稿为空且有保存记录时，读取该记录 MathIR 来源中的 `normalized` 原文；仅当此字段缺失时退回保存步骤的原文。没有记录时继续显示空状态。此改动只影响显示，未把旧证明写入新草稿或重新提交核验。

独立 SwiftUI 预览重新编译后，实际 GUI 检查了空草稿加已保存的真实代数证明记录：左栏显示原题及完整原有推导，右栏同时显示四步依赖关系；截图为 `native-current-1280/welcome-record-preview.png`。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件无变化。未调用 DeepSeek、Lean 或 Kernel；Stitch 的演示题目与这份实际保存记录不同，仍不构成同数据整页 1:1 验收。

## 摄像头照片信息栏

对照 `golden-1280/camera.png`，Stitch 的已拍摄状态在照片下方有图片信息栏。原生 `NativeCamera` 现在只在已有照片时显示该结构：从图片数据读取真实像素宽高，从字节数显示真实文件大小，并显示“尚未识别”。本地 fixture 明确标作“本地原图”；真实相机拍摄标作“相机原图”。没有移植 Golden 的假设备名、耗时、清晰度分数或 AI 结果。

独立 SwiftUI 预览重新编译，在实际 GUI 使用用户照片核对信息栏为 `4000 × 2252 px`、`1.8 MB`，并保存 `native-current-1280/camera.png`。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件无变化。未调用 DeepSeek、Lean 或 Kernel。此页面仍因参考截图采用不同照片及演示遥测，未达到同数据整页 1:1。

## 导入页保存记录来源显示

跨页检查发现：预览已载入手写证明的保存记录后，导入页此前只读取当前 `recognition.blocks`；该样例没有单独加载识别修订，因此错误显示 `0 份原稿 · 0 个片段`。导入页现和原稿对应页一样读取 `sourceBlocks`（保存记录的 MathIR 来源优先，尚无记录时使用当前识别片段），在卡片与底部状态显示一致的数量。对本地文件的缩略图直接使用 NSImage；远程资产仍用现有 AsyncImage。没有改动来源或验证数据。

独立 SwiftUI 预览重新编译，使用用户手写照片和已保存的映射记录实际 GUI 检查：导入页显示 `1 份原稿 · 11 个片段`、原题和原图缩略图，截图 `native-current-1280/import-handwriting.png`。在没有独立识别修订的保存记录上点击“校对”，实际进入可用的原稿对应页；存在识别修订时仍进入片段校对。正式 App UI-only 重建与严格深层签名验证通过，36 个后端基线文件未变。未调用 DeepSeek、Lean 或 Kernel。Golden 的五条混合状态队列是不同演示数据，仍未完成同数据整页 1:1。

## 歧义候选读法与原文校对绑定

全页滚动检查符号歧义页时发现确认按钮在未选择候选项时仍呈可用；切换歧义项还将候选置为空字符串，旧处理函数可能把该空串写进来源片段。更关键的是这份已保存的 MathIR 候选包含“蓝色下划线及下方小符号是分数线或标记”这样的**读法说明**，来源范围却跨整个 75 字片段；旧按钮会把整段原文替换成说明文字。这并非忠实校对。

现仅在当前歧义项明确选中候选读法时启用“按此读法校对原文”；切换项清除选择。候选读法作为编辑参考，进入已有的识别修订页或原稿编辑页，由用户核对并实际修改文字；候选说明本身不再被当作替换文本写入原稿。这是 UI 与已有校对流程的绑定修正，未改 MathIR、Statement Lock、Lean 或验证逻辑。

独立 SwiftUI 预览编译后，在真实 GUI 的手写样例中验证：未选择时按钮 disabled，选中第一种读法后启用，点击后进入原稿编辑，文本对比显示移除 0 行、新增 0 行，原文仍含用户确认的 `2cos(k+2)θ`。截图 `native-current-1280/ambiguity-review-no-mutation.png`。正式 App UI-only 重建和严格深层签名验证通过，36 个后端基线文件未变；无 DeepSeek、Lean 或 Kernel 调用。Golden 示例与当前数学内容不同，整页 1:1 仍未验收。

## 未完成证明页的长步骤依赖图

使用已保存的十二步手写证明记录检查时，右栏原证明依赖影响图原先把全部节点压进约 300 pt 宽度，圈和步骤标签相互重叠。现在仅在此卡片内按实际步骤数展开图的宽度，并允许横向滚动；步骤状态和依赖连线仍来自记录。四步样例保持原布局。

独立 SwiftUI 预览重新编译后，实际 GUI 确认十二步记录的前几步节点间距正常，横向滚动到末端可看见步骤 8–12，截图为 `native-current-1280/failure-handwriting-graph.png`。正式 App UI-only 重建及严格深层签名验证通过，36 个后端基线文件未变。未调用 DeepSeek、Lean 或 Kernel。未完成证明页仍未达到同数据整页 1:1 像素验收。

## 未完成证明页顶部卡片纵向对齐

对照 `golden-1280/failure.png` 与四步保存记录的原生截图，顶部结果卡原先约 264 pt 高，Stitch 参考卡约 365 pt，高度差让状态四格与逐步核验列表过早出现。现在为标题与诊断区保留 150 pt 最小高度；较长的真实诊断仍可自然撑开，不向短记录补造说明。新截图中卡片约 350 pt 高，状态与列表的纵向位置更接近 Golden。

独立 SwiftUI 预览编译并在实际 GUI 检查四步样例，截图更新为 `native-current-1280/failure.png`。正式 macOS App UI-only 重建、严格深层签名验证通过，36 个后端基线文件哈希不变。没有调用 DeepSeek、Lean 或 Kernel。参考图使用不同数学题和诊断内容，因此同数据整页 1:1 仍未验收。

## 验证结果横幅的右上光晕

对照 Stitch 当前导出 `aade4d47c3a94439a72dbffdffd4a91d/screen.html`，成功横幅在 `bg-surface-container-low` 上叠有右上方 `bg-primary/5` 的 320 pt 模糊圆形。原生 `StitchCard` 现可选择此装饰，仅用于已核验结果横幅；未核验卡片和其它页面仍使用原背景。此改动不改变状态来源或数学内容。

SwiftUI 预览重新编译并在实际 GUI 核对：横幅右上区域呈淡青绿色，标题、四格数据及下方证明步骤布局保持，截图更新为 `native-current-1280/success.png`。正式 App UI-only 重建、严格深层签名验证通过，36 个后端基线文件未变；没有新 DeepSeek、Lean 或 Kernel 调用。参考图的定理、遥测和引理记录与本地保存证明不同，同数据整页 1:1 尚未验收。

## 识别校对页手写原稿概览

已保存的 4000×2252 横向照片按整张宽度缩进左侧窄栏时，原稿纸张在 224 pt 概览视口中太小。识别校对页现默认按图片高度展示，宽出的边缘由视口裁切；“恢复全图”仍显示完整照片。共用的 `SourceImage` 明确为图片视口保留 224 pt 高度，缩放栏排在图片下方，不再压住照片。窄栏里缩放栏用简短百分比和恢复图标，辅助功能名称仍是完整的“适合高度 / 恢复全图”。

独立 SwiftUI 预览重新编译，实际 GUI 使用用户手写照片与已保存的 16 片段响应检查：默认纸张更大，缩放控件不重叠；点击“恢复全图”后整张照片可见。截图更新为 `native-current-1280/recognition-handwriting.png`，并复查了共用视口的原稿对应页。正式 App UI-only 重建及严格深层签名验证通过，36 个后端基线文件未变。没有调用 DeepSeek、Lean 或 Kernel；此检查不代表新的识别结果，整页同数据 1:1 仍未验收。

## 摄像头原稿默认完整呈现

摄像头拍摄后的确认视口此前默认使用 `fill`，宽幅原图在 4:3 视口里会裁去左右边缘，可能遮住纸张边缘或证明内容。现在默认按完整原图 `fit`，可手动点“填满视口”查看裁切放大效果，再点“显示全图”返回。此项只改变原生 SwiftUI 图片显示，不修改识别或后端流程。

独立 SwiftUI 预览重新编译，并在实际 GUI 用用户的 4000×2252 手写照片检查：首屏可见整幅照片、按钮显示“填满视口”，截图更新为 `native-current-1280/camera.png`。正式 App UI-only 重建、严格深层签名验证通过，36 个后端基线文件哈希无变化。未调用 DeepSeek、Lean 或 Kernel。Stitch 参考使用不同照片与演示遥测，本页尚未完成同数据整页 1:1 验收。

## 系统状态页顶部几何

对照 `golden-1280/system-error.png`，系统状态页参考的主说明区约 200 pt，底部浅灰状态条约 75 pt。原生此前把主说明区留到 236 pt，而状态条只有约 39 pt，导致空白比例和状态层级偏离。宽屏原生布局已改为 200 pt 说明区、约 75 pt 状态条；窄屏仍由文字自然撑开。状态条继续显示真实服务、原稿和任务状态，没有引入参考图中的重连次数、耗时、内存或服务遥测。

SwiftUI 预览重新编译并在实际 GUI 检查，状态条起点与 Stitch 参考接近，截图更新为 `native-current-1280/system-error.png`。正式 macOS App UI-only 重建及严格深层签名验证通过，36 个后端基线文件无变化。未调用 DeepSeek、Lean 或 Kernel。参考图是有故障事件的演示状态，本地预览是尚未就绪状态，不能作为同数据整页 1:1 验收。

## 形式化细节页的证明闭合节点

对照 `golden-1280/formal-details.png`，形式化步骤列表在全部步骤之后有一个独立的证明闭合卡片。原生列表此前到最后一个步骤就结束。现在仅当保存记录的现有 `verified` 判定为真时，按同一序号节奏显示“证明闭合／全部证明步骤已核验／KERNEL 已核验”；未通过的记录不显示闭合节点。此处只读取既有判定，没有修改 Kernel、Statement Lock 或证明结果。

SwiftUI 预览重新编译，实际 GUI 的可访问性树确认 4 个已核验步骤之后出现第 5 个闭合卡片；滚动到页尾后目视确认该卡与四项核验指标正常排列，截图 `native-current-1280/formal-details-closure.png`。正式 App UI-only 重建及严格深层签名验证通过，36 个后端基线文件无变化。本轮未调用 DeepSeek、Lean 或 Kernel。Stitch 示例使用不同定理与形式化代码，整页同数据 1:1 仍未验收。

## 形式化检查器的代码视口与底部层级

对照 Stitch 的 `formal-details` 原始 HTML 和截图，右侧检查器有代码上方来源行、有限高度代码区、下方诊断卡与底栏。原生此前将完整 Lean 脚本直接撑开整列，长证明使右栏远长于左栏。形式化细节页现在把代码放在 440 pt 的纵向视口中，横向代码滚动仍保留；来源行显示保存的脚本及实际行数，诊断卡显示保存记录中的真实诊断条数，底栏显示当前记录的 Kernel 判定。其它页面复用的检查器仍保持原行为。没有添加不存在的文件路径、执行耗时或工具链版本。

SwiftUI 预览重新编译后，实际 GUI 确认 59 行脚本在代码视口中可纵向滚动（滚动值从 0 变到约 0.53），下方诊断卡读取到 1 条保存的诊断，并显示来源与已保存的 Kernel 状态。截图 `native-current-1280/formal-details-inspector.png`。正式 App UI-only 重建、严格深层签名验证通过，36 个后端基线文件无变化；没有新 DeepSeek、Lean 或 Kernel 调用。同数据整页 1:1 仍未验收。

## 识别校对页三列宽度反馈问题

在 1280 pt 预览窗口中，识别校对页此前用页面内容自身的 `GeometryReader` 宽度反复计算三列。中间校对内容的固有宽度会把页面撑大，计算又把左、中、右列进一步放大，最终右侧检查栏溢出窗口并出现水平滚动。现在由原生根视图直接传入窗口分配给内容区的宽度（窗口宽度减 240 pt 侧栏与两侧各 24 pt 内边距），按照 Stitch 原有 26%／48%／26% 比例分配三列。这是布局约束修复，未改识别数据或用户核验逻辑。

独立 SwiftUI 预览重新编译，实际 GUI 在 1280 pt 窗口分别检查了数学文本样例和用户手写原稿加 16 片段保存响应：左侧原稿、中间校对、右侧检查与操作都在窗口内，截图更新为 `native-current-1280/recognition.png`、`native-current-1280/recognition-handwriting.png`。正式 macOS App UI-only 重建、严格深层签名验证通过，36 个后端基线文件未变。未调用 DeepSeek、Lean 或 Kernel。Stitch 识别页参考使用另一份原稿及 1622 px 视口，同数据整页 1:1 尚未验收。
## Welcome saved-proof preview structure

The welcome preview now renders recorded proof rows as numbered native mathematical steps beside the existing dependency graph. Each row opens its corresponding recorded step; an unestablished row is marked “尚未证明” using its saved status. When no record exists, the original draft preview remains available. This follows the Stitch two-column visual hierarchy without copying its fictional sample proof or adding a submission. The explicit native fixture preview compiled, displayed all four saved algebra steps, and clicking step 1 opened the matching detail page. The official macOS App rebuilt and passed `codesign --verify --deep --strict`; backend baseline comparison found 0 changed files among 36. No live AI or Lean request was made. This is not matched-data pixel acceptance for all 15 screens.
## Source mapping long manuscript segments

The handwritten proof fixture has 11 recorded source fragments and 12 proof steps. Previously every fragment expanded the center column vertically, pushing its proofreading control and the page action row far below the image and proof panels. The native mapping page now caps the fragment list at 480 pt and scrolls it independently when there are more than four fragments; short records retain their natural height. In the explicit native fixture, AX exposed the nested scroll area, scrolling it reached the final fragments while the selected proof step and source image stayed in place. Capture: `native-current-1280/source-mapping-handwriting-bounded.png`. No source text, provenance, mathematical status, image precision, AI call, or Lean proof was changed. Preview and official macOS App builds passed; official signature verified; backend baseline remains 36 unchanged files. Full 15-screen 1:1 acceptance is still incomplete.
## Import clipboard-card preview

The Stitch import screen includes a compact content preview inside the second gateway card. The native import page now shows a single-line preview of the actual current mathematical draft when one exists, with truncation inside the card. It does not claim that a clipboard capture or import happened. In the explicit saved-response fixture, the card showed the existing algebra manuscript excerpt; screenshot `native-current-1280/import-draft-preview.png`. Native preview and official App rebuilt; `codesign --verify --deep --strict` passed; backend baseline remains 36 unchanged files. No DeepSeek or Lean request was made. The source screen's simulated multi-file processing list cannot be represented as real user jobs by this one-record fixture, so full same-data 15-screen pixel acceptance remains open.
## Failure result mathematical goal hierarchy

The failure summary previously left most of its upper region empty and placed the theorem goal below the four status facts. It now presents the saved original theorem goal directly under the first unfinished-step explanation, labeled “原题目标”; the status facts remain below. This moves real mathematics into the focal region of the Stitch result composition without suggesting that the theorem is false or fabricating a diagnostic. The explicit native failure fixture showed step 3 still unproved, 2/4 saved steps established, the original inequality, and Kernel not passed. Screenshot `native-current-1280/failure-goal-hierarchy.png`. Preview/official builds and official code-signature verification passed; 36 backend baseline files unchanged. No AI or Lean call was made. Source HTML uses a different fictional proof, so full 15-page matched-data pixel acceptance remains unproven.
## Formal inspector bounded data tabs

The explicit formal-details screen now keeps MathIR, diagnostics, Statement Lock, and Mathlib content in the same 440 pt right-hand inspection viewport as Lean code. This prevents a large saved MathIR JSON record from stretching the entire two-column page and pushing mathematical proof steps and lower metrics away. The complete saved content remains scrollable and selectable. In the native fixture, switching to MathIR exposed a nested scroll area; scrolling changed its own scroll value while left proof cards and inspector footer stayed in place. Screenshot `native-current-1280/formal-details-mathir-scroll.png`. Preview and official App builds passed; official signature verified and 36 backend files unchanged. No AI or Lean verification was rerun. Full same-data 15-screen fidelity remains unproven.

## Workspace mathematical headline

The workspace manuscript now uses the actual saved theorem goal as its large headline when that goal is present. Its existing proposition card remains below, matching the Stitch hierarchy of a prominent theorem heading followed by the formal statement. A record without a goal retains the generic heading. The explicit native fixture displayed `(x + y)² ≤ 2(x² + y²)` at headline size, with the same saved proposition and four proof steps below; capture updated at `native-current-1280/workspace.png`. The preview and official native App compiled, the official signature passed strict deep verification, and all 36 backend baseline files remained unchanged. No DeepSeek or Lean call was made. The Stitch reference uses a different theorem, so this is a visual improvement, not same-data pixel acceptance across all 15 screens.

## Verifying page ties its mathematical content to the submitted task

The Stitch verifying reference names its active theorem in the header. Native now shows the goal from the current job's MathIR in that position once the structure event has arrived, falling back to “正在验证你的证明” before it exists. The original-manuscript section reads the saved submission snapshot, so later draft edits cannot make an in-progress job appear to be checking different text. The job still determines stage and final status; the UI does not infer proof success from progress. In the explicit native fixture, the header displayed `(x + y)² ≤ 2(x² + y²)`, with stage four running and the result pending; capture updated at `native-current-1280/verifying.png`. The preview does not exercise changing a draft during an actual running job, so snapshot behavior is supported by source inspection and compilation rather than live-job GUI evidence. The official App rebuilt and passed strict deep signature verification; all 36 backend baseline files match. No new DeepSeek or Lean request was made. All 15 pages still lack matched-data full-page 1:1 acceptance.

## Success page ambiguity metric wording

The success summary now labels the saved `unresolvedAmbiguityIds` count as “未决歧义” and displays its count with the unit “处”, rather than implying a record count for source ambiguity. In the explicit success fixture, the summary visibly showed `4 / 4 已核验` and `未决歧义 0 处`; this is the fixture's saved result, not a new verification. The native preview and official macOS App rebuilt, strict deep code-signature verification passed, and all 36 backend baseline hashes matched. No DeepSeek, Lean, or Kernel request was made. Same-data full-page 1:1 acceptance across the 15 screens remains incomplete.

## Workspace comparison now binds Stitch's mathematical context

The display-only Cauchy–Schwarz fixture previously had no MathIR scope, variables, or assumptions, so the SwiftUI workspace's right rail could not reproduce the Stitch reference's mathematical context. The fixture now includes `f` and `g` in `L²([a,b])`, the three displayed hypotheses, and a goal scope; it stays under `tests/fixtures/ui` and is loaded only by the explicit preview control. After rebuilding the standalone preview, the actual SwiftUI workspace AX tree showed both variables and all three assumptions in the right rail beside the matching integral inequality. The preview banner continued to state that no AI or Lean ran and no Kernel certificate exists. No production UI, verification data, backend, DeepSeek, Lean, or Kernel code was changed. This closes the workspace's theorem-context data mismatch for visual review, while full same-viewport pixel acceptance and the remaining fourteen screens are still open.

## Clean comparison viewport for the 15-screen preview

The independent UI fixture target had pinned a persistent notice below every page, reducing the visible design area and covering page content in screenshots. `NativeRoot` now accepts an environment-only notice suppression setting whose default remains `false`; only `PreviewApp` sets it to `true`. The fixture window title and optional top QA toolbar still identify the preview. After recompiling, I hid the QA toolbar and inspected the actual Mac window: no notice banner remained, and the homepage's hero, input, and entry-card positions aligned closely with the 1280 pt Stitch first viewport. The official macOS App was rebuilt; strict deep signature verification passed and all 36 backend baseline hashes matched, confirming production keeps the default notice behavior and unchanged backend. One existing `allowedFileTypes` deprecation warning remains. This improves the comparison viewport across all 15 routes; it does not establish full-page pixel acceptance, and homepage lower-page sample content still differs from the Stitch demonstration.

## Verifying-page fixture snapshot consistency

Switching the explicit preview fixture while already on the verifying route previously updated the displayed record but left the in-flight task's saved MathIR snapshot pointing at the prior sample. Added a `UI_FIXTURE`-only store binding that updates the displayed record, task MathIR snapshot, draft, and submitted original together. The preview build defines this flag; the official App target does not compile the fixture-only method. In the actual native window, switching to the Cauchy Stitch sample updated the header goal, task status goal, four proof steps, and expanded original manuscript to the same inequality and source text. The local-service banner remained honest and the final result remained pending; this was a display fixture, with no AI, Lean, or Kernel execution. Preview rebuilt and GUI/AX state inspected. Official macOS App rebuilt and passed strict deep signature verification; all 36 backend baseline hashes matched. This resolves sample-state mixing for visual review, not full same-data 1:1 acceptance for all 15 screens.

## Preferences: input, formalization, and shortcuts

Compared tabs 2–4 with the original Preferences export. Their visual card and grid hierarchy is now represented in SwiftUI with two-column panels at desktop widths. Input preferences use the already-supported image/PDF, math-text, and handwriting actions, and explain the existing original-preserving review flow. Formalization preferences bind the existing `showEngineering` setting and link to the saved formalization record; supporting cards describe Lean Kernel, diagnostics, and saved Mathlib results without fabricated timeout, cache, or hardware metrics. The shortcuts panel lists the five key equivalents actually registered by `NativeApp` (new, import, export, verify, preferences).

The export's auto-disambiguation rules, camera preprocessing toggles, clipboard watcher, Lean exposure modes, timeout slider, neural acceleration, Mathlib cache telemetry/reindex action, and global LaTeX/Lean bindings do not exist in the current product binding, so they are not presented as working settings. Native preview compiled; actual GUI/AX inspection covered each of tabs 2–4. Official macOS App rebuilt and `codesign --verify --deep --strict` passed; backend integrity report shows 36 files checked, none changed. No AI, Lean, or Kernel request. This closes the three previously empty tabs structurally while full same-data pixel parity for the Preferences page and all 15 pages remains outstanding.

## Workspace command ribbon grouping

Compared the native workspace ribbon to the original workspace export. The formatting controls (heading, emphasis, paragraph roles, inline/display math) now form the left group, while existing source/camera/import/reference actions form a separate right group with the reference's flexible gap. No unsupported one-step proof, LaTeX/PDF exporter, live-validation toggle, or new import behavior was added. Rebuilt the native fixture and inspected the actual Mac window with the saved Cauchy–Schwarz sample: the groups separate left/right, all actions remain exposed in AX, and the record still reports 0/4 verified. This is a saved UI fixture; no Provider, Lean, or Kernel request. The official macOS App then rebuilt, passed `codesign --verify --deep --strict`, and the backend integrity report remained 36 checked / 0 changed. One existing `allowedFileTypes` deprecation warning remains. The article title/body density and full-page same-data parity remain open.
